<?php
session_start();
	require 'protected.php';
	checkLogin();
	checkUserLevel(5, 'index.php');
require 'config.php';
require 'core/functions.php'; 
require 'language.php';

// Inicializar a conexão com o banco de dados
$db = new Database();
$conn = $db->getConnection();

// Obter a notícia existente com base no ID passado na URL
if (isset($_GET['id'])) {
    $newsId = $_GET['id'];
    $stmt = $conn->prepare("SELECT * FROM news WHERE id = ?");
    $stmt->execute([$newsId]);
    $news = $stmt->fetch();
    
    if (!$news) {
        echo "News not found.";
        exit;
    }
} else {
    echo "No news ID provided.";
    exit;
}

// Fetch categories for the select dropdown
$stmt = $conn->prepare("SELECT * FROM categories");
$stmt->execute();
$categories = $stmt->fetchAll();

// Atualizar a notícia
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $subtitle = $_POST['subtitle']; // Novo campo para o subtítulo
    $content = $_POST['content'];
    $categoryId = $_POST['category'];
    $coverImage = $_FILES['cover_image'];
    $thumbnailImage = $_FILES['thumbnail_image'];

    // Verificar se novas imagens foram enviadas e fazer upload/redimensionamento
    if ($coverImage['size'] > 0) {
        $coverImagePath = 'uploads/cover_' . basename($coverImage['name']);
        move_uploaded_file($coverImage['tmp_name'], $coverImagePath);
        resizeImage($coverImagePath, $coverImagePath, 650, 300);
    } else {
        $coverImagePath = $news['cover_image'];
    }

    if ($thumbnailImage['size'] > 0) {
        $thumbnailImagePath = 'uploads/thumb_' . basename($thumbnailImage['name']);
        move_uploaded_file($thumbnailImage['tmp_name'], $thumbnailImagePath);
        resizeImage($thumbnailImagePath, $thumbnailImagePath, 254, 160);
    } else {
        $thumbnailImagePath = $news['thumbnail_image'];
    }

    // Atualizar a notícia no banco de dados
    $stmt = $conn->prepare("UPDATE news SET title = ?, subtitle = ?, content = ?, category_id = ?, cover_image = ?, thumbnail_image = ? WHERE id = ?");
    $stmt->execute([$title, $subtitle, $content, $categoryId, $coverImagePath, $thumbnailImagePath, $newsId]);
	header("Location: edit_news.php?id=" .$newsId. "");
    echo "News updated successfully!";
}
?>

<!DOCTYPE html>
<html lang="en" data-sidenav-size="fullscreen">

    <head>
        <meta charset="utf-8" />
        <title> <?php echo lang('Edit News'); ?> | <?php echo SITE_TITLE; ?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="<?php echo META_DESCRIPTION;?>" name="description" />
		<meta name="keywords" content="<?php echo META_KEYWORDS;?>">
        <meta content="SITE_TITLE" name="author" />

        <!-- App favicon -->
        <link rel="shortcut icon" href="assets/images/favicon.ico">

        <!-- Daterangepicker css -->
        <link rel="stylesheet" href="assets/vendor/daterangepicker/daterangepicker.css">

        <!-- Vector Map css -->
        <link rel="stylesheet" href="assets/vendor/admin-resources/jquery.vectormap/jquery-jvectormap-1.2.2.css">

        <!-- Theme Config Js -->
        <script src="assets/js/hyper-config.js"></script>

        <!-- App css -->
        <link href="assets/css/app-saas.min.css" rel="stylesheet" type="text/css" id="app-style" />
<script src="js/Chart.js"></script>
<script src="js/jquery.js"></script>
        <!-- Icons css -->
        <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    </head>

    <body>
        <!-- Begin page -->
        <div class="wrapper">

            <?php include 'includes/topbar.php';?> 

            <!-- ========== Left Sidebar Start ========== -->
            <div class="leftside-menu">

               

                

                <!-- Sidebar Hover Menu Toggle Button -->
                <div class="button-sm-hover" data-bs-toggle="tooltip" data-bs-placement="right" title="Show Full Sidebar">
                    <i class="ri-checkbox-blank-circle-line align-middle"></i>
                </div>

                <!-- Full Sidebar Menu Close Button -->
                <div class="button-close-fullsidebar">
                    <i class="ri-close-fill align-middle"></i>
                </div>

                <!-- Sidebar -left -->
                <div class="h-100" id="leftside-menu-container" data-simplebar>
                    <!-- Leftbar User -->
                    
<?php include 'includes/sidebar2.php';?>
                    <!--- End Sidemenu -->

                    <div class="clearfix"></div>
                </div>
            </div>
            <!-- ========== Left Sidebar End ========== -->

            <!-- ============================================================== -->
            <!-- Start Page Content here -->
            <!-- ============================================================== -->

            <div class="content-page" >
                <div class="content" >

                    <!-- Start Content-->
                    <div class="container-fluid" >

                        <div class="row">
                            <div class="col-8"  style="margin:0 auto;">
                                <div class="page-title-box">                                    
                                    
                                    
									<div class="page-title-right">
                                        <form class="d-flex">
											<button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#danger-header-modal">Delete</button>
                                        </form>
                                    </div>
									<h4 class="page-title" ><?php echo lang('Edit News'); ?></h4>
                                </div>
								
                            </div>
                        </div>

                        <div class="row">
						
						<div class="card col-xl-8 col-lg-8"  style="margin:0 auto;">
						<?php
						
							switch ($error) {
									
										case 1:
										?>
											<div class="alert alert-success" role="alert">
												<strong><?php echo lang('News added successfully!') ?></strong>
											</div>
										<?php
										break;
										case 2:
										?>
											<div class="alert alert-danger bg-transparent text-danger" role="alert">
												<strong><?php echo lang('Invalid login credentials.') ?></strong>
											</div>
										<?php
										break;
									default:
									
										break;
								}
						
						?>
						
							<form method="post" enctype="multipart/form-data">
								<div class="mb-3">
									<h4 for="simpleinput" class="form-label"><?php echo lang('Title'); ?>:</h4>
									<input type="text" name="title" id="simpleinput" value="<?php echo htmlspecialchars($news['title']); ?>" class="form-control" required>
								</div>
								<div class="mb-3">
									<h4 for="simpleinput" class="form-label"><?php echo lang('Subtitle'); ?>:</h4>
									<input type="text" name="subtitle" id="simpleinput" value="<?php echo htmlspecialchars($news['subtitle']); ?>" class="form-control" required>
								</div>

								<h4 for="content"><?php echo lang('Content'); ?>:</h4>
								<textarea id="content" name="content" required><?php echo htmlspecialchars($news['content']); ?></textarea><br>
								
								<div class="mb-3">
									<label for="example-fileinput" class="form-label"><?php echo lang('Category'); ?>:</label>
										<select name="category" class="form-select mb-3" required>
										<?php foreach ($categories as $category): ?>
											<option value="<?php echo $category['id']; ?>" <?php echo $category['id'] == $news['category_id'] ? 'selected' : ''; ?>>
												<?php echo $category['name']; ?>
											</option>
										<?php endforeach; ?>
									</select>
								</div>
								<div class="mb-3">
									<label for="example-fileinput" class="form-label"><?php echo lang('Cover Image'); ?>: (650x300)</label>
									<input type="file" id="example-fileinput" class="form-control" name="cover_image">
									<img style="margin-top:10px !important;" src="<?php echo $news['cover_image']; ?>" alt="<?php echo $lang['cover_image']; ?>" width="850px"><br>
								</div>
								<div class="mb-3">
									<label for="example-fileinput" class="form-label"><?php echo lang('Tumbnail'); ?>: (254x160)</label>
									<input type="file" id="example-fileinput" class="form-control" name="thumbnail_image">
									<img style="margin-top:10px !important;" src="<?php echo $news['thumbnail_image']; ?>" alt="<?php echo $lang['thumbnail_image']; ?>" width="350"><br>
								</div>

								<div class="d-grid">
									<button type="submit" class="btn btn-lg btn-primary"><?php echo lang('Update'); ?></button>
								</div>
							</form>

							<!-- Include a WYSIWYG editor -->
							<script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
							<script>
								CKEDITOR.replace('content');
							</script>
                            

                       </div>


                    </div>
                    <!-- container -->

                </div>
                <!-- content -->

                
						<div id="danger-header-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="danger-header-modalLabel" aria-hidden="true">
							<div class="modal-dialog">
								<div class="modal-content">
									<div class="modal-header bg-danger">
										<h4 class="modal-title" style="color: white;" id="danger-header-modalLabel">Warning: Post Deletion</h4>
										<button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"></button>
									</div>
									<div class="modal-body">
													<div class="mb-1">
														<label for="example-palaceholder" class="form-label">You are about to delete this post. This action is permanent and cannot be undone.</label>
													</div>
													<div class="mb-1">
														<h4><label for="example-palaceholder" class="form-label">Title: <?php echo htmlspecialchars($news['title']); ?></label></h4>
													</div>
													<div class="mb-1">
														<h4><label for="example-palaceholder" class="form-label">Create At: <?php echo htmlspecialchars($news['created_at']); ?></label></h4>
													</div>
													<div class="mb-1">
														<label for="example-palaceholder" class="form-label">Upon confirmation, all comments, likes, and any other interactions associated with this post will also be permanently deleted.</label>
													</div>
													<div class="mb-1">
														<label for="example-palaceholder" class="form-label">Are you sure you want to proceed?</label>
													</div>
										
                                                <!-- comment box -->
													
													
                                               
									</div>
									<div class="modal-footer">
										<button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
										<a Href="delete_news.php?id=<?php echo $newsId; ?>" type="submit" class="btn btn-danger">Delete</a>
									</div>
									
									<!-- end .border-->
								</div><!-- /.modal-content -->
							</div><!-- /.modal-dialog -->
						</div><!-- /.modal -->
            </div>

            <!-- ============================================================== -->
            <!-- End Page content -->
            <!-- ============================================================== -->

        </div>
        <!-- END wrapper -->

        <!-- Vendor js -->
        <script src="assets/js/vendor.min.js"></script>

        <!-- Daterangepicker js -->
        <script src="assets/vendor/daterangepicker/moment.min.js"></script>
        <script src="assets/vendor/daterangepicker/daterangepicker.js"></script>
        
        <!-- Apex Charts js -->
        <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>

        <!-- Vector Map js -->
        <script src="assets/vendor/admin-resources/jquery.vectormap/jquery-jvectormap-1.2.2.min.js"></script>
        <script src="assets/vendor/admin-resources/jquery.vectormap/maps/jquery-jvectormap-world-mill-en.js"></script>

        <!-- Dashboard App js -->
        <script src="assets/js/pages/demo.dashboard.js"></script>

      

        <!-- Apex Chart Column Demo js -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/dayjs/1.11.0/dayjs.min.js"></script>  
        <script src="https://cdnjs.cloudflare.com/ajax/libs/dayjs/1.11.0/plugin/quarterOfYear.min.js"></script>        
        <!--<script src="assets/js/pages/demo.apex-column.js"></script> -->
		<?php
			include 'js/graficosCollum.php';
			//include 'js/graficospie.php';
			include 'js/graficosbar.php';
		?>

        <!-- Apex Chart Area Demo js -->
        <script src="assets/js/app.min.js"></script>

    </body>
</html> 
