<?php 
session_start();

include 'config.php';
	require 'core/functions.php'; 
	include 'language.php'; 
	
// Fetch news from the database
$db = new Database();
$conn = $db->getConnection();

$stmt = $conn->prepare("SELECT n.*, c.name as category_name FROM news n LEFT JOIN categories c ON n.category_id = c.id ORDER BY n.created_at DESC LIMIT 5");
$stmt->execute();
$news = $stmt->fetchAll();

?>

<!DOCTYPE html>
<html lang="en" data-layout="topnav">

    <head>
        <meta charset="utf-8" />
        <title><?php echo SITE_TITLE; ?> | <?php echo SITE_SUBTITLE; ?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="<?php echo META_DESCRIPTION;?>" name="description" />
		<meta name="keywords" content="<?php echo META_KEYWORDS;?>">
        <meta content="SITE_TITLE" name="author" />

        <!-- App favicon -->
        <link rel="shortcut icon" href="assets/images/favicon.ico">

        <!-- Plugin css -->
        <link rel="stylesheet" href="assets/vendor/daterangepicker/daterangepicker.css">
        <link href="assets/vendor/admin-resources/jquery.vectormap/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css" />

        <!-- Theme Config Js -->
        <script src="assets/js/hyper-config.js"></script>

        <!-- App css -->
        <link href="assets/css/app-saas.min.css" rel="stylesheet" type="text/css" />

        <!-- Icons css -->
        <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    </head>

    <body>
        <!-- Begin page -->
        <div class="wrapper">

            

		<?php include('includes/topnav.php'); ?>

            
            <div class="content-page" style="max-width: 1300px; margin:0 auto;">
                <div class="content">
                    
                    <!-- Start Content-->
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-12 center" > 

                                <div id="carouselExampleControls" class="carousel slide " data-bs-ride="carousel">
    <div class="carousel-inner" role="listbox">
        <div class="carousel-item active">
            <img class="d-block img-fluid" style="important;width: 100% !important; height: 400px !important;" src="assets/images/slide/slide-1.jpg" alt="First slide">
        </div>
        <div class="carousel-item" style="">
            <a href="#"><img class="d-block img-fluid" style="width: 100% !important; height: 400px !important;" src="assets/images/slide/slide-2.jpg" alt="Second slide"></a>
            <div class="carousel-caption d-none d-md-block" style="background: #333333d9; float:right;">
                <h3 class="text-white">Second slide label</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
            </div>
        </div>
        <div class="carousel-item">
            <img class="d-block img-fluid" style="width: 100% !important; height: 400px !important;" src="assets/images/slide/slide-3.jpg" alt="Third slide">
        </div>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
    </a>
</div>

                            </div> <!-- end col -->

                           
                        </div>
                        <!-- end row -->

                        <div class="row" Style="margin-top:20px;">
                            <div class="col-lg-4 col-sm-6">
                                <a href="#">
								<div class="card text-bg-primary" style="background: #405A7C !important;">
                                    <div class="card-body">
                                        <blockquote class="card-bodyquote">
                                            <h1 style="text-align: center;width:230px; float:right;">JOINT THE DISCORD</h1>
											<img class="d-block img-fluid" style="width: 100px !important; height: 100px !important;float: left;" src="assets/images/discord.png" alt="Third slide">
                                        </blockquote>
                                    </div> <!-- end card-body-->
                                </div> <!-- end card-->
								</a>
                            </div>
							<div class="col-lg-4 col-sm-6">
                                <a href="#">
								<div class="card text-bg-primary" style="background: #405A7C !important;">
                                    <div class="card-body">
                                        <blockquote class="card-bodyquote">
                                            <h1 style="text-align: center;width:230px; float:right;">DOWNLOAD ON STEAM</h1>
											<img class="d-block img-fluid" style="width: 100px !important; height: 100px !important;float: left;" src="assets/images/steam.png" alt="Third slide">
                                        </blockquote>
                                    </div> <!-- end card-body-->
                                </div> <!-- end card-->
								</a>
                            </div>
							<div class="col-lg-4 col-sm-6">
                                <a href="#">
								<div class="card text-bg-primary" style="background: #405A7C !important;">
                                    <div class="card-body">
                                        <blockquote class="card-bodyquote">
                                            <h1 style="text-align: center;width:230px; hight:100%; float:right;">PLAY ON PLAYSTORE</h1>
											<img class="d-block img-fluid" style="width: 100px !important; height: 100px !important;float: left;" src="assets/images/playstore.png" alt="Third slide">
                                        </blockquote>
                                    </div> <!-- end card-body-->
                                </div> <!-- end card-->
								</a>
                            </div>
                        </div>
                        <!-- end row -->

                        <div class="row">
                            <div class="col-xl-8 col-lg-12 order-lg-2 order-xl-1">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <h4 class="header-title">NEWS</h4>
                                            <a href="new.php" class="btn btn-sm btn-link">VIEW ALL</a>
                                        </div>
										
						<?php foreach ($news as $item): ?>
						<div class="row">
                            <div class="col-lg-12">
                                <div class="card">
                                    <div class="row g-0 align-items-top" style="max-height:160px;">
                                        <div class="col-md-4">
                                            <a href="read.php?new=<?php echo $item['id']; ?>" class="link-secondary"><img src="<?php echo $item['thumbnail_image']; ?>" style="width:342px; height:160px;" class="img-fluid rounded-start" alt="..."></a>
                                        </div>
                                        <div class="col-md-8">
                                            <div class="card-body">
                                                <h5 class="card-title"><a href="read.php?new=<?php echo $item['id']; ?>" class="link-secondary"><?php echo $item['title']; ?></a></h5>
                                                <p class="card-text"><?php echo $item['subtitle']; ?></p>
                                                <p class="card-text"><small class="text-muted"><?php echo $item['created_at']; ?></small></p>
                                            </div> <!-- end card-body-->
                                        </div> <!-- end col -->
                                    </div> <!-- end row-->
                                </div> <!-- end card-->
                            </div> <!-- end col-->
                        </div>
						<?php endforeach; ?>

                                    </div> <!-- end card-body-->
                                </div> <!-- end card-->
                            </div> <!-- end col-->

                           

                            <div class="col-xl-4 col-lg-6 order-lg-1">
                                <div class="card">
                                    <div class="card-body pb-0">
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <h4 class="header-title">Top 10 Global Rank</h4>
                                        </div>
                                    </div>

                                    <div class="card-body py-0 mb-3" data-simplebar style="max-height: 403px;"> 
                                        <table class="table table-striped table-centered mb-0">
    <thead>
        <tr>
            <td>Name</td>
            <td>Class</td>
            <td>Level</td>
        </tr>
    </thead>
    <tbody>
	<?php 
				$class_Character = getStableHash($class);
				$conditions = ["ORDER BY level DESC"];
				$totalC = fetchRank('characters', '*');
				foreach ($totalC as $class) {	
				
			  ?>
        <tr>
            <td class="table-user"><?php echo $class['characterName'];?></td>
            <td><?php
										
											$resultArray = processArrayClass($array_Class);
											
											$key = $class['dataId'];; // Por exemplo, a chave que você quer verificar

											$data = getDataForKey($key, $resultArray);
											if ($data !== null) {
												echo lang($data);
											} else {
												echo "null";
											}
										
										?></td>
            <td><?php echo $class['level'];?></td>
        </tr>
		<?php
			}
		?>

    </tbody>
</table>
                                        <!-- end timeline -->
                                    </div> <!-- end slimscroll -->
                                </div>
                                <!-- end card-->
                            </div>
                            <!-- end col -->

                        </div>
                        <!-- end row -->

                    </div>
                    <!-- container -->

                </div>
                <!-- content -->

                <!-- Footer Start -->
                <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-6">
                                <script>document.write(new Date().getFullYear())</script> © <?php echo SITE_TITLE; ?>
                            </div>
                            <div class="col-md-6">
                                <div class="text-md-end footer-links d-none d-md-block">
                                    <a href="javascript: void(0);">About</a>
                                    <a href="javascript: void(0);">Support</a>
                                    <a href="javascript: void(0);">Contact Us</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </footer>
                <!-- end Footer -->

            </div>

            <!-- ============================================================== -->
            <!-- End Page content -->
            <!-- ============================================================== -->

        </div>
        <!-- END wrapper -->

   
        
        <!-- Vendor js -->
        <script src="assets/js/vendor.min.js"></script>

        <!-- Daterangepicker js -->
        <script src="assets/vendor/daterangepicker/moment.min.js"></script>
        <script src="assets/vendor/daterangepicker/daterangepicker.js"></script>
        
        <!-- Apex Charts js -->
        <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>

        <!-- Vector Map js -->
        <script src="assets/vendor/admin-resources/jquery.vectormap/jquery-jvectormap-1.2.2.min.js"></script>
        <script src="assets/vendor/admin-resources/jquery.vectormap/maps/jquery-jvectormap-world-mill-en.js"></script>

        <!-- Dashboard App js -->
        <script src="assets/js/pages/demo.dashboard.js"></script>

        <!-- App js -->
        <script src="assets/js/app.min.js"></script>

    </body>
</html>