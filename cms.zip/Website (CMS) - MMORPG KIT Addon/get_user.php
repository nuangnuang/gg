<?php
include 'config.php';
	require 'core/functions.php'; 
	include 'language.php'; 

try {
    $database = new Database();
    $conn = $database->getConnection();
} catch (Exception $e) {
    die("Falha na conexão: " . $e->getMessage());
}

$q = $_GET['q'];

$sql = "SELECT id, username FROM userlogin WHERE username LIKE ?";
$stmt = $conn->prepare($sql);
$search = "%$q%";
$stmt->bindParam(1, $search, PDO::PARAM_STR);
$stmt->execute();
$result = $stmt->fetchAll();

$suggestions = "";
if ($result) {
    foreach ($result as $row) {
        $suggestions .= "<div onclick='selectSuggestion(\"user\", \"" . $row['id'] . "\", \"" . $row['username'] . "\")'>" . $row['username'] . "</div>";
    }
}

echo $suggestions;
?>
