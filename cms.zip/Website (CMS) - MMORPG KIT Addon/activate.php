<?php
require 'Config.php';
require 'core/functions.php'; 
include 'language.php'; 
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Atualizar o status de ativação do usuário
    $db = new Database();
    $conn = $db->getConnection();

    $stmt = $conn->prepare("UPDATE userlogin SET isEmailVerified = 1 WHERE id = ?");
    $stmt->execute([$id]);

    echo "Your account has been activated. You can now login.";
} else {
    echo "Invalid request.";
}
?>
