<?php 
session_start();
	require 'protected.php';
	checkLogin();
	checkUserLevel(5, 'index.php');
require 'config.php';
require 'core/functions.php'; 
require 'language.php';

	

?>
<!DOCTYPE html>
<html lang="en" data-sidenav-size="fullscreen">

    <head>
        <meta charset="utf-8" />
        <title><?php echo SITE_TITLE; ?> | <?php echo lang('Items'); ?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="<?php echo META_DESCRIPTION;?>" name="description" />
		<meta name="keywords" content="<?php echo META_KEYWORDS;?>">
        <meta content="SITE_TITLE" name="author" />

        <!-- App favicon -->
        <link rel="shortcut icon" href="assets/images/favicon.ico">

        <!-- Daterangepicker css -->
        <link rel="stylesheet" href="assets/vendor/daterangepicker/daterangepicker.css">

        <!-- Vector Map css -->
        <link rel="stylesheet" href="assets/vendor/admin-resources/jquery.vectormap/jquery-jvectormap-1.2.2.css">

        <!-- Theme Config Js -->
        <script src="assets/js/hyper-config.js"></script>

        <!-- App css -->
        <link href="assets/css/app-saas.min.css" rel="stylesheet" type="text/css" id="app-style" />
<script src="js/Chart.js"></script>
<script src="js/jquery.js"></script>
        <!-- Icons css -->
        <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
		<!-- MDI Icons Demo js -->
        <script src="assets/js/pages/demo.materialdesignicons.js"></script>
    </head>

    <body>
        <!-- Begin page -->
        <div class="wrapper">

            <?php include 'includes/topbar.php';?> 

            <!-- ========== Left Sidebar Start ========== -->
            <div class="leftside-menu">

                

                <!-- Sidebar Hover Menu Toggle Button -->
                <div class="button-sm-hover" data-bs-toggle="tooltip" data-bs-placement="right" title="Show Full Sidebar">
                    <i class="ri-checkbox-blank-circle-line align-middle"></i>
                </div>

                <!-- Full Sidebar Menu Close Button -->
                <div class="button-close-fullsidebar">
                    <i class="ri-close-fill align-middle"></i>
                </div>

                <!-- Sidebar -left -->
                <div class="h-100" id="leftside-menu-container" data-simplebar>
                    <!-- Leftbar User -->
                    <div class="leftbar-user">
                        <a href="pages-profile.html">
                            <img src="assets/images/users/avatar-1.jpg" alt="user-image" height="42" class="rounded-circle shadow-sm">
                            <span class="leftbar-user-name mt-2">Dominic Keller</span>
                        </a>
                    </div>

                    <!--- Sidemenu -->
<?php include 'includes/sidebar2.php';?>                         <!--- End Sidemenu -->

                    <div class="clearfix"></div>
                </div>
            </div>
            <!-- ========== Left Sidebar End ========== -->

            <!-- ============================================================== -->
            <!-- Start Page Content here -->
            <!-- ============================================================== -->

            <div class="content-page">
                <div class="content">

                    <!-- Start Content-->
                    <div class="container-fluid">

                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">                                    
                                    
                                    <h4 class="page-title"><?php echo lang('Items list'); ?></h4>
                                </div>
                            </div>
                        </div>


                        <div class="row">
						<div class="col-lg-12">
                       <div class="card">
                         <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                        
                
                                                                                  
                        <script src="assets/js/pages/demo.datatable-init.js"></script>                            
							<table id="basic-datatable" class="table dt-responsive nowrap w-100">
								<thead>
									<tr>
										<th><?php echo lang('Username'); ?></th>
										<th><?php echo lang('Id'); ?></th>
										<th><?php echo lang('Type'); ?></th>
										<th><?php echo lang('Category'); ?></th>
										<th><?php echo lang('Set'); ?></th>
										<th><?php echo lang('Level'); ?></th>
										
									</tr>
								</thead>


								<tbody>
								<?php
								
									if (isset($_GET['list']) & ($_GET['list'] == 'banned')) {
										$list = $_GET['list'];
										$list = filter_var($list, FILTER_SANITIZE_STRING);
										// Defina as condições desejadas como um array
										

										// Use a função fetchRecords para buscar registros em uma tabela com condições
										$result = fetchRecords('items', '*', $conditions);
									
									}else{

										// Use a função fetchRecords para buscar registros em uma tabela com condições
										$result = fetchRecords('items', '*');
									}

									foreach ($result as $row) {

								?>
									<tr>
										<td><a href="edit_item.php?id=<?php echo $row['id'];?>" class="link-primary"><img src="<?php echo $row['image']; ?>" style="height: 40px !important; width:40px !important; margin-right:10px;" /><?php echo $row['name']; ?></a></td>
										<td ><?php echo $row['id']; ?></td>
										<td><?php 
										
										$idd = $row['ItemType']; 
										
										if($idd != 0){
										$conditions = ["id = '$idd'"];
										$result = fetchRecords('category_items', '*', $conditions);
									

									foreach ($result as $rows) {
										
										 echo $rows['name'];

									}
										?><?php }else{
										?>
										<?php echo lang('None'); ?>
										<?php
									}?></td>
										<td>
										<?php
										
											$categoryId = $row['category'];
											if ($categoryId != 0){
											$conditionsss = ["id = '$categoryId'"];
											$cat = fetchRecords('category_items', '*', $conditionsss);
											foreach ($cat as $rows) {
												?><a href="perfil.php?id=<?php echo $categoryId;?>" class="link-primary"><?php echo $rows['name'];; ?></a><?php
											
											}
											}else{
												echo lang('No Guild');
											}
										
										?></td>
										<td><?php echo $row['equipamentSet']; ?></td>
										<td><?php echo $row['level']; ?>
										</td>
										
									</tr>
									
									<?php } ?>
									
								</tbody>
							</table>

                      </div> <!-- end card-body-->
                                </div> <!-- end card-->
                            </div> <!-- end col -->
                        </div>


           
                                </div>
                        </div>
						
                            
                        </div>
                        <!-- end row -->

                        <div class="row">
                            <div class="col-xl-12 col-lg-12 order-lg-2 order-xl-1">
                                <div class="card">
                                    <!-- Datatable Init js -->


            

                                    </div> <!-- end card-->
                            </div> <!-- end col-->


                           <!-- end col -->

                        </div>
                        <!-- end row -->

                    </div>
                    <!-- container -->

                </div>
                <!-- content -->

                

            </div>

            <!-- ============================================================== -->
            <!-- End Page content -->
            <!-- ============================================================== -->

        </div>
        <!-- END wrapper -->


        <!-- Vendor js -->
        <script src="assets/js/vendor.min.js"></script>

        <!-- Daterangepicker js -->
        <script src="assets/vendor/daterangepicker/moment.min.js"></script>
        <script src="assets/vendor/daterangepicker/daterangepicker.js"></script>
        
        <!-- Apex Charts js -->
        <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>

        <!-- Vector Map js -->
        <script src="assets/vendor/admin-resources/jquery.vectormap/jquery-jvectormap-1.2.2.min.js"></script>
        <script src="assets/vendor/admin-resources/jquery.vectormap/maps/jquery-jvectormap-world-mill-en.js"></script>

        <!-- Dashboard App js -->
        <script src="assets/js/pages/demo.dashboard.js"></script>

      <!-- Datatable js -->
        <script src="assets/vendor/datatables.net/js/jquery.dataTables.min.js"></script>
        <script src="assets/vendor/datatables.net-bs5/js/dataTables.bootstrap5.min.js"></script>
        <script src="assets/vendor/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
        <script src="assets/vendor/datatables.net-responsive-bs5/js/responsive.bootstrap5.min.js"></script>
        <script src="assets/vendor/jquery-datatables-checkboxes/js/dataTables.checkboxes.min.js"></script>

        <!-- Apex Chart Column Demo js -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/dayjs/1.11.0/dayjs.min.js"></script>  
        <script src="https://cdnjs.cloudflare.com/ajax/libs/dayjs/1.11.0/plugin/quarterOfYear.min.js"></script>        
        <!--<script src="assets/js/pages/demo.apex-column.js"></script> -->
		
 <script src="assets/js/pages/demo.customers.js"></script>
        <!-- Apex Chart Area Demo js -->
        <script src="assets/js/app.min.js"></script>

    </body>
</html> 