<?php
session_start();

	include 'config.php';
	require 'core/functions.php'; 
	require 'protected.php';
	checkLogin();
	checkUserLevel(5, 'index.php');
	include 'language.php'; 

// Inicializar a conexão com o banco de dados
$db = new Database();
$conn = $db->getConnection();

// Verificar se o ID da notícia foi passado
if (isset($_GET['id'])) {
    $newsId = $_GET['id'];

    // Buscar as imagens associadas à notícia
    $stmt = $conn->prepare("SELECT cover_image, thumbnail_image FROM news WHERE id = ?");
    $stmt->execute([$newsId]);
    $news = $stmt->fetch();

    if ($news) {
        // Deletar as imagens do sistema de arquivos
        if (file_exists($news['cover_image'])) {
            unlink($news['cover_image']);
        }
        if (file_exists($news['thumbnail_image'])) {
            unlink($news['thumbnail_image']);
        }

        // Deletar a notícia do banco de dados
        $stmt = $conn->prepare("DELETE FROM news WHERE id = ?");
        $stmt->execute([$newsId]);
	header("Location: news.php");
        echo "Notícia deletada com sucesso!";
    } else {
		header("Location: news.php");
        echo "Notícia não encontrada!";
    }
} else {
	header("Location: news.php");
    echo "ID da notícia não fornecido!";
}
?>
