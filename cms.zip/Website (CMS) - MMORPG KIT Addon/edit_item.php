<?php
session_start();
	require 'protected.php';
	checkLogin();
	checkUserLevel(5, 'index.php');
require 'config.php';
require 'core/functions.php'; 
require 'language.php';
// Fetch categories from the database
$db = new Database();
$conn = $db->getConnection();

$stmt = $conn->prepare("SELECT * FROM category_items WHERE type = '0'");
$stmt->execute();
$itemType = $stmt->fetchAll();

$stmt = $conn->prepare("SELECT * FROM category_items WHERE type = '1'");
$stmt->execute();
$categories = $stmt->fetchAll();

// Conectar ao banco de dados
$database = new Database();
$db = $database->getConnection();

// Obter os detalhes do item
$id = $_GET['id'];
$sql = "SELECT * FROM items WHERE id = :id";
$stmt = $db->prepare($sql);
$stmt->bindParam(':id', $id);
$stmt->execute();
$item = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$item) {
    echo "Item não encontrado!";
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_item'])) {
    // Redirecionar para o script de exclusão de item
    header('Location: delete_item.php?id=' . $id);
    exit;
}

?>
<!DOCTYPE html>
<html lang="en" data-sidenav-size="fullscreen">

    <head>
        <meta charset="utf-8" />
        <title> <?php echo lang('Add Item'); ?> | <?php echo SITE_TITLE; ?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="<?php echo META_DESCRIPTION;?>" name="description" />
		<meta name="keywords" content="<?php echo META_KEYWORDS;?>">
        <meta content="SITE_TITLE" name="author" />

        <!-- App favicon -->
        <link rel="shortcut icon" href="assets/images/favicon.ico">

        <!-- Daterangepicker css -->
        <link rel="stylesheet" href="assets/vendor/daterangepicker/daterangepicker.css">

        <!-- Vector Map css -->
        <link rel="stylesheet" href="assets/vendor/admin-resources/jquery.vectormap/jquery-jvectormap-1.2.2.css">

        <!-- Theme Config Js -->
        <script src="assets/js/hyper-config.js"></script>

        <!-- App css -->
        <link href="assets/css/app-saas.min.css" rel="stylesheet" type="text/css" id="app-style" />
<script src="js/Chart.js"></script>
<script src="js/jquery.js"></script>
        <!-- Icons css -->
        <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    </head>

    <body>
        <!-- Begin page -->
        <div class="wrapper">

            <?php include 'includes/topbar.php';?> 

            <!-- ========== Left Sidebar Start ========== -->
            <div class="leftside-menu">

               

                

                <!-- Sidebar Hover Menu Toggle Button -->
                <div class="button-sm-hover" data-bs-toggle="tooltip" data-bs-placement="right" title="Show Full Sidebar">
                    <i class="ri-checkbox-blank-circle-line align-middle"></i>
                </div>

                <!-- Full Sidebar Menu Close Button -->
                <div class="button-close-fullsidebar">
                    <i class="ri-close-fill align-middle"></i>
                </div>

                <!-- Sidebar -left -->
                <div class="h-100" id="leftside-menu-container" data-simplebar>
                    <!-- Leftbar User -->
                    
<?php include 'includes/sidebar2.php';?>
                    <!--- End Sidemenu -->

                    <div class="clearfix"></div>
                </div>
            </div>
            <!-- ========== Left Sidebar End ========== -->

            <!-- ============================================================== -->
            <!-- Start Page Content here -->
            <!-- ============================================================== -->

            <div class="content-page" >
                <div class="content" >

                    <!-- Start Content-->
                    <div class="container-fluid" >

                        <div class="row">
                            <div class="col-8"  style="margin:0 auto;">
                                <div class="page-title-box">                                    
                                    <div class="page-title-right">
                                        <form class="d-flex">
											<button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#danger-header-modal">Delete</button>
                                        </form>
                                    </div>
                                    <h4 class="page-title"><?php echo lang('Edit Item'); ?></h4>
                                </div>
                            </div>
                        </div>

                        <div class="row">
						
						<div class="card col-xl-8 col-lg-8"  style="margin:0 auto;">
						<?php
						
							switch ($error) {
									
										case 1:
										?>
											<div class="alert alert-success" role="alert">
												<strong><?php echo lang('Item added successfully!') ?></strong>
											</div>
										<?php
										break;
										case 2:
										?>
											<div class="alert alert-danger bg-transparent text-danger" role="alert">
												<strong><?php echo lang('Invalid Item') ?></strong>
											</div>
										<?php
										break;
									default:
									
										break;
								}
						
						?>
							<form method="POST" action="update_item.php" enctype="multipart/form-data">
								<div class="mb-3">
									<input type="hidden" value="<?php echo $item['id']; ?>" name="id" id="simpleinput" class="form-control" required>
								</div>
								<div class="mb-3">
									<h4 for="simpleinput" class="form-label"><?php echo lang('Name'); ?>:</h4>
									<input type="text" value="<?php echo htmlspecialchars($item['name']); ?>" name="name" id="simpleinput" class="form-control" required>
								</div>
								
								<div class="mb-3">
									<label for="example-fileinput" class="form-label"><?php echo lang('Image'); ?>: (200x200)</label>
									<input type="file" id="example-fileinput" class="form-control" name="image">
									<img style="margin-top:10px !important;" src="<?php echo htmlspecialchars($item['image']); ?>"  width="200px"><br>
								</div>

								<h4 for="content"><?php echo lang('Description'); ?>:</h4>
								<textarea id="description" name="description" required><?php echo htmlspecialchars($item['description']); ?></textarea><br>
								
								<h4 for="content"><?php echo lang('Stats'); ?>:</h4>
								<textarea id="stats" name="stats" required><?php echo htmlspecialchars($item['stats']); ?></textarea><br>
								
								<h4 for="content"><?php echo lang('Conditions'); ?>:</h4>
								<textarea id="conditions" name="conditions" required><?php echo htmlspecialchars($item['conditions']); ?></textarea><br>
								
								<div class="mb-3">
									<label for="example-fileinput" class="form-label"><?php echo lang('Set'); ?>:</label>
										<select name="set" class="form-select mb-3" required>
										<option value="0"><?php echo lang('None'); ?></option>
										<?php foreach ($categories as $category): ?>
										<option value="<?php echo $category['id']; ?>"><?php echo $category['name']; ?></option>
									<?php endforeach; ?>
									</select>
								</div>
								
								<div class="mb-3">
									<label for="example-fileinput" class="form-label"><?php echo lang('Item Type'); ?>:</label>
										<select name="type" class="form-select mb-3" required>
										<?php foreach ($itemType as $category): ?>
											<option value="<?php echo $category['id']; ?>" <?php echo $category['id'] == $item['ItemType'] ? 'selected' : ''; ?>>
												<?php echo $category['name']; ?>
											</option>
										<?php endforeach; ?>
									</select>
								</div>
								
								<div class="mb-3">
									<label for="example-fileinput" class="form-label"><?php echo lang('Category'); ?>:</label>
										<select name="category" class="form-select mb-3" required>
										<?php foreach ($categories as $category): ?>
											<option value="<?php echo $category['id']; ?>" <?php echo $category['id'] == $item['category'] ? 'selected' : ''; ?>>
												<?php echo $category['name']; ?>
											</option>
										<?php endforeach; ?>
									</select>
								</div>
								
								<div class="mb-3">
									<label for="example-fileinput" class="form-label"><?php echo lang('Level'); ?>:</label>
									<input type="text" value="<?php echo htmlspecialchars($item['level']); ?>" name="level" id="simpleinput" class="form-control" required>
								</div>
								
								<div class="mb-3">
									<label for="example-fileinput" class="form-label"><?php echo lang('weight'); ?>:</label>
									<input type="text" name="weight"  value="<?php echo htmlspecialchars($item['weight']); ?>" id="simpleinput" class="form-control" required>
								</div>
								
								<div class="mb-3">
									<label for="example-fileinput" class="form-label"><?php echo lang('Max Socket'); ?>:</label>
									<input type="text" name="MaxSocket" value="<?php echo htmlspecialchars($item['MaxSocket']); ?>" id="simpleinput" class="form-control" required>
								</div>

								<div class="d-grid">
									<button type="submit" class="btn btn-lg btn-primary"><?php echo lang('Edit Item'); ?></button>
								</div>
							</form>

							<!-- Include a WYSIWYG editor -->
							<script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
							<script>
								CKEDITOR.replace('description');
								CKEDITOR.replace('stats');
								CKEDITOR.replace('conditions');
							</script>
                            

                       </div>


                    </div>
                    <!-- container -->
<div id="danger-header-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="danger-header-modalLabel" aria-hidden="true">
							<div class="modal-dialog">
								<div class="modal-content">
									<div class="modal-header bg-danger">
										<h4 class="modal-title" style="color: white;" id="danger-header-modalLabel">Warning: Post Deletion</h4>
										<button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"></button>
									</div>
									<div class="modal-body">
													<div class="mb-1">
														<label for="example-palaceholder" class="form-label">You are about to delete this item. This action is permanent and cannot be undone.</label>
													</div>
													<div class="mb-1">
														<label for="example-palaceholder" class="form-label">Are you sure you want to proceed?</label>
													</div>
										
                                                <!-- comment box -->
													
													
                                               
									</div>
									<div class="modal-footer">
										<button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
										<a Href="delete_item.php?id=<?php echo $item['id']; ?>" type="submit" class="btn btn-danger">Delete</a>
									</div>
									
									<!-- end .border-->
								</div><!-- /.modal-content -->
							</div><!-- /.modal-dialog -->
						</div><!-- /.modal -->
                </div>
                <!-- content -->

                

            </div>

            <!-- ============================================================== -->
            <!-- End Page content -->
            <!-- ============================================================== -->

        </div>
        <!-- END wrapper -->

        <!-- Vendor js -->
        <script src="assets/js/vendor.min.js"></script>

        <!-- Daterangepicker js -->
        <script src="assets/vendor/daterangepicker/moment.min.js"></script>
        <script src="assets/vendor/daterangepicker/daterangepicker.js"></script>
        
        <!-- Apex Charts js -->
        <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>

        <!-- Vector Map js -->
        <script src="assets/vendor/admin-resources/jquery.vectormap/jquery-jvectormap-1.2.2.min.js"></script>
        <script src="assets/vendor/admin-resources/jquery.vectormap/maps/jquery-jvectormap-world-mill-en.js"></script>

        <!-- Dashboard App js -->
        <script src="assets/js/pages/demo.dashboard.js"></script>

      

        <!-- Apex Chart Column Demo js -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/dayjs/1.11.0/dayjs.min.js"></script>  
        <script src="https://cdnjs.cloudflare.com/ajax/libs/dayjs/1.11.0/plugin/quarterOfYear.min.js"></script>        
        <!--<script src="assets/js/pages/demo.apex-column.js"></script> -->
		<?php
			include 'js/graficosCollum.php';
			//include 'js/graficospie.php';
			include 'js/graficosbar.php';
		?>

        <!-- Apex Chart Area Demo js -->
        <script src="assets/js/app.min.js"></script>

    </body>
</html> 