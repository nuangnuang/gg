<?php
require 'config.php';
require 'core/functions.php'; 
include 'language.php'; 
require 'libs/PHPMailer/src/Exception.php';
require 'libs/PHPMailer/src/PHPMailer.php';
require 'libs/PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = md5($_POST['password']); // Criptografar a senha
    $email = $_POST['email'];
	$authType = 1;

    // Verificar se o usuário já existe
    $db = new Database();
    $conn = $db->getConnection();

    $stmt = $conn->prepare("SELECT id FROM userlogin WHERE username = ?");
    $stmt->execute([$username]);
    $existingUser = $stmt->fetch();

    if ($existingUser) {
		header("Location: register.php?a=1");
        echo "Username already exists. Please choose another one.";
    } else {
		// Verificar se o email já existe
        $stmt = $conn->prepare("SELECT id FROM userlogin WHERE email = ?");
        $stmt->execute([$email]);
        $existingEmail = $stmt->fetch();

        if ($existingEmail) {
			header("Location: register.php?a=2");
            echo "Email already exists. Please use another one.";
        }else{
        // Gerar um ID único
        $id = Utils::generateId();

        // Inserir o novo usuário no banco de dados
        $stmt = $conn->prepare("INSERT INTO userlogin (id, username, password, email, authType) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$id, $username, $password, $email, $authType]);

        // Enviar email de ativação
        $activationLink = SITE_URL . "/activate.php?id=$id";
        $subject = "Account Activation";
        $body = "Click on the following link to activate your account: <a href=\"$activationLink\">$activationLink</a>";

        if (sendEmail($email, $subject, $body)) {
            echo "Your account has been created. Please check your email to activate it.";
        } else {
            echo "Failed to send activation email.";
			header("Location: register.php?a=3");
        }
    }
	
	}
}

// Função para enviar email
function sendEmail($to, $subject, $body) {
    $mail = new PHPMailer(true);

    try {
        // Configurações do servidor
        $mail->isSMTP();
        $mail->Host = EMAIL_HOST;
        $mail->SMTPAuth = true;
        $mail->Username = EMAIL_USER;
        $mail->Password = EMAIL_PASS;
        $mail->SMTPSecure = 'tls';
        $mail->Port = EMAIL_PORT;

        // Remetente
        $mail->setFrom(EMAIL_FROM, EMAIL_NAME);

        // Destinatário
        $mail->addAddress($to);

        // Conteúdo do email
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $body;

        $mail->send();
        return true;
    } catch (Exception $e) {
        return false;
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title><?php echo lang('Create Account'); ?> | <?php echo SITE_TITLE; ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="<?php echo META_DESCRIPTION;?>" name="description" />
		<meta name="keywords" content="<?php echo META_KEYWORDS;?>">
        <meta content="SITE_TITLE" name="author" />

    <!-- App favicon -->
    <link rel="shortcut icon" href="assets/images/favicon.ico">

    <!-- Theme Config Js -->
    <script src="assets/js/hyper-config.js"></script>

    <!-- App css -->
    <link href="assets/css/app-saas.min.css" rel="stylesheet" type="text/css" />

    <!-- Icons css -->
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
</head>

<body class="authentication-bg pb-0 ">

    <div class="auth-fluid">
        <!--Auth fluid left content -->
        <div class="auth-fluid-form-box ">
            <div class="card-body d-flex flex-column h-100 gap-3">

                <!-- Logo -->
                <div class="auth-brand text-center text-lg-start">
                    <a href="index.html" class="logo-dark">
                        <span><img src="assets/images/logo-dark.png" alt="dark logo" height="22"></span>
                    </a>
                    <a href="index.html" class="logo-light">
                        <span><img src="assets/images/logo.png" alt="logo" height="22"></span>
                    </a>
                </div>

                <div class="my-auto">
                    <!-- title-->
                    <h4 class="mt-3"><?php echo lang('CREATE AN ACCOUNT!') ?></h4>
                    <p class="text-muted mb-4"><?php echo lang('Don\'t have an account? Create your account, it takes less than a minute') ?></p>
								<?php
								
									// Verifica se o parâmetro 'token' está definido na URL
									if (isset($_GET['a'])) {
										// Recupera o valor do parâmetro 'token'
										$error = $_GET['a'];

									}

								switch ($error) {
									
										case 1:
										?>
											<div class="alert alert-danger bg-transparent text-danger" role="alert">
												<strong><?php echo lang('Username already exists. Please choose another one.') ?></strong>
											</div>
										<?php
										break;
										case 2:
										?>
											<div class="alert alert-danger bg-transparent text-danger" role="alert">
												<strong><?php echo lang('Email already exists. Please use another one.') ?></strong>
											</div>
										<?php
										break;
										case 3:
										?>
											<div class="alert alert-danger bg-transparent text-danger" role="alert">
												<strong><?php echo lang('Failed to send activation email.') ?></strong>
											</div>
										<?php
										break;
									default:
										break;
								}
								?>
                    <!-- form -->
                    <form method="POST" action="register.php">
                        <div class="mb-3">
                            <label for="fullname" class="form-label"><?php echo lang('Username') ?></label>
                            <input class="form-control" type="text" name="username" id="fullname" placeholder="<?php echo lang('Enter your username'); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="emailaddress" class="form-label"><?php echo lang('Email') ?></label>
                            <input class="form-control" type="email" name="email" id="emailaddress" required placeholder="<?php echo lang('Enter your email'); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label"><?php echo lang('Password') ?></label>
                            <input class="form-control" name="password" type="password" required id="password" placeholder="<?php echo lang('Enter your password'); ?>">
                        </div>
                        <div class="mb-3">
                            <div class="form-check">
                                <input type="checkbox" class="form-check-input" id="checkbox-signup" required>
                                <label class="form-check-label" for="checkbox-signup"><?php echo lang('I accept'); ?> <a href="javascript: void(0);" class="text-muted"><?php echo lang('Terms and Conditions'); ?></a></label>
                            </div>
                        </div>
                        <div class="mb-0 d-grid text-center">
                            <button class="btn btn-primary" type="submit"><i class="mdi mdi-account-circle"></i> <?php echo lang('Create Account'); ?> </button>
                        </div>
                        <!-- social-->
                        <div class="text-center mt-4">
                          
                        </div>
                    </form>
                    <!-- end form-->
                </div>

                <!-- Footer-->
                <footer class="footer footer-alt">
                    <p class="text-muted"><?php echo lang('Already have account?'); ?> <a href="login.php" class="text-muted ms-1"><b><?php echo lang('Log In'); ?></b></a></p>
                </footer>

            </div> <!-- end .card-body -->
        </div>
        <!-- end auth-fluid-form-box-->

        <!-- Auth fluid right content -->
        <!-- <div class="auth-fluid-right text-center">
            <div class="auth-user-testimonial">
                <h2 class="mb-3">I love the color!</h2>
                <p class="lead"><i class="mdi mdi-format-quote-open"></i> It's a elegent templete. I love it very much! . <i class="mdi mdi-format-quote-close"></i>
                </p>
                <p>
                    - Hyper Admin User
                </p>
            </div> end auth-user-testimonial
        </div>-->
        <!-- end Auth fluid right content -->
    </div>
    <!-- end auth-fluid-->
    <!-- Vendor js -->
    <script src="assets/js/vendor.min.js"></script>

    <!-- App js -->
    <script src="assets/js/app.min.js"></script>

</body>

</html>
