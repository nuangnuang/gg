<?php 
session_start();
require 'protected.php';
checkLogin();
checkUserLevel(5, 'index.php');
require 'config.php';
require 'core/functions.php'; 
require 'language.php';

$database = new Database();
$conn = $database->getConnection();

if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $sql = "DELETE FROM vouchers WHERE id = :id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    header("Location: voucher.php?a=2");
}


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $voucher_code = $_POST['voucher_code'];
    if (empty($voucher_code)) {
        $voucher_code = generateUniqueVoucherCode($conn);
    }
    $title = $_POST['title'];
    $content = $_POST['content'];
    $use_limit = $_POST['use_limit'];
    $end_time = $_POST['end_time'];
    $cash = $_POST['cash'];
    $gold = $_POST['gold'];
    $currency = $_POST['currency'];

    // Verifica se os usuários foram enviados
    $allowed_users = "";
    if (!empty($_POST['userIds'])) {
        $allowed_users = implode(',', $_POST['userIds']);
    }

    // Verifica se os itens foram enviados
    $items = "";
    if (!empty($_POST['itemIds']) && !empty($_POST['quantities'])) {
        $itemIds = $_POST['itemIds'];
        $quantities = $_POST['quantities'];

        // Verifica se itemIds[] e quantities[] têm o mesmo número de elementos
        if (count($itemIds) !== count($quantities)) {
            die("Erro: O número de IDs de itens e quantidades não corresponde.");
        }

        // Monta a string dos itens com as quantidades correspondentes
        for ($i = 0; $i < count($itemIds); $i++) {
            $itemId = $itemIds[$i];
            $quantity = $quantities[$i];
            $items .= "$itemId:$quantity:0:0.00:0:0.00:0:0:;";
        }
    }

    // Inserir os dados do voucher na tabela vouchers
    $stmt = $conn->prepare("INSERT INTO vouchers (voucher_code, title, content, use_limit, end_time, cash, gold, currency, allowed_users, items) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$voucher_code, $title, $content, $use_limit, $end_time, $cash, $gold, $currency, $allowed_users, $items]);
}
?>
<!DOCTYPE html>
<html lang="en" data-sidenav-size="fullscreen">

    <head>
        <meta charset="utf-8" />
        <title><?php echo SITE_TITLE; ?> | <?php echo lang('Voucher'); ?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="<?php echo META_DESCRIPTION;?>" name="description" />
		<meta name="keywords" content="<?php echo META_KEYWORDS;?>">
        <meta content="SITE_TITLE" name="author" />

        <!-- App favicon -->
        <link rel="shortcut icon" href="assets/images/favicon.ico">

        <!-- Daterangepicker css -->
        <link rel="stylesheet" href="assets/vendor/daterangepicker/daterangepicker.css">

        <!-- Vector Map css -->
        <link rel="stylesheet" href="assets/vendor/admin-resources/jquery.vectormap/jquery-jvectormap-1.2.2.css">

        <!-- Theme Config Js -->
        <script src="assets/js/hyper-config.js"></script>

        <!-- App css -->
        <link href="assets/css/app-saas.min.css" rel="stylesheet" type="text/css" id="app-style" />
<script src="js/Chart.js"></script>
<script src="js/jquery.js"></script>
        <!-- Icons css -->
        <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
		<!-- MDI Icons Demo js -->
        <script src="assets/js/pages/demo.materialdesignicons.js"></script>
		<style>
        .suggestions {
            border: 1px solid #ccc;
            display: none;
            position: absolute;
            background-color: white;
            z-index: 1000;
            max-height: 200px;
            overflow-y: auto;
        }

        .suggestions div {
            padding: 8px;
            cursor: pointer;
        }

        .suggestions div:hover {
            background-color: #f0f0f0;
        }

        #selectedItems, #selectedUsers {
            margin-top: 10px;
        }

        .selected-item, .selected-user {
            display: flex;
            align-items: center;
            margin-bottom: 5px;
        }

        .selected-item img, .selected-user img {
            max-width: 50px;
            max-height: 50px;
            margin-right: 10px;
        }

        .selected-item button, .selected-user button {
            margin-left: 10px;
        }
		.suggestions div img {
    max-width: 50px;
    max-height: 50px;
    margin-right: 10px;
}
    </style>
    <script>
        function showSuggestions(field, value) {
            if (value.length == 0) {
                document.getElementById(field + "Suggestions").innerHTML = "";
                document.getElementById(field + "Suggestions").style.display = "none";
                return;
            }

            const xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function () {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    document.getElementById(field + "Suggestions").innerHTML = xhr.responseText;
                    document.getElementById(field + "Suggestions").style.display = "block";
                }
            };
            xhr.open("GET", "get_" + field + ".php?q=" + encodeURIComponent(value), true);
            xhr.send();
        }

        function selectSuggestion(field, id, value, extra) {
            if (field === 'user') {
                var userIdInput = document.createElement("input");
                userIdInput.type = "hidden";
                userIdInput.name = "userIds[]";
                userIdInput.value = id;

                var userNameDisplay = document.createElement("span");
                userNameDisplay.textContent = value;

                var removeButton = document.createElement("button");
                removeButton.textContent = "Remove";
                removeButton.className = "btn btn-danger";
                removeButton.style.marginLeft = "10px";
                removeButton.onclick = function () {
                    this.parentNode.remove();
                    userIdInput.remove();
                };

                var newUserField = document.createElement("div");
                newUserField.className = "selected-user";
                newUserField.appendChild(userNameDisplay);
                newUserField.appendChild(removeButton);
                newUserField.appendChild(userIdInput);

                document.getElementById("selectedUsers").appendChild(newUserField);
                document.getElementById("allowedUsers").value = "";
            } else if (field === 'item') {
                document.getElementById("itemInput").value = "";

                var itemIdInput = document.createElement("input");
                itemIdInput.type = "hidden";
                itemIdInput.name = "itemIds[]";
                itemIdInput.value = id;

                var itemNameDisplay = document.createElement("h5");
                itemNameDisplay.textContent = value;
				itemNameDisplay.className = "card-title";
                itemNameDisplay.style.textAlign = "center";
                itemNameDisplay.style.marginTop = "5px";
				itemNameDisplay.style.width = "fit-content";
				itemNameDisplay.style.maxWidth = "100%";
                itemNameDisplay.style.overflow = "hidden";
                itemNameDisplay.style.textOverflow = "ellipsis";
                itemNameDisplay.style.whiteSpace = "nowrap";
                itemNameDisplay.style.display = "inline-block";
                itemNameDisplay.style.textAlign = "center";

                var itemImage = document.createElement("img");
                itemImage.src = extra;
                itemImage.alt = "Icon";
				itemImage.className = "card-img-top";
				

                var quantityInput = document.createElement("input");
                quantityInput.type = "number";
                quantityInput.min = "0";
                quantityInput.name = "quantities[]";
                quantityInput.placeholder = "Amount";
                quantityInput.className = "form-control";
                quantityInput.style.width = "100%";

                var removeButton = document.createElement("button");
                removeButton.textContent = "Remove";
                removeButton.className = "btn btn-danger";
                removeButton.style.marginTop = "4px";
                removeButton.onclick = function () {
                    this.parentNode.remove();
                    itemIdInput.remove();
                    quantityInput.remove();
                };

                var newItemField = document.createElement("div");
                newItemField.className = "col-sm-2 col-lg-2 card";
                newItemField.style.width = "120px";
                newItemField.appendChild(itemImage);
                newItemField.appendChild(itemNameDisplay);
                newItemField.appendChild(quantityInput);
                newItemField.appendChild(removeButton);
                newItemField.appendChild(itemIdInput);

                document.getElementById("selectedItems").appendChild(newItemField);
            }
            document.getElementById(field + "Suggestions").innerHTML = "";
            document.getElementById(field + "Suggestions").style.display = "none";
        }
    </script>
	<script>
    function generateVoucherCode() {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        let code = '';
        for (let i = 0; i < 16; i++) {
            if (i > 0 && i % 4 === 0) {
                code += '-';
            }
            code += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        document.getElementById('voucher_code').value = code;
    }
</script>
    </head>

    <body>
        <!-- Begin page -->
        <div class="wrapper">

            <?php include 'includes/topbar.php';?> 

            <!-- ========== Left Sidebar Start ========== -->
            <div class="leftside-menu">

                

                <!-- Sidebar Hover Menu Toggle Button -->
                <div class="button-sm-hover" data-bs-toggle="tooltip" data-bs-placement="right" title="Show Full Sidebar">
                    <i class="ri-checkbox-blank-circle-line align-middle"></i>
                </div>

                <!-- Full Sidebar Menu Close Button -->
                <div class="button-close-fullsidebar">
                    <i class="ri-close-fill align-middle"></i>
                </div>

                <!-- Sidebar -left -->
                <div class="h-100" id="leftside-menu-container" data-simplebar>
                    <!-- Leftbar User -->
                    <div class="leftbar-user">
                        <a href="pages-profile.html">
                            <img src="assets/images/users/avatar-1.jpg" alt="user-image" height="42" class="rounded-circle shadow-sm">
                            <span class="leftbar-user-name mt-2">Dominic Keller</span>
                        </a>
                    </div>

                    <!--- Sidemenu -->
<?php include 'includes/sidebar2.php';?>                         <!--- End Sidemenu -->

                    <div class="clearfix"></div>
                </div>
            </div>
            <!-- ========== Left Sidebar End ========== -->

            <!-- ============================================================== -->
            <!-- Start Page Content here -->
            <!-- ============================================================== -->

            <div class="content-page">
                <div class="content">

                    <!-- Start Content-->
                    <div class="container-fluid">

                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">                                    
                                    
                                    <h4 class="page-title"><?php echo lang('Voucher list'); ?></h4>
                                </div>


                            
                            </div>
                        </div>

                    <div class="row">
                        <div class="col-xl-12">
                            <div class="card">
							  <div id="message"></div>
							<?php
                            if (isset($_GET['a'])) {
                                $error = $_GET['a'];
                                switch ($error) {
                                    case 1:
                                        echo '<div class="alert alert-success" role="alert"><strong>' . lang('Category added successfully!') . '</strong></div>';
                                        break;
                                    case 2:
                                        echo '<div class="alert alert-danger bg-transparent text-danger" role="alert"><strong>' . lang('Deleted.') . '</strong></div>';
                                        break;
                                }
                            }
                            ?>
                                <div class="card-body">
                                    <h4 class="header-title mb-3"><?php echo lang('Add Voucher'); ?></h4>
                                    <form method="POST" >
										<div class="row">
                                                        <div class="col-md-6">
                                                            <div class="mb-3">
																<label for="voucher_code" class="form-label">Voucher Code:</label>
																<div class="input-group">
																	<input type="text" class="form-control" id="voucher_code" name="voucher_code" required>
																	<button type="button" class="btn btn-primary" onclick="generateVoucherCode()">Generate Code</button>
																</div>
															</div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="mb-3">
																<label for="title" class="form-label">Título:</label>
																<input type="text" class="form-control" id="title" name="title" required>
															</div>
                                                        </div> <!-- end col -->
                                        </div> <!-- end row -->
										<div class="row">
                                                        <div class="mb-3">
															<label for="content" class="form-label">Conteúdo:</label>
															<textarea class="form-control" id="content" name="content" required></textarea>
														</div>
                                        </div> <!-- end row -->
										<div class="row">
                                                        <div class="col-md-6">
                                                            <div class="mb-3">
																<label for="useLimit" class="form-label">Limite de Uso:</label>
																<input type="number" class="form-control" id="useLimit" name="use_limit" required>
															</div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="mb-3">
																<label for="endTime" class="form-label">Data de Expiração:</label>
																<input type="datetime-local" class="form-control" id="endTime" name="end_time" required>
															</div>
                                                        </div> <!-- end col -->
                                        </div> <!-- end row -->
										<div class="row">
                                                        <div class="col-md-6">
                                                            <div class="mb-3">
																<label for="cash" class="form-label">Cash:</label>
																<input type="number" class="form-control" id="cash" name="cash" required>
															</div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="mb-3">
																<label for="gold" class="form-label">Gold:</label>
																<input type="number" class="form-control" id="gold" name="gold" required>
															</div>
                                                        </div> <!-- end col -->
                                        </div> <!-- end row -->
										<div class="row">
                                                        <div class="mb-3">
															<label for="itemInput">Itens:</label>
															<input type="text" class="form-control" id="itemInput" name="itemName" onkeyup="showSuggestions('item', this.value)">
															<div id="itemSuggestions" class="suggestions"></div>
															<div id="selectedItems" class="row"></div>
														</div>
                                        </div> <!-- end row -->
										<div class="row">
                                                        <div class="col-md-6">
															<div class="mb-3">
																<label for="allowedUsers" class="form-label">Usuários Permitidos:</label>
																<input type="text" class="form-control" id="allowedUsers" name="allowed_users" onkeyup="showSuggestions('user', this.value)">
																<div id="userSuggestions" class="suggestions"></div>
																<div id="selectedUsers"></div>
															</div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="mb-3">
																<label for="currency" class="form-label">Moeda:</label>
																<input type="text" class="form-control" id="currency" name="currency" required>
															</div>
															<input type="hidden" name="action" value="create">
                                                        </div> <!-- end col -->
                                        </div> <!-- end row -->
                                        <button type="submit" class="btn btn-primary"><?php echo lang('Save'); ?></button>
                                    </form>
                                </div>
                            </div>
                        </div>
                   </div>
                        <!-- end row -->
                        <div class="row">
						<div class="col-lg-12">
                       <div class="card">
                         <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                        
                
                                                                                  
                        <script src="assets/js/pages/demo.datatable-init.js"></script>                            
							<table id="basic-datatable" class="table dt-responsive nowrap w-100">
								<thead>
									<tr>
										<th><?php echo lang('Title'); ?></th>
										<th><?php echo lang('Code'); ?></th>
										<th><?php echo lang('Limite'); ?></th>
										<th><?php echo lang('Users'); ?></th>
										<th><?php echo lang('Items'); ?></th>
										<th><?php echo lang('Cash'); ?></th>
										<th><?php echo lang('Gold'); ?></th>
										<th><?php echo lang('Expire'); ?></th>
										<th><?php echo lang('Action'); ?></th>
										
									</tr>
								</thead>


								<tbody>
								<?php
								
									if (isset($_GET['list']) & ($_GET['list'] == 'banned')) {
										$list = $_GET['list'];
										$list = filter_var($list, FILTER_SANITIZE_STRING);
										// Defina as condições desejadas como um array
										

										// Use a função fetchRecords para buscar registros em uma tabela com condições
										$result = fetchRecords('vouchers', '*', $conditions);
									
									}else{

										// Use a função fetchRecords para buscar registros em uma tabela com condições
										$result = fetchRecords('vouchers', '*');
									}

									foreach ($result as $row) {

								?>
									<tr>
										<td><a href="edit_item.php?id=<?php echo $row['id'];?>" class="link-primary"><strong><?php echo $row['title']; ?></strong></a></td>
										<td ><?php echo $row['voucher_code']; ?></td>
										<td><?php 
										
										if($row['claimed'] == null){
											$uses = 0;
										}else{
											$uses = 1;
										}
										
										if($row['use_limit'] != 0){
											$limit = $row['use_limit'];
										}else{
											$limit = html_entity_decode('&infin;');
										}
										
										echo $uses . ' / ' . $limit;
										//echo $row['use_limit'] . ' / ' . html_entity_decode('&infin;'); ?>
										</td>
										<td>
										<?php
										
											
											$allowed_users = explode(',', $row['allowed_users']);
											if (!empty($allowed_users[0])) {
												foreach ($allowed_users as $user) {
													//echo $user . "<br>";
													$conditionssss = ["id = '$user'"];
													$playersOnlines = fetchRecords('userlogin', '*', $conditionssss);
													foreach ($playersOnlines as $rowss) {
												?><a  href="perfil.php?id=<?php echo $user;?>" class="link-primary"><?php echo $rowss['username']; ?>, </a><?php
											
											}
													
												}
											} else {
												echo lang('All');
											}

										
										?></td>
										<td><?php
													
													$data= $row['items'];		
													
													if ($data !=''){
								
										
													// Explode a string em itens separados
													$items = explode(';', $data);

													// Inicializa um array para armazenar os IDs
													$ids = [];
													$quantities = [];

													// Loop através de cada item
													foreach ($items as $item) {
														// Ignora itens vazios (como o último, que pode ser vazio)
														if (!empty($item)) {
															// Explode o item em seus componentes
															$components = explode(':', $item);
															// Adiciona o primeiro componente (ID) ao array de IDs
															$ids[] = $components[0];
															$quantities[$components[0]] = $components[1];
														}
													}

													// Lista os IDs
													foreach ($ids as $id) {
														$conditionsss = ["id = '$id'"];
														$quantity = $quantities[$id];
													$cat = fetchRecords('items', '*', $conditionsss);
													foreach ($cat as $rows) {
												?><a data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="<?php echo $quantity . "x " . $rows['name']; ?>" href="perfil.php?id=<?php echo $id;?>" class="link-primary"><img src="<?php echo $rows['image']; ?>" style="width:25px; height:25px; margin:2px;"/></a><?php
											
											}
											}
													}else{
														echo lang('No items');
													}
										
										
										?></td>
										<td><?php echo $row['cash']; ?></td>
										<td><?php echo $row['gold']; ?></td>
										<td><?php echo $row['end_time']; ?></td>
										<td>
											<a href="voucher.php?delete=<?php echo $row['id'];?>" class="btn btn-sm btn-danger" onclick="return confirm('<?php echo lang('Are you sure you want to delete this voucher?'); ?>');"><?php echo lang('Delete'); ?></a>
										</td>
										
									</tr>
									
									<?php } ?>
									
								</tbody>
							</table>

                      </div> <!-- end card-body-->
                                </div> <!-- end card-->
                            </div> <!-- end col -->
                        </div>


           
                                </div>
                        </div>
						
                            
                        </div>
                        <!-- end row -->
						

                        <div class="row">
                            <div class="col-xl-12 col-lg-12 order-lg-2 order-xl-1">
                                <div class="card">
                                    <!-- Datatable Init js -->


            

                                    </div> <!-- end card-->
                            </div> <!-- end col-->


                           <!-- end col -->

                        </div>
                        <!-- end row -->

                    </div>
                    <!-- container -->

                </div>
                <!-- content -->

                

            </div>

            <!-- ============================================================== -->
            <!-- End Page content -->
            <!-- ============================================================== -->

        </div>
        <!-- END wrapper -->
		
		


        <!-- Vendor js -->
        <script src="assets/js/vendor.min.js"></script>

        <!-- Daterangepicker js -->
        <script src="assets/vendor/daterangepicker/moment.min.js"></script>
        <script src="assets/vendor/daterangepicker/daterangepicker.js"></script>
        
        <!-- Apex Charts js -->
        <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>

        <!-- Vector Map js -->
        <script src="assets/vendor/admin-resources/jquery.vectormap/jquery-jvectormap-1.2.2.min.js"></script>
        <script src="assets/vendor/admin-resources/jquery.vectormap/maps/jquery-jvectormap-world-mill-en.js"></script>

        <!-- Dashboard App js -->
        <script src="assets/js/pages/demo.dashboard.js"></script>

      <!-- Datatable js -->
        <script src="assets/vendor/datatables.net/js/jquery.dataTables.min.js"></script>
        <script src="assets/vendor/datatables.net-bs5/js/dataTables.bootstrap5.min.js"></script>
        <script src="assets/vendor/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
        <script src="assets/vendor/datatables.net-responsive-bs5/js/responsive.bootstrap5.min.js"></script>
        <script src="assets/vendor/jquery-datatables-checkboxes/js/dataTables.checkboxes.min.js"></script>

        <!-- Apex Chart Column Demo js -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/dayjs/1.11.0/dayjs.min.js"></script>  
        <script src="https://cdnjs.cloudflare.com/ajax/libs/dayjs/1.11.0/plugin/quarterOfYear.min.js"></script>        
        <!--<script src="assets/js/pages/demo.apex-column.js"></script> -->
		
 <script src="assets/js/pages/demo.customers.js"></script>
        <!-- Apex Chart Area Demo js -->
        <script src="assets/js/app.min.js"></script>

    </body>
</html> 