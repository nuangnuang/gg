<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mmm";

// Cria a conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verifica a conexão
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

$q = $_GET['q'];

$sql = "SELECT id, username FROM userlogin WHERE username LIKE ?";
$stmt = $conn->prepare($sql);
$search = "%$q%";
$stmt->bind_param("s", $search);
$stmt->execute();
$result = $stmt->get_result();

$suggestions = "";
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $suggestions .= "<div onclick='selectSuggestion(\"" . $row['id'] . "\", \"" . $row['username'] . "\")'>" . $row['username'] . "</div>";
    }
}

echo $suggestions;

$stmt->close();
$conn->close();
?>
