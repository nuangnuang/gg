<?php
session_start();
	require 'protected.php';
	checkLogin();
	checkUserLevel(5, 'index.php');
require 'config.php';
require 'core/functions.php'; 
require 'language.php';

$database = new Database();
$db = $database->getConnection();
$isEdit = false;
$category = ['id' => '', 'name' => ''];

// Verificar se estamos editando uma categoria
if (isset($_GET['id']) && isset($_GET['action']) && $_GET['action'] == 'edit') {
    $id = $_GET['id'];
    $isEdit = true;

    $sql = "SELECT * FROM categories WHERE id = :id";
    $stmt = $db->prepare($sql);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    $category = $stmt->fetch(PDO::FETCH_ASSOC);
}

$message = '';

// Processar o formulário de adição/edição
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $name = $_POST['name'];

    if ($id && $isEdit) {
        $sql = "UPDATE categories SET name = :name WHERE id = :id";
    } else {
        $sql = "INSERT INTO categories (name) VALUES (:name)";
    }

    $stmt = $db->prepare($sql);
    $stmt->bindParam(':name', $name);
    if ($id && $isEdit) {
        $stmt->bindParam(':id', $id);
    }

    if ($stmt->execute()) {
        $message = '<div class="alert alert-success alert-dismissible text-bg-success border-0 fade show" role="alert">
    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
    <strong>' . lang('Success - ') . '</strong> ' . lang('Category') . ' ' . ($isEdit ? lang('updated') : lang('add')) . ' ' . lang('successfully!') . '
</div>';
    } else {
        $message = '<div class="alert alert-danger alert-dismissible text-bg-danger border-0 fade show" role="alert">
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
            <strong>Error - </strong> Erro ao ' . ($isEdit ? 'atualizar' : 'adicionar') . ' a categoria.
        </div>';
    }
}

// Processar a exclusão de uma categoria
if (isset($_GET['id']) && isset($_GET['action']) && $_GET['action'] == 'delete') {
    $id = $_GET['id'];

    $sql = "DELETE FROM categories WHERE id = :id";
    $stmt = $db->prepare($sql);
    $stmt->bindParam(':id', $id);

    if ($stmt->execute()) {
        $message = '<div class="alert alert-success alert-dismissible text-bg-success border-0 fade show" role="alert">
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
            <strong>Success - </strong> Categoria deletada com sucesso!
        </div>';
    } else {
        $message = '<div class="alert alert-danger alert-dismissible text-bg-danger border-0 fade show" role="alert">
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
            <strong>Error - </strong> Erro ao deletar a categoria.
        </div>';
    }
}

// Recuperar todas as categorias para listagem
$sql = "SELECT * FROM categories";
$stmt = $db->prepare($sql);
$stmt->execute();
$categories = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>
<!DOCTYPE html>
<html lang="en" data-sidenav-size="fullscreen">

<head>
    <meta charset="utf-8" />
    <title><?php echo $isEdit ? 'Editar' : 'Adicionar'; ?> Categoria | <?php echo SITE_TITLE; ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="<?php echo META_DESCRIPTION;?>" name="description" />
		<meta name="keywords" content="<?php echo META_KEYWORDS;?>">
        <meta content="SITE_TITLE" name="author" />

    <!-- App favicon -->
    <link rel="shortcut icon" href="assets/images/favicon.ico">

    <!-- Daterangepicker css -->
    <link rel="stylesheet" href="assets/vendor/daterangepicker/daterangepicker.css">

    <!-- Vector Map css -->
    <link rel="stylesheet" href="assets/vendor/admin-resources/jquery.vectormap/jquery-jvectormap-1.2.2.css">

    <!-- Theme Config Js -->
    <script src="assets/js/hyper-config.js"></script>

    <!-- App css -->
    <link href="assets/css/app-saas.min.css" rel="stylesheet" type="text/css" id="app-style" />
    <script src="js/Chart.js"></script>
    <script src="js/jquery.js"></script>
    <!-- Icons css -->
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
</head>

<body>
    <!-- Begin page -->
    <div class="wrapper">

        <?php include 'includes/topbar.php'; ?> 

        <!-- ========== Left Sidebar Start ========== -->
        <div class="leftside-menu">

            <!-- Sidebar Hover Menu Toggle Button -->
            <div class="button-sm-hover" data-bs-toggle="tooltip" data-bs-placement="right" title="Show Full Sidebar">
                <i class="ri-checkbox-blank-circle-line align-middle"></i>
            </div>

            <!-- Full Sidebar Menu Close Button -->
            <div class="button-close-fullsidebar">
                <i class="ri-close-fill align-middle"></i>
            </div>

            <!-- Sidebar -left -->
            <div class="h-100" id="leftside-menu-container" data-simplebar>
                <!-- Leftbar User -->
                <?php include 'includes/sidebar2.php'; ?>
                <!--- End Sidemenu -->

                <div class="clearfix"></div>
            </div>
        </div>
        <!-- ========== Left Sidebar End ========== -->

        <!-- ============================================================== -->
        <!-- Start Page Content here -->
        <!-- ============================================================== -->

        <div class="content-page">
            <div class="content">

                <!-- Start Content-->
                <div class="container-fluid">

                    <div class="row">
                        <div class="col-8" style="margin:0 auto;">
                            <div class="page-title-box">
                                <?php if ($isEdit == true) { ?>
                                <div class="page-title-right">
                                    <div class="d-flex">
                                        <a href="manage_category.php" class="btn btn-primary">New</a>
                                    </div>
                                </div>
                                <?php } ?>
                                <h4 class="page-title"><?php echo $isEdit ? 'Editar' : 'Adicionar'; ?> Categoria</h4>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="card col-xl-8 col-lg-8" style="margin:0 auto;">
                            <?php if ($message) { echo $message; } ?>
                            <form method="post" action="manage_category.php<?php echo $isEdit ? '?id=' . $category['id'] . '&action=edit' : ''; ?>">
                                <div class="mb-3">
                                    <input type="hidden" name="id" value="<?php echo $category['id']; ?>">
                                    <h4 for="simpleinput" class="form-label"><?php echo lang('Name'); ?>:</h4>
                                    <input type="text" name="name" id="name" value="<?php echo $category['name']; ?>" class="form-control" required>
                                </div>
                                <div class="d-grid">
                                    <input type="submit" style="margin-bottom:20px;" class="btn btn-lg btn-primary" value="<?php echo $isEdit ? 'Atualizar' : 'Adicionar'; ?> Categoria">
                                </div>
                            </form>
                        </div>
                    </div>

                    <div class="row" style="margin-top: 20px;">
                        <div class="card col-xl-8 col-lg-8" style="margin:0 auto;padding-top: 20px;">
                            <script src="assets/js/pages/demo.datatable-init.js"></script>
                            <table id="basic-datatable" class="table table-striped table-centered mb-0">
                                <thead>
                                    <tr>
                                        <th><?php echo lang('Id'); ?></th>
                                        <th><?php echo lang('Name'); ?></th>
                                        <th style="text-align:right;"><?php echo lang('Action'); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($categories as $row): ?>
                                    <tr>
                                        <td><?php echo $row['id']; ?></td>
                                        <td><?php echo $row['name']; ?></td>
                                        <td style="text-align:right;">
                                            <a href="manage_category.php?id=<?php echo $row['id']; ?>&action=edit" class="action-icon"> <i class="mdi mdi-pencil"></i></a>
                                            <a href="manage_category.php?id=<?php echo $row['id']; ?>&action=delete" class="action-icon" onclick="return confirm('Você tem certeza que deseja deletar esta categoria?');"> <i class="mdi mdi-delete"></i></a>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- End Page content -->
        <!-- ============================================================== -->
    </div>
    <!-- END wrapper -->

    <!-- Theme JS -->
    <script src="assets/js/vendor.min.js"></script>

    <!-- Daterangepicker js -->
    <script src="assets/vendor/daterangepicker/moment.min.js"></script>
    <script src="assets/vendor/daterangepicker/daterangepicker.js"></script>

    <!-- Apex Charts js -->
    <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>

    <!-- Vector Map js -->
    <script src="assets/vendor/admin-resources/jquery.vectormap/jquery-jvectormap-1.2.2.min.js"></script>
    <script src="assets/vendor/admin-resources/jquery.vectormap/maps/jquery-jvectormap-world-mill-en.js"></script>

    <!-- Dashboard App js -->
    <script src="assets/js/pages/demo.dashboard.js"></script>

    <!-- Datatable js -->
    <script src="assets/vendor/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="assets/vendor/datatables.net-bs5/js/dataTables.bootstrap5.min.js"></script>
    <script src="assets/vendor/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
    <script src="assets/vendor/datatables.net-responsive-bs5/js/responsive.bootstrap5.min.js"></script>
    <script src="assets/vendor/jquery-datatables-checkboxes/js/dataTables.checkboxes.min.js"></script>

    <!-- Apex Chart Column Demo js -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/dayjs/1.11.0/dayjs.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/dayjs/1.11.0/plugin/quarterOfYear.min.js"></script>
    <!-- <script src="assets/js/pages/demo.apex-column.js"></script> -->
    <?php
        include 'js/graficosCollum.php';
        //include 'js/graficospie.php';
        include 'js/graficosbar.php';
    ?>

    <!-- Apex Chart Area Demo js -->
    <script src="assets/js/app.min.js"></script>

</body>
</html>
