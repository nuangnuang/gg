<?php
require 'config.php';
require 'core/functions.php';



// Processar o formulário
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id']; // Assumindo que o campo ID está presente no formulário
    
    $name = $_POST['name'];
    $description = $_POST['description'];
    $stats = $_POST['stats'];
    $set = $_POST['set'];
    $type = $_POST['type'];
    $weight = $_POST['weight'];
    $conditions = $_POST['conditions'];
    $level = $_POST['level'];
    $MaxSocket = $_POST['MaxSocket'];
    $category = $_POST['category']; // Supondo que você tenha um campo de seleção para a categoria
    $target_file = $_POST['existing_image']; // Defina o nome do arquivo corretamente

    $new_image = false;

    // Upload da imagem, se uma nova imagem for fornecida
    if (isset($_FILES["image"]) && $_FILES["image"]["error"] == 0) {
        $target_dir = "uploads/";
        $imageFileType = strtolower(pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION));
        $unique_name = "item_" . uniqid() . '.' . $imageFileType; // Prefixo adicionado ao nome único
        $target_file = $target_dir . $unique_name;

        // Verificar se o arquivo é uma imagem real
        $check = getimagesize($_FILES["image"]["tmp_name"]);
        if ($check !== false) {
            if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
                // Redimensionar a imagem
                resizeImage($target_file, $target_file, 200, 200);
                $new_image = true;
            } else {
                echo "Desculpe, houve um erro ao fazer upload do seu arquivo.";
                exit;
            }
        } else {
            echo "Arquivo não é uma imagem.";
            exit;
        }
    }

    // Atualizar dados no banco de dados usando a classe Database
    $database = new Database();
    $db = $database->getConnection();

    $sql = "UPDATE items SET 
                name = :name, 
                description = :description, 
                stats = :stats, 
                equipamentSet = :set, 
                itemType = :type, 
                weight = :weight, 
                conditions = :conditions, 
                MaxSocket = :MaxSocket, 
                category = :category, 
                level = :level";

    if ($new_image) {
        $sql .= ", image = :image";
    }

    $sql .= " WHERE id = :id";

    $stmt = $db->prepare($sql);
    $stmt->bindParam(':id', $id);
    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':description', $description);
    $stmt->bindParam(':stats', $stats);
    $stmt->bindParam(':set', $set);
    $stmt->bindParam(':type', $type);
    $stmt->bindParam(':weight', $weight);
    $stmt->bindParam(':conditions', $conditions);
    $stmt->bindParam(':MaxSocket', $MaxSocket);
    $stmt->bindParam(':category', $category);
    $stmt->bindParam(':level', $level);

    if ($new_image) {
        $stmt->bindParam(':image', $target_file);
    }

    if ($stmt->execute()) {
		header("Location: " . $_SERVER["HTTP_REFERER"]);
        echo "Item atualizado com sucesso!";
    } else {
        echo "Erro ao atualizar o item.";
    }
}
?>
