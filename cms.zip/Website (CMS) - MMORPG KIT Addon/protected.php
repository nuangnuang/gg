<?php
// functions.php




function checkLogin() {
    if (!isset($_SESSION['username'])) {
        header("Location: login.php");
        exit();
    }
}

function checkUserLevel($requiredLevel,$url) {
    if ($_SESSION['userLevel'] < $requiredLevel) {
        header("Location: $url"); // Página de acesso negado
        exit();
    }
}

?>