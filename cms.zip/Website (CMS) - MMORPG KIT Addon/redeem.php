<?php
session_start();
require 'protected.php';
checkLogin();
require 'config.php';
require 'core/functions.php';

$database = new Database();
$conn = $database->getConnection();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $voucher_code = $_POST['voucher_code'];
    $user_id = $_SESSION['user_id']; // Assumindo que o ID do usuário está armazenado na sessão
    $user_name = $_SESSION['user_name']; // Assumindo que o nome do usuário está armazenado na sessão

    $message = redeemVoucher($conn, $voucher_code, $user_id, $user_name);
}

function redeemVoucher($conn, $voucher_code, $user_id, $user_name) {
    // Verifica se o voucher existe e é válido
    $stmt = $conn->prepare("SELECT * FROM vouchers WHERE voucher_code = ?");
    $stmt->execute([$voucher_code]);
    $voucher = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$voucher) {
        return "Voucher inválido.";
    }

    // Verifica o limite de uso, se use_limit for 0, não há limite
    $claimed_users = explode(',', $voucher['claimed']);
    if ($voucher['use_limit'] != 0 && count($claimed_users) >= $voucher['use_limit']) {
        return "Este voucher atingiu o limite de uso.";
    }

    // Verifica se o voucher já expirou
    $current_time = date('Y-m-d H:i:s');
    if ($current_time > $voucher['end_time']) {
        return "Este voucher já expirou.";
    }

    // Verifica se o usuário já resgatou este voucher
    if (in_array($user_id, $claimed_users)) {
        return "Você já resgatou este voucher.";
    }

    // Marca o voucher como resgatado pelo usuário
    $claimed_users[] = $user_id;
    $claimed_users_str = implode(',', $claimed_users);
    $stmt = $conn->prepare("UPDATE vouchers SET claimed = ? WHERE id = ?");
    $stmt->execute([$claimed_users_str, $voucher['id']]);

    // Aplica os itens ao usuário
    $items = $voucher['items'];
    $title = $voucher['title'];
    $content = $voucher['content'];
    $gold = $voucher['gold'];
    $cash = $voucher['cash'];

    // Insere os dados na tabela mail
    $eventId = ''; // Gera um ID único para o evento
    $senderId = '0'; // Aqui você pode definir o ID do remetente conforme necessário
    $senderName = 'Sistema'; // Nome do remetente, pode ser ajustado
    $currencies = ''; // Defina o valor adequado para o campo 'currencies'

    $sql = "INSERT INTO mail (eventId, senderId, senderName, receiverId, title, content, gold, cash, items, currencies) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$eventId, $senderId, $senderName, $user_id, $title, $content, $gold, $cash, $items, $currencies]);

    return "Voucher resgatado com sucesso!";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Resgatar Voucher</title>
</head>
<body>
    <?php if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($message)): ?>
        <p><?php echo $message; ?></p>
    <?php endif; ?>
    <form action="" method="post">
        <label for="voucher_code">Código do Voucher:</label>
        <input type="text" id="voucher_code" name="voucher_code" required>
        <button type="submit">Resgatar</button>
    </form>
</body>
</html>
