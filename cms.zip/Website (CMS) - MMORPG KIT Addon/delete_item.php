<?php
session_start();
require 'protected.php';
checkLogin();
checkUserLevel(5, 'index.php');
require 'config.php';
require 'core/functions.php';
require 'language.php';

// Conectar ao banco de dados
$database = new Database();
$db = $database->getConnection();

// Verificar se o ID do item foi enviado via POST
if (1 == 1) {
    // Obter o ID do item a ser excluído
    $id = $_GET['id'];

    // Excluir o item do banco de dados
    $stmt = $db->prepare("DELETE FROM items WHERE id = :id");
    $stmt->bindParam(':id', $id);
    $stmt->execute();

    // Redirecionar de volta para a página de edição de itens com uma mensagem de sucesso
    header('Location: items.php');
    exit;
} else {
    // Redirecionar de volta para a página de edição de itens com uma mensagem de erro
    header('Location: items.php');
    exit;
}
?>
