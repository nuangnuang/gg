<?php
session_start();
require 'config.php';
require 'core/functions.php'; 

$db = new Database();
$conn = $db->getConnection();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = md5($_POST['password']); // Uso de MD5 conforme a tabela

    try {
        $stmt = $conn->prepare("SELECT * FROM userlogin WHERE username = ? AND password = ?");
        $stmt->execute([$username, $password]);

        if ($stmt->rowCount() === 1) {
            $user = $stmt->fetch();
            $_SESSION['username'] = $username;
            $_SESSION['userLevel'] = $user['userLevel'];
            $_SESSION['user_id'] = $user['id'];
			
            header("Location: index.php");
            exit();
        } else {
			header("Location: login.php?a=2");
            echo "Invalid login credentials.";
        }
		$_SESSION['userLevel'] = $user['userLevel'];
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}
?>
