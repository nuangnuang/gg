<?php
require 'config.php';
require 'core/functions.php'; 

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['token'];
    $newPassword = md5($_POST['new_password']); // Criptografar a nova senha

    // Verificar o token no banco de dados
    $db = new Database();
    $conn = $db->getConnection();

    $stmt = $conn->prepare("SELECT user_id FROM password_reset_tokens WHERE token = ? AND expires_at > NOW()");
    $stmt->execute([$token]);
    $resetToken = $stmt->fetch();

    if ($resetToken) {
        $userId = $resetToken['user_id'];

        // Atualizar a senha no banco de dados
        $stmt = $conn->prepare("UPDATE userlogin SET password = ? WHERE id = ?");
        $stmt->execute([$newPassword, $userId]);

        // Deletar o token após o uso
        $stmt = $conn->prepare("DELETE FROM password_reset_tokens WHERE token = ?");
        $stmt->execute([$token]);
		header("Location: login.php?a=1");
        echo "Your password has been reset successfully.";
    } else {
		header("Location: forgot_password.php?error=4");
        echo "Invalid or expired token.";
    }
} elseif (isset($_GET['token'])) {
$token = $_GET['token'];}
?>
