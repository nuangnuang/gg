<?php
session_start();
	require 'protected.php';
	checkLogin();
	checkUserLevel(5, 'index.php');
require 'config.php';
require 'core/functions.php'; 
require 'language.php';
// Fetch categories from the database
$db = new Database();
$conn = $db->getConnection();

$stmt = $conn->prepare("SELECT * FROM categories WHERE type = '0'");
$stmt->execute();
$categories = $stmt->fetchAll();

?><!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Cadastro de Itens</title>
    <script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
</head>
<body>
    <h1>Cadastro de Itens</h1>
    <form action="insert_item.php" method="post" enctype="multipart/form-data">
        <label for="id">ID:</label>
        <input type="text" name="id" id="id" required><br>
        
        <label for="nome">Nome:</label>
        <input type="text" name="nome" id="nome" required><br>
        
        <label for="image">Imagem:</label>
        <input type="file" name="image" id="image" required><br>
        
        <label for="description">Descrição:</label>
        <textarea name="description" id="description"></textarea><br>
        
        <label for="stats">Stats:</label>
        <textarea name="stats" id="stats"></textarea><br>
        
        <label for="set">Set:</label>
        <input type="text" name="set" value="0" id="set" hidden><br>
        
        <label for="type">Tipo:</label>
        <input type="text" name="type" id="type"><br>
		
		<label for="type">Category:</label>
        <input type="text" name="category" id="type"><br>
		
		<label for="type">Level:</label>
        <input type="text" name="level" id="type"><br>
        
        <label for="weight">Peso:</label>
        <input type="number" step="0.01" name="weight" id="weight"><br>
        
        <label for="conditions">Condições:</label>
        <textarea name="conditions" id="conditions"></textarea><br>
        
        <label for="MaxSocket">Max Socket:</label>
        <input type="number" name="MaxSocket" id="MaxSocket"><br>
        
        <input type="submit" value="Cadastrar">
    </form>

    <script>
        CKEDITOR.replace('description');
        CKEDITOR.replace('stats');
        CKEDITOR.replace('conditions');
    </script>
</body>
</html>
