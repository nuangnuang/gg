<?php
require 'config.php';
require 'core/functions.php'; 
	include 'language.php'; 

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newsId = $_POST['news_id'];
    $language = $_POST['language'];
    $title = $_POST['title'];
    $content = $_POST['content'];

    // Insert translation into the database
    $stmt = $conn->prepare("INSERT INTO news_translations (news_id, language, title, content) VALUES (?, ?, ?, ?)");
    $stmt->execute([$newsId, $language, $title, $content]);

    echo "Translation added successfully!";
}

// Fetch news from the database
$stmt = $conn->prepare("SELECT * FROM news");
$stmt->execute();
$news = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Translation</title>
</head>
<body>
    <h2>Add Translation</h2>
    <form method="post">
        <label for="news_id">News:</label>
        <select id="news_id" name="news_id" required>
            <?php foreach ($news as $item): ?>
                <option value="<?php echo $item['id']; ?>"><?php echo $item['title']; ?></option>
            <?php endforeach; ?>
        </select><br>

        <label for="language">Language:</label>
        <input type="text" id="language" name="language" required><br>

        <label for="title">Title:</label>
        <input type="text" id="title" name="title" required><br>

        <label for="content">Content:</label>
        <textarea id="content" name="content" required></textarea><br>

        <button type="submit">Add Translation</button>
    </form>

    <!-- Include a WYSIWYG editor -->
    <script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
    <script>
        CKEDITOR.replace('content');
    </script>
</body>
</html>
