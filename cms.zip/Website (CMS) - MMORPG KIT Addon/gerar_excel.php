<?php
require 'PhpSpreadsheet/src/PhpSpreadsheet/Spreadsheet.php';
require 'PhpSpreadsheet/src/PhpSpreadsheet/Writer/Xlsx.php';
require 'PhpSpreadsheet/src/PhpSpreadsheet/Writer/BaseWriter.php';
require 'PhpSpreadsheet/vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

// Conecta ao banco de dados
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "seu_banco_de_dados";
$dbh = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);

// Verifica se um bairro foi selecionado
$bairro = isset($_POST['bairro']) ? $_POST['bairro'] : '';

// Monta a consulta SQL com ou sem o filtro de bairro
$sql = "SELECT * FROM dados";
if (!empty($bairro)) {
    $sql .= " WHERE bairro = :bairro";
}
$sql .= " ORDER BY id DESC";

$stmt = $dbh->prepare($sql);

if (!empty($bairro)) {
    $stmt->bindParam(':bairro', $bairro, PDO::PARAM_STR);
}

$stmt->execute();
$info = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Cria uma nova planilha
$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();

// Define o cabeçalho
$sheet->setCellValue('A1', 'Nome');
$sheet->setCellValue('B1', 'Sexo');
$sheet->setCellValue('C1', 'Endereço');
$sheet->setCellValue('D1', 'Número da Casa');
$sheet->setCellValue('E1', 'Quantidade de Pessoas na Casa');
$sheet->setCellValue('F1', 'Telefone');
$sheet->setCellValue('G1', 'Idade');
$sheet->setCellValue('H1', 'Bairro');
$sheet->setCellValue('I1', 'Tipo');

// Preenche os dados na planilha
$rowIndex = 2; // Começa na segunda linha, após o cabeçalho

foreach ($info as $valor) {
    $sheet->setCellValue('A' . $rowIndex, $valor['nome']);
    $sheet->setCellValue('B' . $rowIndex, $valor['sexo']);
    $sheet->setCellValue('C' . $rowIndex, $valor['endereco']);
    $sheet->setCellValue('D' . $rowIndex, $valor['numero_casa']);
    $sheet->setCellValue('E' . $rowIndex, $valor['quantidade_pessoas_casa']);
    $sheet->setCellValue('F' . $rowIndex, $valor['telefone']);
    $sheet->setCellValue('G' . $rowIndex, $valor['idade']);
    $sheet->setCellValue('H' . $rowIndex, $valor['bairro']);

    // Obtém os tipos associados
    $idfiltro = $valor['id'];
    $sql_tipo = "SELECT DISTINCT p.tipo AS tipo
                 FROM dados u
                 JOIN posts p ON u.id = p.user_id
                 WHERE u.id = :id";
    $stmt_tipo = $dbh->prepare($sql_tipo);
    $stmt_tipo->bindValue(':id', $idfiltro);
    $stmt_tipo->execute();
    $tipos = [];
    while ($row = $stmt_tipo->fetch(PDO::FETCH_ASSOC)) {
        $tipos[] = $row['tipo'];
    }
    $sheet->setCellValue('I' . $rowIndex, implode(', ', $tipos));

    $rowIndex++;
}

// Gera o arquivo Excel
$writer = new Xlsx($spreadsheet);
$fileName = 'dados_filtrados.xlsx';

header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment; filename="' . $fileName . '"');
header('Cache-Control: max-age=0');

$writer->save('php://output');
?>
