<?php
	class Database {
		private $dbh;

		public function __construct() {
			// Configuração da conexão PDO
			$dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME;
			$options = [
				PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
				PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
				PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"
			];

			// Inicialização da conexão PDO
			try {
				$this->dbh = new PDO($dsn, DB_USER, DB_PASS, $options);
			} catch (PDOException $e) {
				throw new Exception("Failed to connect to database: " . $e->getMessage());
			}
		}

		public function getConnection() {
			return $this->dbh;
		}
	}
	
	class Utils {
    public static function generateId($alphabet = "_-0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ", $size = 21) {
        $id = '';
        $alphabetLength = strlen($alphabet);
        for ($i = 0; $i < $size; $i++) {
            $index = random_int(0, $alphabetLength - 1);
            $id .= $alphabet[$index];
        }
        return $id;
    }
}
?>