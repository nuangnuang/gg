<?php
	
	require_once 'class.php';
	
try {
		// Inicialize a conexão com o banco de dados
		$db = new Database();
		$dbh = $db->getConnection();
		// Agora $dbh contém a conexão PDO e pode ser usado para executar consultas
	} catch (Exception $e) {
		echo "Error: " . $e->getMessage();
		// Lidar com o erro de conexão com o banco de dados
	}

function deleteRecord($table, $conditions) {
    // Instanciar a classe Database
    $database = new Database();
    $db = $database->getConnection();

    // Construir a consulta SQL
    $sql = "DELETE FROM $table WHERE ";

    // Construir a cláusula WHERE dinamicamente
    $whereClauses = [];
    $params = [];
    foreach ($conditions as $field => $value) {
        $whereClauses[] = "$field = :$field";
        $params[":$field"] = $value;
    }
    $sql .= implode(' AND ', $whereClauses);

    // Preparar e executar a instrução SQL
    $stmt = $db->prepare($sql);

    return $stmt->execute($params);
}
// Função para contar o número de registros em uma tabela
function countRecords($table, $conditions = []) {


    try {
        // Inicialize a conexão com o banco de dados
        $db = new Database(DB_HOST, DB_NAME, DB_USER, DB_PASS);
        $dbh = $db->getConnection();

        // Construir a consulta SQL
        $sql = "SELECT COUNT(*) as count FROM $table";

        // Adicionar condições, se houver
        if (!empty($conditions)) {
            $sql .= " WHERE " . implode(" AND ", $conditions);
        }

        // Preparar e executar a consulta
        $stmt = $dbh->prepare($sql);
        $stmt->execute();

        // Obter o resultado
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        // Retornar o número de registros
        return $result['count'];
    } catch (PDOException $e) {
        throw new Exception("Erro ao contar registros: " . $e->getMessage());
    }
}

// Função para buscar registros em uma tabela com condições opcionais
function fetchRecords($table, $columns = '*', $conditions = []) {

    try {
        // Inicialize a conexão com o banco de dados
        $db = new Database(DB_HOST, DB_NAME, DB_USER, DB_PASS);
        $dbh = $db->getConnection();

        // Construir a consulta SQL
        $sql = "SELECT $columns FROM $table";

        // Adicionar condições, se houver
        if (!empty($conditions)) {
            $sql .= " WHERE " . implode(" AND ", $conditions);
        }

        // Preparar e executar a consulta
        $stmt = $dbh->prepare($sql);
        $stmt->execute();

        // Retornar os resultados
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        throw new Exception("Erro ao buscar registros: " . $e->getMessage());
    }
}

// Função para buscar registros em uma tabela com condições opcionais
function fetchRank($table, $columns = '*', $conditions = []) {

    try {
        // Inicialize a conexão com o banco de dados
        $db = new Database(DB_HOST, DB_NAME, DB_USER, DB_PASS);
        $dbh = $db->getConnection();

        // Construir a consulta SQL
        $sql = "SELECT $columns FROM $table";

        // Adicionar condições, se houver
        if (!empty($conditions)) {
            $sql .= " WHERE " . implode(" AND ", $conditions);
        }
		// Adicionar LIMIT 1 para retornar apenas o primeiro registro encontrado
        $sql .= " ORDER BY level DESC LIMIT 10";
        // Preparar e executar a consulta
        $stmt = $dbh->prepare($sql);
        $stmt->execute();

        // Retornar os resultados
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        throw new Exception("Erro ao buscar registros: " . $e->getMessage());
    }
}

// Função para buscar um único registro em uma tabela com condições opcionais
function fetchRecord($table, $columns = '*', $conditions = []) {

    try {
        // Inicialize a conexão com o banco de dados
        $db = new Database(DB_HOST, DB_NAME, DB_USER, DB_PASS);
        $dbh = $db->getConnection();

        // Construir a consulta SQL
        $sql = "SELECT $columns FROM $table";

        // Adicionar condições, se houver
        if (!empty($conditions)) {
            $sql .= " WHERE " . implode(" AND ", $conditions);
        }

        // Adicionar LIMIT 1 para retornar apenas o primeiro registro encontrado
        $sql .= " LIMIT 1";

        // Preparar e executar a consulta
        $stmt = $dbh->prepare($sql);
        $stmt->execute();

        // Retornar o primeiro resultado
        return $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        throw new Exception("Erro ao buscar registro: " . $e->getMessage());
    }
}


function getUncheckedInt32($r) {
    $r = $r & 0xFFFFFFFF;
    if ($r & 0x80000000)
    {
        $r = $r & ~0x80000000;
        $r = -2147483648 + $r;
    }
    return $r;
}

function getStableHash($str) {
    $id = str_split($str);
    $hash1 = (int)5381;
    $hash2 = $hash1;
    $len = count($id);
    $end = 0;
    for ($i = 0; $i < $len && ord($id[$i]) != $end; $i += 2)
    {
        $char = ord($id[$i]);
        $hash1 = getUncheckedInt32(getUncheckedInt32(getUncheckedInt32($hash1 << 5) + $hash1) ^ $char);
        $char = ord($id[$i + 1]);
        if ($i == $len - 1 || $char == $end)
            break;
        $hash2 = getUncheckedInt32(getUncheckedInt32(getUncheckedInt32($hash2 << 5) + $hash2) ^ $char);
    }

    return getUncheckedInt32($hash1 + getUncheckedInt32($hash2 * 1566083941));
}

function processArrayClass($arr) {
    $result = [];

    foreach ($arr as $value) {
        $result[getStableHash($value)] = $value;
    }

    return $result;
}

function printDataForKey($key, $resultArray) {
    if (array_key_exists($key, $resultArray)) {
        echo $resultArray[$key];
    } else {
        echo "Chave $key não encontrada no array.";
    }
}

function getDataForKey($key, $resultArray) {
    if (array_key_exists($key, $resultArray)) {
        return $resultArray[$key];
    } else {
        return null; // ou qualquer outro valor que você deseje retornar se a chave não for encontrada
    }
}

    // Função para gerar um nome aleatório para as imagens
    function generateRandomName($prefix, $extension) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $randomString = '';
        for ($i = 0; $i < 10; $i++) {
            $randomString .= $characters[rand(0, strlen($characters) - 1)];
        }
        return $prefix . '_' . $randomString . '.' . $extension;
    }

// Função para buscar registros em uma tabela com condições opcionais
function fetchNews($table, $columns = '*', $conditions = []) {

    try {
        // Inicialize a conexão com o banco de dados
        $db = new Database(DB_HOST, DB_NAME, DB_USER, DB_PASS);
        $dbh = $db->getConnection();

        // Construir a consulta SQL
        $sql = "SELECT $columns FROM $table";

        // Adicionar condições, se houver
        if (!empty($conditions)) {
            $sql .= " WHERE " . implode(" AND ", $conditions);
        }
		$sql .= " ORDER BY created_at DESC";
        // Preparar e executar a consulta
        $stmt = $dbh->prepare($sql);
        $stmt->execute();

        // Retornar os resultados
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        throw new Exception("Erro ao buscar registros: " . $e->getMessage());
    }
}
// Função para redimensionar imagem
function resizeImage($sourcePath, $destPath, $width, $height, $quality = 100) {
    $imageInfo = getimagesize($sourcePath);
    $sourceWidth = $imageInfo[0];
    $sourceHeight = $imageInfo[1];
    
    switch ($imageInfo['mime']) {
        case 'image/jpeg':
            $sourceImage = imagecreatefromjpeg($sourcePath);
            break;
        case 'image/png':
            $sourceImage = imagecreatefrompng($sourcePath);
            break;
        case 'image/gif':
            $sourceImage = imagecreatefromgif($sourcePath);
            break;
        default:
            throw new Exception('Unsupported image type');
    }

    $destImage = imagecreatetruecolor($width, $height);
    imagecopyresampled($destImage, $sourceImage, 0, 0, 0, 0, $width, $height, $sourceWidth, $sourceHeight);

    switch ($imageInfo['mime']) {
        case 'image/jpeg':
            imagejpeg($destImage, $destPath, $quality);
            break;
        case 'image/png':
            imagepng($destImage, $destPath, 9 - round($quality / 10)); // O valor da qualidade do PNG varia de 0 a 9
            break;
        case 'image/gif':
            imagegif($destImage, $destPath);
            break;
    }

    imagedestroy($sourceImage);
    imagedestroy($destImage);
}

/* function generateUniqueVoucherCode($conn) {
    $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    do {
        $code = '';
        for ($i = 0; $i < 16; $i++) {
            if ($i > 0 && $i % 4 === 0) {
                $code .= '-';
            }
            $code .= $chars[rand(0, strlen($chars) - 1)];
        }

        $stmt = $conn->prepare("SELECT COUNT(*) FROM vouchers WHERE voucher_code = ?");
        $stmt->execute([$code]);
        $count = $stmt->fetchColumn();
    } while ($count > 0);

    return $code;
} */



?>