<?php
session_start();
require 'protected.php';
checkLogin();
checkUserLevel(5, 'index.php');
require 'config.php';
require 'core/functions.php';
require 'language.php';

class Voucher {
    private $conn;

    public function __construct($conn) {
        $this->conn = $conn;
    }

    public function generateUniqueVoucherCode() {
        $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        do {
            $code = '';
            for ($i = 0; $i < 16; $i++) {
                if ($i > 0 && $i % 4 === 0) {
                    $code .= '-';
                }
                $code .= $chars[rand(0, strlen($chars) - 1)];
            }

            $stmt = $this->conn->prepare("SELECT COUNT(*) FROM vouchers WHERE voucher_code = ?");
            $stmt->execute([$code]);
            $count = $stmt->fetchColumn();
        } while ($count > 0);

        return $code;
    }

    public function createVoucher($data) {
        $voucher_code = empty($data['voucher_code']) ? $this->generateUniqueVoucherCode() : $data['voucher_code'];
        $title = $data['title'];
        $content = $data['content'];
        $use_limit = $data['useLimit'];
        $end_time = $data['endTime'];
        $cash = $data['cash'];
        $gold = $data['gold'];
        $currency = $data['currency'];
        $allowed_users = isset($data['userIds']) ? implode(',', $data['userIds']) : null;
        $itemIds = $data['itemIds'];
        $quantities = $data['quantities'];

        if (count($itemIds) !== count($quantities)) {
            return lang("O número de IDs de itens e quantidades não corresponde.");
        }

        $items = "";
        for ($i = 0; $i < count($itemIds); $i++) {
            $itemId = $itemIds[$i];
            $quantity = $quantities[$i];
            $items .= "$itemId:$quantity:0:0.00:0:0.00:0:0:;";
        }

        $stmt = $this->conn->prepare("INSERT INTO vouchers (voucher_code, title, content, use_limit, end_time, cash, gold, currency, allowed_users, items) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$voucher_code, $title, $content, $use_limit, $end_time, $cash, $gold, $currency, $allowed_users, $items]);

        return lang("Voucher criado com sucesso!");
    }

    public function redeemVoucher($voucher_code, $receiverId) {
        $stmt = $this->conn->prepare("SELECT * FROM vouchers WHERE voucher_code = ?");
        $stmt->execute([$voucher_code]);
        $voucher = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$voucher) {
            return lang("Voucher não encontrado.");
        }

        $allowed_users = explode(',', $voucher['allowed_users']);
        if (!in_array($receiverId, $allowed_users) && !empty($voucher['allowed_users'])) {
            return lang("Você não está autorizado a usar este voucher.");
        }

        $claimed_users = explode(',', $voucher['claimed']);
        if ($voucher['use_limit'] > 0 && count($claimed_users) >= $voucher['use_limit']) {
            return lang("Limite de uso do voucher atingido.");
        }

        if (in_array($receiverId, $claimed_users)) {
            return lang("Você já utilizou este voucher.");
        }

        $claimed_users[] = $receiverId;
        $new_claimed = implode(',', $claimed_users);

        $stmt = $this->conn->prepare("UPDATE vouchers SET claimed = ? WHERE voucher_code = ?");
        $stmt->execute([$new_claimed, $voucher_code]);

        // Enviar itens e recompensas para o usuário
        $items = $voucher['items'];
        $cash = $voucher['cash'];
        $gold = $voucher['gold'];
        $title = $voucher['title'];
        $content = $voucher['content'];
        $senderId = 0;
        $senderName = "Sistema";
        $eventId = '';

        $sql = "INSERT INTO mail (eventId, senderId, senderName, receiverId, title, content, gold, cash, items, currencies) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute([$eventId, $senderId, $senderName, $receiverId, $title, $content, $gold, $cash, $items, '']);

        return lang("Voucher resgatado com sucesso!");
    }

    public function deleteVoucher($voucher_id) {
        $stmt = $this->conn->prepare("DELETE FROM vouchers WHERE id = ?");
        $stmt->execute([$voucher_id]);

        return lang("Voucher excluído com sucesso!");
    }
}

try {
    $database = new Database();
    $conn = $database->getConnection();
    $voucher = new Voucher($conn);

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $action = $_POST['action'];
        $data = $_POST;

        switch ($action) {
            case 'create':
                $message = $voucher->createVoucher($data);
                break;
            case 'redeem':
                $voucher_code = $data['voucher_code'];
                $receiverId = $data['receiverId'];
                $message = $voucher->redeemVoucher($voucher_code, $receiverId);
                break;
            case 'delete':
                $voucher_id = $data['voucher_id'];
                $message = $voucher->deleteVoucher($voucher_id);
                break;
            default:
                $message = lang("Ação inválida.");
        }

        echo json_encode(['message' => $message]);
    }
} catch (Exception $e) {
    echo json_encode(['message' => lang("Erro: ") . $e->getMessage()]);
}
?>
