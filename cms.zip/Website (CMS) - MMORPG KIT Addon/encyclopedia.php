<?php 

	require 'protected.php';
include 'config.php';
	require 'core/functions.php'; 
	include 'language.php'; 

	

?>
<!DOCTYPE html>
<html lang="en" data-layout="topnav">

    <head>
        <meta charset="utf-8" />
        <title><?php echo SITE_TITLE; ?> | <?php echo lang('Items'); ?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="<?php echo META_DESCRIPTION;?>" name="description" />
		<meta name="keywords" content="<?php echo META_KEYWORDS;?>">
        <meta content="SITE_TITLE" name="author" />

        <!-- App favicon -->
        <link rel="shortcut icon" href="assets/images/favicon.ico">

        <!-- Daterangepicker css -->
        <link rel="stylesheet" href="assets/vendor/daterangepicker/daterangepicker.css">

        <!-- Vector Map css -->
        <link rel="stylesheet" href="assets/vendor/admin-resources/jquery.vectormap/jquery-jvectormap-1.2.2.css">
        <link rel="stylesheet" href="assets/vendor/admin-resources/jquery.vectormap/jquery-jvectormap-1.2.2.css">

        <!-- Theme Config Js -->
        <script src="assets/js/hyper-config.js"></script>

        <!-- App css -->
        <link href="assets/css/app-saas.min.css" rel="stylesheet" type="text/css" id="app-style" />
<script src="js/Chart.js"></script>
<script src="js/jquery.js"></script>
        <!-- Icons css -->
        <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
		<!-- MDI Icons Demo js -->
        <script src="assets/js/pages/demo.materialdesignicons.js"></script>
    </head>

    <body>
        <!-- Begin page -->
        <div class="wrapper">

            

		<?php include('includes/topnav.php'); ?>

            <!-- ============================================================== -->
            <!-- Start Page Content here -->
            <!-- ============================================================== -->

            <div class="content-page" style="max-width: 1500px; margin:0 auto;">
                <div class="content">

                    <!-- Start Content-->
                    <div class="container-fluid">

                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">                                    
                                    
                                    <h4 class="page-title"><?php echo lang('Encyclopedia'); ?></h4>
                                </div>
                            </div>
                        </div>


                        <div class="row">
						<div class="col-lg-9">
                       <div class="card">
                         <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                        
                
                                                                                  
                        <script src="assets/js/pages/demo.datatable-init.js"></script>                            
							<table id="basic-datatable" class="table dt-responsive nowrap w-100">
								<thead>
									<tr>
										<th><?php echo lang('Username'); ?></th>
										<th><?php echo lang('Type'); ?></th>
										<th><?php echo lang('Category'); ?></th>
										<th><?php echo lang('Set'); ?></th>
										<th><?php echo lang('Level'); ?></th>
										
									</tr>
								</thead>


								<tbody>
								<?php
								
									if (isset($_GET['category_id'])) {
										$list = $_GET['category_id'];
										$list = filter_var($list, FILTER_SANITIZE_STRING);
										// Defina as condições desejadas como um array
										$conditionsss = ["category = '$list'"];

										// Use a função fetchRecords para buscar registros em uma tabela com condições
										$result = fetchRecords('items', '*', $conditionsss);
									
									}else{

										// Use a função fetchRecords para buscar registros em uma tabela com condições
										$result = fetchRecords('items', '*');
									}

									foreach ($result as $row) {

								?>
									<tr>
										<td><a href="item_view.php?id=<?php echo $row['id'];?>" class="link-primary"><img src="<?php echo $row['image']; ?>" style="height: 40px !important; width:40px !important; margin-right:10px;" /><?php echo $row['name']; ?></a></td>
										<td><?php
										
											$typeId = $row['ItemType'];
											if ($typeId != 0){
											$conditionsss = ["id = '$typeId'"];
											$cat = fetchRecords('category_items', '*', $conditionsss);
											foreach ($cat as $rows) {
												?><?php echo $rows['name']; ?><?php
											
											}
											}else{
												echo lang('No Category');
											}
										
										?></td>
										<td>
										<?php
										
											$categoryId = $row['category'];
											if ($categoryId != 0){
											$conditionsss = ["id = '$categoryId'"];
											$cat = fetchRecords('category_items', '*', $conditionsss);
											foreach ($cat as $rows) {
												?><a href="encyclopedia.php?category_id=<?php echo $categoryId;?>" class="link-primary"><?php echo $rows['name'];; ?></a><?php
											
											}
											}else{
												echo lang('No Category');
											}
										
										?></td>
										<td><?php echo $row['equipamentSet']; ?></td>
										<td><?php echo $row['level']; ?>
										</td>
										
									</tr>
									
									<?php } ?>
									
								</tbody>
							</table>

                      </div> <!-- end card-body-->
                                </div> <!-- end card-->
                            </div> <!-- end col -->
                        </div>


           
                                </div>
                        </div>
						<div class="col-xl-3 col-lg-6 order-lg-1">
                                <div class="card">
                                    <div class="card-body pb-0">
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <h4 class="header-title">Item Type</h4>
                                        </div>
                                    </div>

                                    <div class="card-body py-0 mb-3" data-simplebar> 
									<?php
$database = new Database(); // Instancia a classe Database
$db = $database->getConnection(); // Obtém a conexão com o banco de dados

// Função para obter as categorias
function getCategories($db) {
    $stmt = $db->prepare("SELECT * FROM category_items ORDER BY type, itemType");
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Recupera todas as categorias
$categories = getCategories($db);

// Organiza as categorias em um array associativo com pais e filhos
$categoryTree = [];
foreach ($categories as $category) {
    if ($category['type'] == 0) { // Pai
        $categoryTree[$category['id']] = [
            'name' => $category['name'],
            'children' => []
        ];
    } else { // Filho
        if (isset($categoryTree[$category['itemType']])) {
            $categoryTree[$category['itemType']]['children'][] = $category;
        }
    }
}

// Função para gerar o HTML do menu
function renderMenu($categoryTree) {
    $menuHtml = '<ul class="side-nav">';
    foreach ($categoryTree as $id => $category) {
        $menuHtml .= '<li class="side-nav-item">';
        $menuHtml .= '<a data-bs-toggle="collapse" href="#category_' . $id . '" aria-expanded="false" aria-controls="category_' . $id . '" class="side-nav-link">';
        
        // Switch case para definir a classe do ícone com base no nome da categoria
        switch ($category['name']) {
            case 'Weapons':
                $menuHtml .= '<i class="mdi mdi-sword"></i>';
                break;
            case 'Equipaments':
                $menuHtml .= '<i class="mdi mdi-ring"></i>';
                break;
            case 'Consumables':
                $menuHtml .= '<i class="uil uil-flask-potion"></i>';
                break;
            default:
                $menuHtml .= '<i class="mdi mdi-folder"></i>';
                break;
        }

        $menuHtml .= '<span> ' . $category['name'] . ' </span>';
        $menuHtml .= '<span class="menu-arrow"></span>';
        $menuHtml .= '</a>';
        $menuHtml .= '<div class="collapse" id="category_' . $id . '">';
        $menuHtml .= '<ul class="side-nav-second-level">';
        // Adiciona a opção "All" em todas as categorias pai
        ///$menuHtml .= '<li>';
        //$menuHtml .= '<a href="encyclopedia.php?category_id=' . $id . '">All</a>';
        //$menuHtml .= '</li>';
        foreach ($category['children'] as $child) {
            $menuHtml .= '<li>';
            $menuHtml .= '<a href="encyclopedia.php?category_id=' . $child['id'] . '">' . $child['name'] . '</a>';
            $menuHtml .= '</li>';
        }
        $menuHtml .= '</ul>';
        $menuHtml .= '</div>';
        $menuHtml .= '</li>';
    }
    $menuHtml .= '</ul>';
    return $menuHtml;
}

$menuHtml = renderMenu($categoryTree);
?>
<div class="wrapper">
        <!-- Menu de Categorias -->
        <?php echo $menuHtml; ?>

        <!-- Seu conteúdo aqui -->

    </div>

       
                                        <!-- end timeline -->
                                    </div> <!-- end slimscroll -->
                                </div>
                                <!-- end card-->
                            </div>
                            <!-- end col -->
                            
                        </div>
                        <!-- end row -->

                        <div class="row">
                            <div class="col-xl-12 col-lg-12 order-lg-2 order-xl-1">
                                <div class="card">
                                    <!-- Datatable Init js -->


            

                                    </div> <!-- end card-->
                            </div> <!-- end col-->


                           <!-- end col -->

                        </div>
                        <!-- end row -->

                    </div>
                    <!-- container -->

                </div>
                <!-- content -->

                

            </div>

            <!-- ============================================================== -->
            <!-- End Page content -->
            <!-- ============================================================== -->

        </div>
        <!-- END wrapper -->

        <!-- Theme Settings -->

        <!-- Vendor js -->
        <script src="assets/js/vendor.min.js"></script>

        <!-- Daterangepicker js -->
        <script src="assets/vendor/daterangepicker/moment.min.js"></script>
        <script src="assets/vendor/daterangepicker/daterangepicker.js"></script>
        
        <!-- Apex Charts js -->
        <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>

        <!-- Vector Map js -->
        <script src="assets/vendor/admin-resources/jquery.vectormap/jquery-jvectormap-1.2.2.min.js"></script>
        <script src="assets/vendor/admin-resources/jquery.vectormap/maps/jquery-jvectormap-world-mill-en.js"></script>

        <!-- Dashboard App js -->
        <script src="assets/js/pages/demo.dashboard.js"></script>

      <!-- Datatable js -->
        <script src="assets/vendor/datatables.net/js/jquery.dataTables.min.js"></script>
        <script src="assets/vendor/datatables.net-bs5/js/dataTables.bootstrap5.min.js"></script>
        <script src="assets/vendor/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
        <script src="assets/vendor/datatables.net-responsive-bs5/js/responsive.bootstrap5.min.js"></script>
        <script src="assets/vendor/jquery-datatables-checkboxes/js/dataTables.checkboxes.min.js"></script>

        <!-- Apex Chart Column Demo js -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/dayjs/1.11.0/dayjs.min.js"></script>  
        <script src="https://cdnjs.cloudflare.com/ajax/libs/dayjs/1.11.0/plugin/quarterOfYear.min.js"></script>        
        <!--<script src="assets/js/pages/demo.apex-column.js"></script> -->
		
 <script src="assets/js/pages/demo.customers.js"></script>
        <!-- Apex Chart Area Demo js -->
        <script src="assets/js/app.min.js"></script>

    </body>
</html> 