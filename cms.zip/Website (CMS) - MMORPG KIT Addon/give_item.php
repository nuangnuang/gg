<?php
    require 'config.php';
    require 'core/functions.php';
    require 'language.php';

    ?>
<!DOCTYPE html>
<html lang="en" data-sidenav-size="fullscreen">

    <head>
        <meta charset="utf-8" />
        <title> <?php echo lang('Send Email'); ?> | <?php echo SITE_TITLE; ?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="<?php echo META_DESCRIPTION;?>" name="description" />
		<meta name="keywords" content="<?php echo META_KEYWORDS;?>">
        <meta content="SITE_TITLE" name="author" />

        <!-- App favicon -->
        <link rel="shortcut icon" href="assets/images/favicon.ico">

        <!-- Daterangepicker css -->
        <link rel="stylesheet" href="assets/vendor/daterangepicker/daterangepicker.css">

        <!-- Vector Map css -->
        <link rel="stylesheet" href="assets/vendor/admin-resources/jquery.vectormap/jquery-jvectormap-1.2.2.css">

        <!-- Theme Config Js -->
        <script src="assets/js/hyper-config.js"></script>

        <!-- App css -->
        <link href="assets/css/app-saas.min.css" rel="stylesheet" type="text/css" id="app-style" />
<script src="js/Chart.js"></script>
<script src="js/jquery.js"></script>
        <!-- Icons css -->
        <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <script>
        function showSuggestions(field, value) {
            if (value.length == 0) {
                document.getElementById(field + "Suggestions").innerHTML = "";
                document.getElementById(field + "Suggestions").style.display = "none";
                return;
            }

            const xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    document.getElementById(field + "Suggestions").innerHTML = xhr.responseText;
                    document.getElementById(field + "Suggestions").style.display = "block";
                }
            };
            xhr.open("GET", "get_" + field + ".php?q=" + encodeURIComponent(value), true);
            xhr.send();
        }

        function selectSuggestion(field, id, value, extra) {
            if (field === 'user') {
                document.getElementById("receiverId").value = id;
                document.getElementById("receiverName").value = value;
            } else if (field === 'item') {
				document.getElementById("itemInput").value = ""; // Limpa o campo de texto
                var itemIdInput = document.createElement("input");
                itemIdInput.type = "hidden";
                itemIdInput.name = "itemIds[]";
                itemIdInput.value = id;

                var itemNameDisplay = document.createElement("h5");
                itemNameDisplay.textContent = value;
                itemNameDisplay.className = "card-title";
                itemNameDisplay.style.textAlign = "center";
                itemNameDisplay.style.marginTop = "5px";
				itemNameDisplay.style.width = "fit-content";
				itemNameDisplay.style.maxWidth = "100%";
                itemNameDisplay.style.overflow = "hidden";
                itemNameDisplay.style.textOverflow = "ellipsis";
                itemNameDisplay.style.whiteSpace = "nowrap";
                itemNameDisplay.style.display = "inline-block";
                itemNameDisplay.style.textAlign = "center";


                var itemImage = document.createElement("img");
                itemImage.src = extra;
                itemImage.alt = "Icon";
				//itemImage.style.maxWidth = "50px";
                //itemImage.style.maxHeight = "50px";
				itemImage.className = "card-img-top";

                var quantityInput = document.createElement("input");
                quantityInput.type = "number";
                quantityInput.min = "0";
                quantityInput.name = "quantities[]";
                quantityInput.placeholder = "Amount";
                quantityInput.className = "form-control";

                var removeButton = document.createElement("button");
                removeButton.textContent = "Remove";
                removeButton.className = "btn btn-danger";
                removeButton.style.marginTop = "5px";
                removeButton.onclick = function() {
                    this.parentNode.remove(); // Remove o div que contém o item e o botão de remoção
                    itemIdInput.remove(); // Remove o campo de entrada do ID do item
                    quantityInput.remove(); // Remove o campo de entrada da quantidade
                };

                var newItemField = document.createElement("div");
				newItemField.className = "col-sm-2 col-lg-2 card"; // Define uma classe para o div
                newItemField.appendChild(itemIdInput);
                newItemField.appendChild(itemImage);
                newItemField.appendChild(itemNameDisplay);
                newItemField.appendChild(quantityInput);
                newItemField.appendChild(removeButton);

                document.getElementById("selectedItems").appendChild(newItemField);
            }
            document.getElementById(field + "Suggestions").innerHTML = "";
            document.getElementById(field + "Suggestions").style.display = "none";
        }
    </script>
    <style>
        .suggestions {
            border: 1px solid #ccc;
            display: none;
            position: absolute;
            background-color: white;
            z-index: 1000;
            max-height: 200px;
            overflow-y: auto;
        }
        .suggestions div {
            padding: 8px;
            cursor: pointer;
            display: flex;
            align-items: center;
        }
        .suggestions div img {
            max-width: 50px;
            max-height: 50px;
            margin-right: 10px;
        }
        .suggestions div:hover {
            background-color: #f0f0f0;
        }
        #selectedItems {
            margin-top: 10px;
        }
    </style>
    </head>

    <body>
        <!-- Begin page -->
        <div class="wrapper">

            <?php include 'includes/topbar.php';?> 

            <!-- ========== Left Sidebar Start ========== -->
            <div class="leftside-menu">

               

                

                <!-- Sidebar Hover Menu Toggle Button -->
                <div class="button-sm-hover" data-bs-toggle="tooltip" data-bs-placement="right" title="Show Full Sidebar">
                    <i class="ri-checkbox-blank-circle-line align-middle"></i>
                </div>

                <!-- Full Sidebar Menu Close Button -->
                <div class="button-close-fullsidebar">
                    <i class="ri-close-fill align-middle"></i>
                </div>

                <!-- Sidebar -left -->
                <div class="h-100" id="leftside-menu-container" data-simplebar>
                    <!-- Leftbar User -->
                    
<?php include 'includes/sidebar2.php';?>
                    <!--- End Sidemenu -->

                    <div class="clearfix"></div>
                </div>
            </div>
            <!-- ========== Left Sidebar End ========== -->

            <!-- ============================================================== -->
            <!-- Start Page Content here -->
            <!-- ============================================================== -->

            <div class="content-page" >
                <div class="content" >

                    <!-- Start Content-->
                    <div class="container-fluid" >

                        <div class="row">
                            <div class="col-8"  style="margin:0 auto;">
                                <div class="page-title-box">
						<?php  if ($id != ''){ ?>								
									<div class="page-title-right">
                                        <form class="d-flex">
											<button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#danger-header-modal">Delete</button>
                                        </form>
                                    </div>
									<?php
									
									}
									
									?>
									<h4 class="page-title"><?php  echo lang('Send Email'); ?></h4>
                                </div>
                            </div>
                        </div>

                        <div class="row">
						
						<div class="card col-xl-8 col-lg-8"  style="margin:0 auto;">
						<?php
						// Verifica se o parâmetro 'token' está definido na URL
									if (isset($_GET['a'])) {
										// Recupera o valor do parâmetro 'token'
										$error = $_GET['a'];

									}
							switch ($error) {
									
										case 1:
										?>
											<div class="alert alert-success" role="alert">
												<strong><?php echo lang('Category added successfully!') ?></strong>
											</div>
										<?php
										break;
										case 2:
										?>
											<div class="alert alert-danger bg-transparent text-danger" role="alert">
												<strong><?php echo lang('Deleted.') ?></strong>
											</div>
										<?php
										break;
									default:
									
										break;
								}
						
						?>
							
							<form action="send_item.php" method="post">
								<div class="mb-3">
									<label for="example-fileinput" class="form-label"><?php echo lang('Sender Name'); ?>:</label>
									<input type="text" class="form-control" id="senderName" name="senderName" placeholder="example: New Year Event" required>
								</div>
								<div class="mb-3">
									<label for="example-fileinput" class="form-label"><?php echo lang('Account ID'); ?>:</label>
									<input type="text" class="form-control" id="receiverId" name="receiverId" onkeyup="showSuggestions('user', this.value)" required>
									<div id="userSuggestions" class="suggestions"></div>
								</div>
								<div class="mb-3">
									<label for="example-fileinput" class="form-label"><?php echo lang('Account Name'); ?>:</label>
									<input type="text" class="form-control" id="receiverName" name="receiverName" readonly>
									<div id="userSuggestions" class="suggestions"></div>
								</div>
								<div class="mb-3">
									<label for="itemInput">Items:</label>
									<input type="text" class="form-control" id="itemInput" name="itemName" onkeyup="showSuggestions('item', this.value)" >
									<div id="itemSuggestions" class="suggestions"></div>
									<div id="selectedItems" class="row"></div>
								</div>
								<div class="mb-3">
									<label for="itemInput">Cash:</label>
									<input type="text" class="form-control" id="cash" name="cash" required>
								</div>
								<div class="mb-3">
									<label for="itemInput">Gold:</label>
									<input type="text" class="form-control" id="gold" name="gold" required>
								</div>
								<div class="mb-3">
									<label for="itemInput">Title:</label>
									<input type="text" class="form-control" id="title" name="title" required>
								</div>
								<div class="mb-3">
									<label for="itemInput">Content:</label>
									<textarea id="content" class="form-control" name="content" required></textarea><br>
								</div>
								<div class="d-grid">
									<input style="margin-bottom:10px;" class="btn btn-lg btn-primary" type="submit" value="Send Email">
								</div>



									
								</form>							<!-- Include a WYSIWYG editor -->
							<script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
							<script>
								
							</script>
                            

                       </div>


                    </div>
                    <!-- container -->

                </div>
                <!-- content -->

                						<div id="danger-header-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="danger-header-modalLabel" aria-hidden="true">
							<div class="modal-dialog">
								<div class="modal-content">
									<div class="modal-header bg-danger">
										<h4 class="modal-title" style="color: white;" id="danger-header-modalLabel">Warning: Category Deletion</h4>
										<button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"></button>
									</div>
									<div class="modal-body">
													<div class="mb-1">
														<label for="example-palaceholder" class="form-label">You are about to delete this category. This action is permanent and cannot be undone.</label>
													</div>
													<div class="mb-1">
														<label for="example-palaceholder" class="form-label">Are you sure you want to proceed?</label>
													</div>
										
                                                <!-- comment box -->
													
													
                                               
									</div>
									<div class="modal-footer">
										<button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
										<a Href="delete.php?id=<?php echo $id; ?>" class="btn btn-danger">Delete</a>
									</div>
									
									<!-- end .border-->
								</div><!-- /.modal-content -->
							</div><!-- /.modal-dialog -->
						</div><!-- /.modal -->


            </div>

            <!-- ============================================================== -->
            <!-- End Page content -->
            <!-- ============================================================== -->

        </div>
        <!-- END wrapper -->

        <!-- Vendor js -->
        <script src="assets/js/vendor.min.js"></script>

        <!-- Daterangepicker js -->
        <script src="assets/vendor/daterangepicker/moment.min.js"></script>
        <script src="assets/vendor/daterangepicker/daterangepicker.js"></script>
        
        <!-- Apex Charts js -->
        <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>

        <!-- Vector Map js -->
        <script src="assets/vendor/admin-resources/jquery.vectormap/jquery-jvectormap-1.2.2.min.js"></script>
        <script src="assets/vendor/admin-resources/jquery.vectormap/maps/jquery-jvectormap-world-mill-en.js"></script>

        <!-- Dashboard App js -->
        <script src="assets/js/pages/demo.dashboard.js"></script>

      

        <!-- Apex Chart Column Demo js -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/dayjs/1.11.0/dayjs.min.js"></script>  
        <script src="https://cdnjs.cloudflare.com/ajax/libs/dayjs/1.11.0/plugin/quarterOfYear.min.js"></script>        
        <!--<script src="assets/js/pages/demo.apex-column.js"></script> -->
		<?php
			include 'js/graficosCollum.php';
			//include 'js/graficospie.php';
			include 'js/graficosbar.php';
		?>

        <!-- Apex Chart Area Demo js -->
        <script src="assets/js/app.min.js"></script>

    </body>
</html> 