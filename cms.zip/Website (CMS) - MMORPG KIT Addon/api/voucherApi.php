<?php

require '../config.php';
require '../core/functions.php';

// Conectar ao banco de dados
$database = new Database();
$conn = $database->getConnection();

header('Content-Type: application/json; charset=utf-8');

// Inicializa a resposta
$response = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Recebe os parâmetros
    $voucher_code = $_POST['voucher_code'];
    $character_id = $_POST['character_id']; // Recebe o ID do personagem

    try {
        // Encontre o userId com base no ID do personagem
        $user_id = getUserIdFromCharacterId($conn, $character_id);

        if ($user_id === null) {
            $response['success'] = false;
            $response['message'] = 'Usuário não encontrado.';
        } else {
            // Resgatar o voucher
            $message = redeemVoucher($conn, $voucher_code, $user_id);
            $response['success'] = true;
            $response['message'] = $message;
        }
    } catch (Exception $e) {
        $response['success'] = false;
        $response['message'] = 'Erro: ' . $e->getMessage();
    }

    // Enviar resposta JSON
    echo json_encode($response);
    exit; // Assegura que nenhum outro código é executado após a resposta JSON
}

function getUserIdFromCharacterId($conn, $character_id) {
    $stmt = $conn->prepare("SELECT userId FROM characters WHERE id = ?");
    $stmt->execute([$character_id]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    return $result ? $result['userId'] : null;
}

function redeemVoucher($conn, $voucher_code, $user_id) {
    // Verifica se o voucher existe e é válido
    $stmt = $conn->prepare("SELECT * FROM vouchers WHERE voucher_code = ?");
    $stmt->execute([$voucher_code]);
    $voucher = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$voucher) {
        return "Invalid voucher.";
    }

    // Verifica o limite de uso, se use_limit for 0, não há limite
    $claimed_users = explode(',', $voucher['claimed']);
    if ($voucher['use_limit'] != 0 && count($claimed_users) >= $voucher['use_limit']) {
        return "This voucher has reached its usage limit.";
    }

    // Verifica se o voucher já expirou
    $current_time = date('Y-m-d H:i:s');
    if ($current_time > $voucher['end_time']) {
        return "This voucher has now expired.";
    }

    // Verifica se o usuário já resgatou este voucher
    if (in_array($user_id, $claimed_users)) {
        return "You have already redeemed this voucher.";
    }

    // Marca o voucher como resgatado pelo usuário
    $claimed_users[] = $user_id;
    $claimed_users_str = implode(',', $claimed_users);
    $stmt = $conn->prepare("UPDATE vouchers SET claimed = ? WHERE id = ?");
    $stmt->execute([$claimed_users_str, $voucher['id']]);

    // Aplica os itens ao usuário
    $items = $voucher['items'];
    $title = $voucher['title'];
    $content = $voucher['content'];
    $gold = $voucher['gold'];
    $cash = $voucher['cash'];

    // Insere os dados na tabela mail
    $eventId = ''; // Gera um ID único para o evento
    $senderId = '0'; // Aqui você pode definir o ID do remetente conforme necessário
    $senderName = 'Voucher Code'; // Nome do remetente, pode ser ajustado
    $currencies = ''; // Defina o valor adequado para o campo 'currencies'

    $sql = "INSERT INTO mail (eventId, senderId, senderName, receiverId, title, content, gold, cash, items, currencies) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$eventId, $senderId, $senderName, $user_id, $title, $content, $gold, $cash, $items, $currencies]);

    return "Voucher redeemed successfully";
}
?>
