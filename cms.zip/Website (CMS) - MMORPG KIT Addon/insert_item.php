<?php
session_start();
	require 'protected.php';
	checkLogin();
	checkUserLevel(5, 'index.php');
require 'config.php';
require 'core/functions.php';

// Processar o formulário
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id']; // Assumindo que o campo ID está presente no formulário
    $id = getStableHash($id);
    $name = $_POST['name'];
    $description = $_POST['description'];
    $stats = $_POST['stats'];
    $set = $_POST['set'];
    $type = $_POST['type'];
    $weight = $_POST['weight'];
    $conditions = $_POST['conditions'];
    $level = $_POST['level'];
    $MaxSocket = $_POST['MaxSocket'];
    $category = $_POST['category']; // Supondo que você tenha um campo de seleção para a categoria
    $target_file = ""; // Defina o nome do arquivo corretamente

    // Upload da imagem
    $target_dir = "uploads/";
    $imageFileType = strtolower(pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION));
    $unique_name = "item_" . uniqid() . '.' . $imageFileType; // Prefixo adicionado ao nome único
    $target_file = $target_dir . $unique_name;

    // Verificar se o arquivo é uma imagem real
    $check = getimagesize($_FILES["image"]["tmp_name"]);
    if ($check !== false) {
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
            // Inserir dados no banco de dados usando a classe Database
            $database = new Database();
            $db = $database->getConnection();

            $sql = "INSERT INTO items (id, name, image, description, stats, equipamentSet, itemType, weight, conditions, MaxSocket, category, level)
                    VALUES (:id, :name, :image, :description, :stats, :set, :type, :weight, :conditions, :MaxSocket, :category, :level)";

            $stmt = $db->prepare($sql);
            $stmt->bindParam(':id', $id);
            $stmt->bindParam(':name', $name);
            $stmt->bindParam(':image', $target_file);
            $stmt->bindParam(':description', $description);
            $stmt->bindParam(':stats', $stats);
            $stmt->bindParam(':set', $set);
            $stmt->bindParam(':type', $type);
            $stmt->bindParam(':weight', $weight);
            $stmt->bindParam(':conditions', $conditions);
            $stmt->bindParam(':MaxSocket', $MaxSocket);
            $stmt->bindParam(':category', $category);
            $stmt->bindParam(':level', $level);

            if ($stmt->execute()) {
                echo "Item cadastrado com sucesso!";
				header("Location: items.php");
            } else {
                echo "Erro ao cadastrar o item.";
            }
        } else {
            echo "Desculpe, houve um erro ao fazer upload do seu arquivo.";
        }
    } else {
        echo "Arquivo não é uma imagem.";
    }
}
?>
