<?php 

require 'protected.php';
include 'config.php';
	require 'core/functions.php'; 
	include 'language.php'; 
	
// Fetch news from the database
$db = new Database();
$conn = $db->getConnection();

$stmt = $conn->prepare("SELECT n.*, c.name as category_name FROM news n LEFT JOIN categories c ON n.category_id = c.id ORDER BY n.created_at DESC LIMIT 5");
$stmt->execute();
$news = $stmt->fetchAll();

?>

<!DOCTYPE html>
<html lang="en" data-layout="topnav">

    <head>
        <meta charset="utf-8" />
        <title>Horizontal Layout | Hyper - Responsive Bootstrap 5 Admin Dashboard</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="<?php echo META_DESCRIPTION;?>" name="description" />
		<meta name="keywords" content="<?php echo META_KEYWORDS;?>">
        <meta content="SITE_TITLE" name="author" />

        <!-- App favicon -->
        <link rel="shortcut icon" href="assets/images/favicon.ico">

        <!-- Plugin css -->
        <link rel="stylesheet" href="assets/vendor/daterangepicker/daterangepicker.css">
        <link href="assets/vendor/admin-resources/jquery.vectormap/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css" />

        <!-- Theme Config Js -->
        <script src="assets/js/hyper-config.js"></script>

        <!-- App css -->
        <link href="assets/css/app-saas.min.css" rel="stylesheet" type="text/css" />

        <!-- Icons css -->
        <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    </head>

    <body>
        <!-- Begin page -->
        <div class="wrapper">

            

		<?php include('includes/topnav.php'); ?>

            
            <div class="content-page" style="max-width: 1300px; margin:0 auto;">
                <div class="content">
                    
                    <!-- Start Content-->
                    <div class="container-fluid">




                        <div class="row" style="margin-top:20px;">
                            <div class="col-xl-8 col-lg-12 order-lg-2 order-xl-1">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <h4 class="header-title">NEWS</h4>
                                        </div>
										
						<?php 
						
						if (isset($_GET['category'])) {
										$category = $_GET['category'];
										$category = filter_var($category, FILTER_SANITIZE_STRING);
										// Defina as condições desejadas como um array
										$conditions = ["category_id = '$category'"];

										// Use a função fetchRecords para buscar registros em uma tabela com condições
										$result = fetchNews('news', '*', $conditions);
									
									}else{

										// Use a função fetchRecords para buscar registros em uma tabela com condições
										$result = fetchNews('news', '*');
									}
						
						
						foreach ($result as $item): ?>
						<div class="row">
                            <div class="col-lg-12">
                                <div class="card">
                                    <div class="row g-0 align-items-top" style="max-height:160px;">
                                        <div class="col-md-4">
                                            <a href="read.php?new=<?php echo $item['id']; ?>" class="link-secondary"><img src="<?php echo $item['thumbnail_image']; ?>" style="width:342px; height:160px;" class="img-fluid rounded-start" alt="..."></a>
                                        </div>
                                        <div class="col-md-8">
                                            <div class="card-body">
                                                <h5 class="card-title"><a href="read.php?new=<?php echo $item['id']; ?>" class="link-secondary"><?php echo $item['title']; ?></a></h5>
                                                <p class="card-text"><?php echo $item['subtitle']; ?></p>
                                                <p class="card-text"><small class="text-muted"><?php echo $item['created_at']; ?></small></p>
                                            </div> <!-- end card-body-->
                                        </div> <!-- end col -->
                                    </div> <!-- end row-->
                                </div> <!-- end card-->
                            </div> <!-- end col-->
                        </div>
						<?php endforeach; ?>

                                    </div> <!-- end card-body-->
                                </div> <!-- end card-->
                            </div> <!-- end col-->

                           

                            <div class="col-xl-4 col-lg-6 order-lg-1">
                                <div class="card">
                                    <div class="card-body pb-0">
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <h4 class="header-title">Categories</h4>
                                        </div>
                                    </div>

                                    <div class="card-body py-0 mb-3" data-simplebar> 
                                        <ul class="list-group">
										<?php
								
									if (isset($_GET['list']) & ($_GET['list'] == 'banned')) {
										$list = $_GET['list'];
										$list = filter_var($list, FILTER_SANITIZE_STRING);
										// Defina as condições desejadas como um array
										$conditions = ["category_id = '0'"];

										// Use a função fetchRecords para buscar registros em uma tabela com condições
										$result = fetchRecords('categories', '*');
									
									}else{

										// Use a função fetchRecords para buscar registros em uma tabela com condições
										$result = fetchRecords('categories', '*');
									}

									foreach ($result as $row) {
	

								?>
											<li class="list-group-item d-flex justify-content-between align-items-center">
												<a href="new.php?category=<?php echo $row['id'];?>"><?php echo $row['name'];?></a>
												<span class="badge bg-primary rounded-pill"><?php
													$category_id =  $row['id'];
													$conditions = ["category_id = '$category_id'"];
													$newsCategory = countRecords('news', $conditions);
													
													echo $newsCategory;
												
												?></span>
											</li>
											
									<?php } ?>
										</ul>

       
                                        <!-- end timeline -->
                                    </div> <!-- end slimscroll -->
                                </div>
                                <!-- end card-->
                            </div>
                            <!-- end col -->

                        </div>
                        <!-- end row -->

                    </div>
                    <!-- container -->

                </div>
                <!-- content -->

                <!-- Footer Start -->
                <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-6">
                                <script>document.write(new Date().getFullYear())</script> © <?php echo SITE_TITLE; ?>
                            </div>
                            <div class="col-md-6">
                                <div class="text-md-end footer-links d-none d-md-block">
                                    <a href="javascript: void(0);">About</a>
                                    <a href="javascript: void(0);">Support</a>
                                    <a href="javascript: void(0);">Contact Us</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </footer>
                <!-- end Footer -->

            </div>

            <!-- ============================================================== -->
            <!-- End Page content -->
            <!-- ============================================================== -->

        </div>
        <!-- END wrapper -->

   
        
        <!-- Vendor js -->
        <script src="assets/js/vendor.min.js"></script>

        <!-- Daterangepicker js -->
        <script src="assets/vendor/daterangepicker/moment.min.js"></script>
        <script src="assets/vendor/daterangepicker/daterangepicker.js"></script>
        
        <!-- Apex Charts js -->
        <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>

        <!-- Vector Map js -->
        <script src="assets/vendor/admin-resources/jquery.vectormap/jquery-jvectormap-1.2.2.min.js"></script>
        <script src="assets/vendor/admin-resources/jquery.vectormap/maps/jquery-jvectormap-world-mill-en.js"></script>

        <!-- Dashboard App js -->
        <script src="assets/js/pages/demo.dashboard.js"></script>

        <!-- App js -->
        <script src="assets/js/app.min.js"></script>

    </body>
</html>