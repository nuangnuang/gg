<?php
// URL da API para obter os países e códigos de país
$url = 'https://restcountries.com/v3.1/all';

// Obtém os dados JSON dos países
$data = file_get_contents($url);

// Decodifica os dados JSON em um array associativo
$response = json_decode($data, true);

// Verifica se a resposta é válida e se os dados dos países estão presentes
if ($response) {
    // Array para armazenar os nomes dos países e seus códigos
    $countries_list = [];

    // Percorre os dados dos países e extrai o nome e o código de cada um
    foreach ($response as $country) {
        $country_name = $country['name']['common'];
        $country_code = isset($country['cca2']) ? $country['cca2'] : null; // Verifica se o código de país está presente

        // Verifica se o código de país é válido antes de adicioná-lo ao array
        if ($country_code !== null && !empty($country_code)) {
            // Adiciona o país e seu código ao array
            $countries_list[$country_name] = $country_code;
        }
    }

    // Caminho para o arquivo JSON
    $file_path = 'countries.json';

    // Converter o array em formato JSON e salvar no arquivo
    $json_data = json_encode($countries_list, JSON_PRETTY_PRINT);
    file_put_contents($file_path, $json_data);

    echo "Countries JSON file created successfully.";
} else {
    echo "Failed to retrieve data from the API.";
}
?>
