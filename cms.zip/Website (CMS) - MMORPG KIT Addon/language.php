<?php

// Verifique se o idioma do usuário está definido na sessão
if (!isset($_SESSION['lang'])) {
    $_SESSION['lang'] = DEFAULT_LANGUAGE;
}

// Verifique se o usuário selecionou um novo idioma
if (isset($_GET['lang'])) {
    $selectedLang = $_GET['lang'];
    // Certifique-se de que o idioma selecionado é válido
    if (in_array($selectedLang, ['en', 'pt', 'es'])) {
        $_SESSION['lang'] = $selectedLang;
    }
}

// Função para carregar strings de texto com base no idioma
function lang($key) {
    $lang = isset($_SESSION['lang']) ? $_SESSION['lang'] : DEFAULT_LANGUAGE;
    $langFile = 'lang/' . $lang . '.php';
    if (file_exists($langFile)) {
        $langData = include $langFile;
        if (array_key_exists($key, $langData)) {
            return $langData[$key];
        }
    }
    // Se a chave não existir no arquivo de idioma, retorne a própria chave
    return $key;
}
?>