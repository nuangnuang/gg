<?php
include 'config.php';
include 'core/functions.php'; 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

try {
    $database = new Database();
    $conn = $database->getConnection();
} catch (Exception $e) {
    die("Falha na conexão: " . $e->getMessage());
}

// Recuperando os dados do formulário
$receiverId = $_POST['receiverId'];
$receiverName = $_POST['receiverName'];
$title = $_POST['title'];
$content = $_POST['content'];
$gold = $_POST['gold'];
$cash = $_POST['cash'];


// Inicializa arrays para armazenar IDs de itens e quantidades
$itemIds = $_POST['itemIds'];
$quantities = $_POST['quantities'];

// Verifica se itemIds[] e quantities[] têm o mesmo número de elementos
if(count($itemIds) !== count($quantities)) {
    die("Erro: O número de IDs de itens e quantidades não corresponde.");
}

// Inicializa a string de itens
$items = "";

// Monta a string dos itens com as quantidades correspondentes
for($i = 0; $i < count($itemIds); $i++) {
    $itemId = $itemIds[$i];
    $quantity = $quantities[$i];
    $items .= "$itemId:$quantity:0:0.00:0:0.00:0:0:;";
}

// Insere os dados na tabela mail
//$sql = "INSERT INTO mail (eventId, senderId, senderName, receiverId, title, content, gold, cash, items) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
$eventId = ''; // Gera um ID único para o evento
$senderId = '0'; // Aqui você pode definir o ID do remetente conforme necessário
$senderName = $_POST['senderName'];


// Inclua o valor do campo 'currencies' no array de valores
$currencies = ''; // Defina o valor adequado para o campo 'currencies'
$sql = "INSERT INTO mail (eventId, senderId, senderName, receiverId, title, content, gold, cash, items, currencies) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->execute([$eventId, $senderId, $senderName, $receiverId, $title, $content, $gold, $cash, $items, $currencies]);

echo "Itens enviados com sucesso para $receiverName!";
?>
