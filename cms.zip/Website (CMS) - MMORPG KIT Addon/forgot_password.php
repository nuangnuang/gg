<?php
session_start();
if (isset($_SESSION['username'])) {
    header("Location: index.php");
    exit;
}
include 'config.php';
include 'language.php';
?>
<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8" />
        <title><?php echo lang('Reset Password');?> | <?php echo SITE_TITLE; ?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="<?php echo META_DESCRIPTION;?>" name="description" />
		<meta name="keywords" content="<?php echo META_KEYWORDS;?>">
        <meta content="SITE_TITLE" name="author" />

        <!-- App favicon -->
        <link rel="shortcut icon" href="assets/images/favicon.ico">

        <!-- Theme Config Js -->
        <script src="assets/js/hyper-config.js"></script>

        <!-- App css -->
        <link href="assets/css/app-saas.min.css" rel="stylesheet" type="text/css" />

        <!-- Icons css -->
        <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    </head>

    <body class="authentication-bg">

        <div class="position-absolute start-0 end-0 start-0 bottom-0 w-100 h-100">
            <svg xmlns='http://www.w3.org/2000/svg' width='100%' height='100%' viewBox='0 0 800 800'>
                <g fill-opacity='0.22'>
                    <circle style="fill: rgba(var(--ct-primary-rgb), 0.1);" cx='400' cy='400' r='600'/>
                    <circle style="fill: rgba(var(--ct-primary-rgb), 0.2);" cx='400' cy='400' r='500'/>
                    <circle style="fill: rgba(var(--ct-primary-rgb), 0.3);" cx='400' cy='400' r='300'/>
                    <circle style="fill: rgba(var(--ct-primary-rgb), 0.4);" cx='400' cy='400' r='200'/>
                    <circle style="fill: rgba(var(--ct-primary-rgb), 0.5);" cx='400' cy='400' r='100'/>
                </g>
            </svg>
        </div>

        <div class="account-pages pt-2 pt-sm-5 pb-4 pb-sm-5 position-relative">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xxl-4 col-lg-5">
                        <div class="card">
                            <!-- Logo -->
                            <div class="card-header py-4 text-center bg-primary">
                                <a href="index.html">
                                    <span><img src="assets/images/logo.png" alt="logo" height="22"></span>
                                </a>
                            </div>
                            
                            <div class="card-body p-4">
                                
                                <div class="text-center w-75 m-auto">
                                    <h4 class="text-dark-50 text-center mt-0 fw-bold"><?php echo lang('Reset Password');?></h4>
                                    <p class="text-muted mb-4"><?php echo lang('Enter your email address and we\'ll send you an email with instructions to reset your password.');?></p>
                                </div>
								<?php
								
									// Verifica se o parâmetro 'token' está definido na URL
									if (isset($_GET['error'])) {
										// Recupera o valor do parâmetro 'token'
										$error = $_GET['error'];

									}

								switch ($error) {
									case 2:
										?>
											<div class="alert alert-danger bg-transparent text-danger" role="alert">
												<strong><?php echo lang('Failed to send email.') ?></strong>
											</div>
										<?php
										break;
									case 1:
										?>
											<div class="alert alert-danger bg-transparent text-danger" role="alert">
												<strong><?php echo lang('No account found with that email address.') ?></strong>
											</div>
										<?php
										break;
										case 3:
										?>
											<div class="alert alert-success" role="alert">
												<strong><?php echo lang('An email has been sent to your email address with the password reset link.') ?></strong>
											</div>
										<?php
										break;
										case 4:
										?>
											<div class="alert alert-danger bg-transparent text-danger" role="alert">
												<strong><?php echo lang('Invalid or expired token.') ?></strong>
											</div>
										<?php
										break;
									default:
										break;
								}
								?>
								

                                <form method="POST" action="process_forgot_password.php">
                                    <div class="mb-3">
                                        <label for="emailaddress" class="form-label"><?php echo lang('Email address');?></label>
                                        <input class="form-control" type="email" name="email" id="emailaddress" required="" placeholder="<?php echo lang('Enter your email');?>">
                                    </div>

                                    <div class="mb-0 text-center">
                                        <button class="btn btn-primary" type="submit"><?php echo lang('Reset Password');?></button>
                                    </div>
                                </form>
                            </div> <!-- end card-body-->
                        </div>
                        <!-- end card -->

                        <div class="row mt-3">
                            <div class="col-12 text-center">
                                <p class="text-muted"><?php echo lang('Back to');?> <a href="login.php" class="text-muted ms-1"><b><?php echo lang('Log In');?></b></a></p>
                            </div> <!-- end col -->
                        </div>
                        <!-- end row -->

                    </div> <!-- end col -->
                </div>
                <!-- end row -->
            </div>
            <!-- end container -->
        </div>
        <!-- end page -->

        <footer class="footer footer-alt">
            <script>document.write(new Date().getFullYear())</script> © <?php echo SITE_TITLE; ?>
        </footer>
        <!-- Vendor js -->
        <script src="assets/js/vendor.min.js"></script>
        
        <!-- App js -->
        <script src="assets/js/app.min.js"></script>

    </body>
</html>
