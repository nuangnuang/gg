                    <!--- Sidemenu -->
                    <ul class="side-nav">

                        <li class="side-nav-title">Navigation</li>


                        <li class="side-nav-item">
                            <a href="dashboard.php" class="side-nav-link">
                                <i class="uil-home"></i>
                                <span> <?php echo lang('Dashborad'); ?> </span>
                            </a>
                        </li>
						<li class="side-nav-item">
                            <a data-bs-toggle="collapse" href="#accounts" aria-expanded="false" aria-controls="accounts" class="side-nav-link">
                                <i class="uil-user"></i>
                                <span> <?php echo lang('Accounts'); ?> </span>
								<span class="menu-arrow"></span>
                            </a>
                            <div class="collapse" id="accounts">
                                <ul class="side-nav-second-level">
                                    <li>
                                        <a href="accounts.php">User List</a>
                                    </li>
                                    <li>
                                        <a href="accounts.php?list=banned">Banned User</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
						<li class="side-nav-item">
                            <a data-bs-toggle="collapse" href="#characters" aria-expanded="false" aria-controls="characters" class="side-nav-link">
                                <i class="uil-users-alt"></i>
                                <span> <?php echo lang('Characters'); ?> </span>
								<span class="menu-arrow"></span>
                            </a>
                            <div class="collapse" id="characters">
                                <ul class="side-nav-second-level">
                                    <li>
                                        <a href="characters.php">Characters List</a>
                                    </li>
                                    <li>
                                        <a href="characters.php">Mutted List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
						<li class="side-nav-item">
                            <a data-bs-toggle="collapse" href="#sidebarDashboards" aria-expanded="false" aria-controls="sidebarDashboards" class="side-nav-link">
                                <i class="uil-newspaper"></i>
                                <span> <?php echo lang('News'); ?> </span>
								<span class="menu-arrow"></span>
                            </a>
                            <div class="collapse" id="sidebarDashboards">
                                <ul class="side-nav-second-level">
                                    <li>
                                        <a href="add_news.php">Add News</a>
                                    </li>
                                    <li>
                                        <a href="news.php">List</a>
                                    </li>
                                    <li>
                                        <a href="manage_category.php">Category</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
						<li class="side-nav-item">
                            <a href="voucher.php" class="side-nav-link">
                                <i class="mdi mdi-ticket"></i>
                                <span> <?php echo lang('Vouchers'); ?> </span>
                            </a>
                        </li>
						<li class="side-nav-item">
                            <a data-bs-toggle="collapse" href="#email" aria-expanded="false" aria-controls="email" class="side-nav-link">
                                <i class="uil-envelope"></i>
                                <span> <?php echo lang('Email'); ?> </span>
								<span class="menu-arrow"></span>
                            </a>
                            <div class="collapse" id="email">
                                <ul class="side-nav-second-level">
                                    <li>
                                        <a href="give_item.php">Send Email</a>
                                    </li>
                                    <li>
                                        <a href="#">Email List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
						<li class="side-nav-item">
                            <a data-bs-toggle="collapse" href="#encyclopedia" aria-expanded="false" aria-controls="encyclopedia" class="side-nav-link">
                                <i class="uil-book-alt"></i>
                                <span> <?php echo lang('Encyclopedia'); ?> </span>
								<span class="menu-arrow"></span>
                            </a>
                            <div class="collapse" id="encyclopedia">
                                <ul class="side-nav-second-level">
                                    <li>
                                        <a href="add_items.php">Add Items</a>
                                    </li>
                                    <li>
                                        <a href="items.php">Items List</a>
                                    </li>
                                    <li>
                                        <a href="manage_item_category.php">Category</a>
                                    </li>
                                </ul>
                            </div>
                        </li>						
						<li class="side-nav-item">
                            <a data-bs-toggle="collapse" href="#Bestiary" aria-expanded="false" aria-controls="Bestiary" class="side-nav-link">
                                <i class="uil-book-alt"></i>
                                <span> <?php echo lang('Bestiary'); ?> </span>
								<span class="menu-arrow"></span>
                            </a>
                            <div class="collapse" id="Bestiary">
                                <ul class="side-nav-second-level">
                                    <li>
                                        <a href="#">Add monster</a>
                                    </li>
                                    <li>
                                        <a href="#">Monster List</a>
                                    </li>
                                    <li>
                                        <a href="#">Monster Category</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
						

						<li class="side-nav-item">
                            <a href="logout.php" class="side-nav-link">
                                <i class="uil-location-point"></i>
                                <span> <?php echo lang('Logout'); ?> </span>
                            </a>
                        </li>

						



                        


                    </ul>
