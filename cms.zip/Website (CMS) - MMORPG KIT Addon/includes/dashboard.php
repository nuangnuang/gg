<?php
	

	$totalAccounts = countRecords('userlogin');
	$conditions = ["dataId = '1817826663'"];
	$totalCharacters = countRecords('characters');
	$conditions = ["unbanTime != '0'"];
	$bannedAccounts = countRecords('userlogin', $conditions);
	$conditions = ["unbanTime != '0'"];
	$playersOnline = fetchRecord('statistic');
	$playersOnline = $playersOnline['userCount'];
	$class_Character = getStableHash($class4);
	//echo $class_Character;
	
	
// Definindo a função processArray que aplica a função getStableHash a cada elemento do array e retorna um novo array com os resultados
function processArray($arr) {
    $result = [];

    // Aplicando a função getStableHash a cada elemento do array
    foreach ($arr as $value) {
        $result[] = getStableHash($value);
    }

    return $result;
}

$cls = processArrayClass($array_Class);

$fct = processArrayClass($array_Factions);

// Chamando a função e recebendo o novo array com os hashes
//$resultado = processArray($cls);

// Imprimindo o novo array
//print_r($cls);


	

?>