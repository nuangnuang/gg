            <?php
			include 'config.php';
			
			?><!-- ========== Horizontal Menu Start ========== -->
            <div class="topnav" style="height: 50px !important; top: 0 !important;">
                <div class="container-fluid" style="height: 50px !important;">
                    <nav class="navbar navbar-expand-lg" style="height: 50px !important;">
                        <div class="collapse navbar-collapse" id="topnav-menu-content">
                            <ul class="navbar-nav" style="margin:0 auto !important;">
                                <li class="nav-item dropdown" style="width: 250px !important; margin-top: 5px; margin-right:300px;">
                                    <a href="<?php echo SITE_URL;?>" class="logo-light">
										<span><img src="assets/images/logo.png" alt="logo" height="40"></span>
									</a>
                                </li>
								<li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle arrow-none link-light" href="<?php echo SITE_URL;?>">
                                        <?php echo lang('Home'); ?>
                                    </a>
                                </li>
                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle arrow-none link-light" href="#" id="topnav-apps" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <?php echo lang('Game'); ?> 
                                    </a>
                                    <div class="dropdown-menu" aria-labelledby="topnav-apps">
                                        <a href="#" class="dropdown-item" id="bold"><h6>DOWNLOAD</h6></a>
                                        <a href="encyclopedia.php" class="dropdown-item"><h6>ENCYCLOPEDIA</h6></a>
                                    </div>
                                </li>
                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle arrow-none link-light" href="new.php" id="topnav-pages">
                                        <?php echo lang('News'); ?>
                                    </a>
                                </li>
                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle arrow-none link-light" href="#" id="topnav-components" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <?php echo lang('Community'); ?> 
                                    </a>
                                    <div class="dropdown-menu" aria-labelledby="topnav-components">
                                        <a href="#" class="dropdown-item" id="bold"><h6>RANK</h6></a>
                                        <a href="#" class="dropdown-item" id="bold"><h6>FORUM</h6></a>
                                        <a href="#" class="dropdown-item" id="bold"><h6>DISCORD</h6></a>
                                    </div>
                                </li>
                                <li class="nav-item dropdown" style="background:#ffd200;">
                                    <a class="nav-link dropdown-toggle arrow-none link-dark" href="#" id="topnav-layouts" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <?php echo lang('Account'); ?> 
                                    </a>
									<?php
									
									//include ('core/functions.php')
									// Função para verificar se o usuário está logado
									function checkLoginOn() {
										// Verifica se a sessão de usuário está definida
										if (isset($_SESSION['username'])) {
											return true;
										} else {
											return false;
										}
									}
										
									
									?>
									<?php if (checkLoginOn()){ ?>
									<div class="dropdown-menu" aria-labelledby="topnav-layouts">
                                        <?php
										
											if($_SESSION['userLevel'] == 5){
										
										?><a href="dashboard.php" class="dropdown-item" id="bold"><h6>DASHBOAAD</h6></a>
											<?php } ?>
										<a href="user.php" class="dropdown-item" id="bold"><h6><?php echo lang('ACCOUNT MANAGEMENT'); ?></h6></a>
                                        <a href="logout.php" class="dropdown-item" id="bold"><h6>LOGOUT</h6></a>
                                    </div>
									<?php }else{ ?>
									<div class="dropdown-menu" aria-labelledby="topnav-layouts">
                                        <a href="login.php" class="dropdown-item" id="bold"><h6>LOGIN</h6></a>
                                        <a href="register.php" class="dropdown-item" id="bold"><h6>REGISTER</h6></a>
                                    </div>
								<?php } ?>
                                    
									
									
									
									
									
                                </li>
                            </ul>
                        </div>
                    </nav>
                </div>
            </div>
            <!-- ========== Horizontal Menu End ========== -->