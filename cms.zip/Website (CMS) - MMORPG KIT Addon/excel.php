<form method="POST" action="gerar_excel.php">
    <label for="bairro">Escolha um bairro:</label>
    <select name="bairro" id="bairro">
        <option value="">Todos</option>
        <!-- Aqui você pode preencher com os bairros disponíveis -->
        <option value="Centro">Centro</option>
        <option value="Bairro 2">Bairro 2</option>
        <!-- Adicione mais opções conforme necessário -->
    </select>
    <button type="submit">Gerar Excel</button>
</form>
