<?php
require 'config.php';
require 'core/functions.php'; 
include 'language.php';
require 'libs/PHPMailer/src/Exception.php';
require 'libs/PHPMailer/src/PHPMailer.php';
require 'libs/PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];

    // Verificar se o email existe no banco de dados
    $db = new Database();
    $conn = $db->getConnection();
    
    $stmt = $conn->prepare("SELECT id FROM userlogin WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user) {
        $userId = $user['id'];
        $token = bin2hex(random_bytes(16));
        $expiresAt = date('Y-m-d H:i:s', strtotime('+1 hour'));

        // Inserir o token na tabela password_reset_tokens
        $stmt = $conn->prepare("INSERT INTO password_reset_tokens (user_id, token, expires_at) VALUES (?, ?, ?)");
        $stmt->execute([$userId, $token, $expiresAt]);

        // Enviar email com o link de redefinição de senha
        $resetLink = SITE_URL . "/reset_password.php?token=$token";
        $subject = lang("Password Reset Request");
        $body = lang('Click on the following link to reset your password:') . "<a href=\"$resetLink\">" . lang('Reset Password') . "</a>";

        if (sendEmail($email, $subject, $body)) {
			header("Location: forgot_password.php?error=3");
        } else {
            header("Location: forgot_password.php?error=2");
        }
    } else {
        header("Location: forgot_password.php?error=1");
    }
}

// Função para enviar email
function sendEmail($to, $subject, $body) {
    $mail = new PHPMailer(true);

    try {
        // Configurações do servidor
        $mail->isSMTP();
        $mail->Host = EMAIL_HOST;
        $mail->SMTPAuth = true;
        $mail->Username = EMAIL_USER;
        $mail->Password = EMAIL_PASS;
        $mail->SMTPSecure = 'tls';
        $mail->Port = EMAIL_PORT;

        // Remetente
        $mail->setFrom(EMAIL_FROM, EMAIL_NAME);

        // Destinatário
        $mail->addAddress($to);

        // Conteúdo do email
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $body;

        $mail->send();
        return true;
    } catch (Exception $e) {
        return false;
    }
}
?>
