<?php
session_start();
	require 'protected.php';
	checkLogin();
	checkUserLevel(5, 'index.php');
require 'config.php';
require 'core/functions.php'; 
require 'language.php';

// Configurar a conexão com o banco de dados
$database = new Database();
$db = $database->getConnection();

$id = '';
$name = '';
$type = 0;
$itemType = 0;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = isset($_POST['id']) ? $_POST['id'] : '';
    $name = $_POST['name'];
    $type = $_POST['type'];
    $itemType = $_POST['itemType'];

    if ($id == '') {
        // Adicionar nova categoria
        $sql = "INSERT INTO category_items (name, type, itemType) VALUES (:name, :type, :itemType)";
        $stmt = $db->prepare($sql);
        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':type', $type);
        $stmt->bindParam(':itemType', $itemType);
        $stmt->execute();
        header("Location: manage_item_category.php?a=1");
    } else {
        // Atualizar categoria existente
        $sql = "UPDATE category_items SET name = :name, type = :type, itemType = :itemType WHERE id = :id";
        $stmt = $db->prepare($sql);
        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':type', $type);
        $stmt->bindParam(':itemType', $itemType);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        header("Location: manage_item_category.php?a=1");
    }
}

if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $sql = "DELETE FROM category_items WHERE id = :id";
    $stmt = $db->prepare($sql);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    header("Location: manage_item_category.php?a=2");
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "SELECT * FROM category_items WHERE id = :id";
    $stmt = $db->prepare($sql);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    $category = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($category) {
        $name = $category['name'];
        $type = $category['type'];
        $itemType = $category['itemType'];
    }
}

// Fetch categories from the database
$stmt = $db->prepare("SELECT * FROM category_items WHERE type = '0'");
$stmt->execute();
$categories = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en" data-sidenav-size="fullscreen">
<head>
    <meta charset="utf-8" />
    <title><?php echo lang('Dashboard'); ?> | <?php echo SITE_TITLE; ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="<?php echo META_DESCRIPTION;?>" name="description" />
		<meta name="keywords" content="<?php echo META_KEYWORDS;?>">
        <meta content="SITE_TITLE" name="author" />
    <link rel="shortcut icon" href="assets/images/favicon.ico">
    <link rel="stylesheet" href="assets/vendor/daterangepicker/daterangepicker.css">
    <link rel="stylesheet" href="assets/vendor/admin-resources/jquery.vectormap/jquery-jvectormap-1.2.2.css">
    <script src="assets/js/hyper-config.js"></script>
    <link href="assets/css/app-saas.min.css" rel="stylesheet" type="text/css" id="app-style" />
    <script src="js/Chart.js"></script>
    <script src="js/jquery.js"></script>
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
</head>

<body>
    <div class="wrapper">
        <?php include 'includes/topbar.php';?>

        <div class="leftside-menu">
            <div class="button-sm-hover" data-bs-toggle="tooltip" data-bs-placement="right" title="Show Full Sidebar">
                <i class="ri-checkbox-blank-circle-line align-middle"></i>
            </div>

            <div class="button-close-fullsidebar">
                <i class="ri-close-fill align-middle"></i>
            </div>

            <div class="h-100" id="leftside-menu-container" data-simplebar>
                <?php include 'includes/sidebar2.php';?>
                <div class="clearfix"></div>
            </div>
        </div>

        <div class="content-page">
            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-8" style="margin:0 auto;">
                            <div class="page-title-box">
                                <?php if ($id != ''): ?>								
                                    <div class="page-title-right">
                                        <form class="d-flex">
                                            <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#danger-header-modal">Delete</button>
                                        </form>
                                    </div>
                                <?php endif; ?>
                                <h4 class="page-title"><?php echo $id == '' ? lang('Add') : lang('Edit'); ?> <?php echo lang('Category');?></h4>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="card col-xl-8 col-lg-8" style="margin:0 auto;">
                            <?php
                            if (isset($_GET['a'])) {
                                $error = $_GET['a'];
                                switch ($error) {
                                    case 1:
                                        echo '<div class="alert alert-success" role="alert"><strong>' . lang('Category added successfully!') . '</strong></div>';
                                        break;
                                    case 2:
                                        echo '<div class="alert alert-danger bg-transparent text-danger" role="alert"><strong>' . lang('Deleted.') . '</strong></div>';
                                        break;
                                }
                            }
                            ?>

                            <form action="manage_item_category.php" method="post">
                                <input type="hidden" name="id" value="<?php echo $id; ?>">
                                <div class="mb-3">
                                    <h4 for="simpleinput" class="form-label"><?php echo lang('Name'); ?>:</h4>
                                    <input type="text" name="name" id="simpleinput" value="<?php echo $name; ?>" class="form-control" required>
                                </div>
                                <div class="mb-3">
                                    <label for="example-fileinput" class="form-label"><?php echo lang('Parent or Child'); ?>:</label>
                                    <select name="type" class="form-select mb-3" required>
                                        <option value="0" <?php echo $type == 0 ? 'selected' : ''; ?>><?php echo lang('Parent'); ?></option>
                                        <option value="1" <?php echo $type == 1 ? 'selected' : ''; ?>><?php echo lang('Child'); ?></option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label for="example-fileinput" class="form-label"><?php echo lang('Item Type'); ?>:</label>
                                    <select name="itemType" class="form-select mb-3" required>
                                        <option value="0"><?php echo lang('none'); ?></option>
                                        <?php foreach ($categories as $category): ?>
                                            <option value="<?php echo $category['id']; ?>" <?php echo $itemType == $category['id'] ? 'selected' : ''; ?>><?php echo $category['name']; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="d-grid">
                                    <button type="submit" style="margin-bottom:10px;" class="btn btn-lg btn-primary"><?php echo lang($id == '' ? 'Add' : 'Update'); ?></button>
                                </div>
                            </form>
                        </div>
                    </div>
					
					<div class="row" style="margin-top: 20px;">
                            <div class="card col-xl-8 col-lg-8" style="margin:0 auto;">
                                <div class="">
                                    <div class="card-body">
                                        
						<script src="assets/js/pages/demo.datatable-init.js"></script>                            
							<table id="basic-datatable" class="table dt-responsive nowrap w-100">
								<thead>
									<tr>
										<th><?php echo lang('Title'); ?></th>
										<th><?php echo lang('Type'); ?></th>
										<th><?php echo lang('Parent'); ?></th>
										<th><?php echo lang('Actions'); ?></th>
									</tr>
								</thead>
								<tbody>
								<?php
									$result = $db->query("SELECT * FROM category_items")->fetchAll(PDO::FETCH_ASSOC);

									foreach ($result as $row) {
								?>
									<tr>
										<td><a href="manage_item_category.php?id=<?php echo $row['id'];?>" class="link-primary"><?php echo $row['name'];?></a></td>
										<td><?php echo $row['type'] == 0 ? lang('Parent') : lang('Child'); ?></td>
										<td>
											<?php
											if ($row['type'] == 0) {
												echo lang('Parent');
											} else {
												$mainCatID = $row['itemType'];
												$getCatname = $db->query("SELECT name FROM category_items WHERE id = $mainCatID")->fetch(PDO::FETCH_ASSOC);
												echo $getCatname['name'];
											}
											?>
										</td>
										<td>
											<a href="manage_item_category.php?id=<?php echo $row['id'];?>" class="btn btn-sm btn-warning"><?php echo lang('Edit'); ?></a>
											<a href="manage_item_category.php?delete=<?php echo $row['id'];?>" class="btn btn-sm btn-danger" onclick="return confirm('<?php echo lang('Are you sure you want to delete this category?'); ?>');"><?php echo lang('Delete'); ?></a>
										</td>
									</tr>
									<?php } ?>
								</tbody>
							</table>
					</div> 
					</div> 
					</div>
					</div>
                </div>
            </div>
        </div>
    </div>

    <?php include 'includes/footer.php';?>

    <div class="rightbar-overlay"></div>

    <script src="assets/js/vendor.min.js"></script>
    <script src="assets/vendor/daterangepicker/moment.min.js"></script>
    <script src="assets/vendor/daterangepicker/daterangepicker.js"></script>
    <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
    <script src="assets/vendor/admin-resources/jquery.vectormap/jquery-jvectormap-1.2.2.min.js"></script>
    <script src="assets/vendor/admin-resources/jquery.vectormap/maps/jquery-jvectormap-world-mill-en.js"></script>
    <script src="assets/js/pages/demo.apex-line.js"></script>
    <script src="assets/js/app.min.js"></script>
</body>
</html>
