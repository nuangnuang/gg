<?php
require 'config.php';
require 'core/functions.php'; 
include 'language.php'; 
require 'libs/PHPMailer/src/Exception.php';
require 'libs/PHPMailer/src/PHPMailer.php';
require 'libs/PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

try {
    $db = new Database();
    $conn = $db->getConnection();
} catch (Exception $e) {
    echo "Database connection error: " . $e->getMessage();
    exit;
}

// Carregar o arquivo JSON com os códigos dos países
$countriesJson = file_get_contents('countries.json');
$countries = json_decode($countriesJson, true);

$firstName = $_POST['firstName'];
$secondName = $_POST['secondName'];
$country = $_POST['country'];
$username = $_POST['username'];
$email = $_POST['email'];
$password = $_POST['password'];
$emailVerification = isset($_POST['emailVerification']) ? $_POST['emailVerification'] : 0; // Nova variável para verificação por email
$id = Utils::generateId();

// Verificar se o país existe no JSON e obter o código do país
if (!isset($countries[$country])) {
    echo "Invalid country";
    exit;
}

// Verificar se o email é válido
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo "Invalid email address";
    exit;
}

// Verificar se a senha tem pelo menos 6 caracteres
if (strlen($password) < 6) {
    echo "Password must be at least 6 characters long";
    exit;
}

// Verificar se o nome de usuário é válido
if (!preg_match('/^[a-zA-Z0-9]{6,16}$/', $username)) {
    echo "Username must be 6-16 characters long and contain only letters and numbers";
    exit;
}

$countryCode = $countries[$country];

// Verificar se o nome de usuário já existe na tabela userlogin
$sql = "SELECT * FROM userlogin WHERE username = :username";
$stmt = $conn->prepare($sql);
$stmt->execute(['username' => $username]);

if ($stmt->rowCount() > 0) {
    echo "Username already exists";
    exit;
}

// Verificar se o e-mail já existe na tabela userlogin
$sql = "SELECT * FROM userlogin WHERE email = :email";
$stmt = $conn->prepare($sql);
$stmt->execute(['email' => $email]);

if ($stmt->rowCount() > 0) {
    echo "Email already exists";
    exit;
}

// Utilizando MD5 para a senha
$hashed_password = md5($password);

// Iniciar uma transação
$conn->beginTransaction();

try {
    // Inserir na tabela userlogin
    $sql = "INSERT INTO userlogin (id, username, password, email, authType) VALUES (:id, :username, :password, :email, :authType)";
    $stmt = $conn->prepare($sql);
    $userlogin_success = $stmt->execute([
        'id' => $id,
        'username' => $username,
        'password' => $hashed_password,
        'email' => $email,
        'authType' => 1
    ]);
    
    // Inserir na tabela user_info
    $sql = "INSERT INTO user_info (id, first_name, last_name, country, country_code) VALUES (:id, :first_name, :last_name, :country, :country_code)";
    $stmt = $conn->prepare($sql);
    $userinfo_success = $stmt->execute([
        'id' => $id,
        'first_name' => $firstName,
        'last_name' => $secondName,
        'country' => $country,
        'country_code' => $countryCode
    ]);

    if ($userlogin_success && $userinfo_success) {
        // Verificar se a verificação por email está ativada
        if ($emailVerification == "1") {
            // Enviar email de ativação
            $activationLink = SITE_URL . "/activate.php?id=$id";
            $subject = "Account Activation";
            $body = "Click on the following link to activate your account: <a href=\"$activationLink\">$activationLink</a>";

            if (sendEmail($email, $subject, $body)) {
                echo "Activation email sent";
            } else {
                echo "Failed to send activation email.";
            }
        } else {
            echo "Registration successful";
        }

        // Confirmar a transação
        $conn->commit();
    } else {
        // Reverter a transação
        $conn->rollBack();
        echo "Error: Unable to complete registration";
    }
} catch (Exception $e) {
    // Reverter a transação em caso de erro
    $conn->rollBack();
    echo "Error: " . $e->getMessage();
}

// Função para enviar email
function sendEmail($to, $subject, $body) {
    $mail = new PHPMailer(true);

    try {
        // Configurações do servidor de email (substitua com suas configurações)
        $mail->isSMTP();
        $mail->Host = EMAIL_HOST;
        $mail->SMTPAuth = true;
        $mail->Username = EMAIL_USER;
        $mail->Password = EMAIL_PASS;
        $mail->SMTPSecure = 'tls';
        $mail->Port = EMAIL_PORT;

        // Remetente
        $mail->setFrom(EMAIL_FROM, EMAIL_NAME);

        // Destinatário
        $mail->addAddress($to);

        // Conteúdo do email
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body = $body;

        $mail->send();
        return true;
    } catch (Exception $e) {
        return false;
    }
}
?>
