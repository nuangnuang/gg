<?php
// Database settings
define('DB_HOST', 'localhost'); // Database server address
define('DB_USER', ''); // Database username
define('DB_PASS', ''); // Database password
define('DB_NAME', ''); // Database name

// Website settings
define('SITE_TITLE', 'Website Name'); // Website title
define('SITE_SUBTITLE', 'Free MMORPG'); // Website subtitle
define('SITE_URL', 'http://yourdomain.com'); // Website URL
define('SITE_EMAIL', 'contact@example.com'); // Website email address

define('EMAIL_FROM', 'noreply@example.com');
define('EMAIL_NAME', 'Website Name');
define('EMAIL_HOST', 'mail.example.com');
define('EMAIL_PORT', 587);
define('EMAIL_USER', 'example');
define('EMAIL_PASS', 'password');

// Language setting
define('DEFAULT_LANGUAGE', 'en'); // Default website language

// Metadata configuration
define('META_DESCRIPTION', 'A MMORPG SITE'); // Site description for SEO
define('META_KEYWORDS', 'MMORPG, massively multiplayer online role-playing game, online game, fantasy game, virtual world, role-playing, RPG, adventure, quests, leveling up, character customization, fantasy creatures, dungeons, guilds, PvP, PvE, raiding, loot, gear, skills, magic, spells, classes, races, open world, exploration, crafting, economy, player interaction, social gaming, community, events, updates'); // SEO keywords

// Class settings
$array_Class = ['Archer', 'Assassin', 'Healer', 'Knight', 'Mage'];

// Faction settings
$array_Factions = ['Aeris', 'Aquis', 'Ignis', 'Terranum'];

// Session configuration (optional)
// define('SESSION_LIFETIME', 3600); // Session lifetime in seconds

// Error configuration (uncomment to enable in development environment)
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
error_reporting(E_ALL & ~E_DEPRECATED & ~E_WARNING);

?>
