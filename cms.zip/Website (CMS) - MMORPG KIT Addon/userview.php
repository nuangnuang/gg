<?php
session_start();
	require 'protected.php';
	checkLogin();
	checkUserLevel(5, 'index.php');
require 'config.php';
require 'core/functions.php'; 
require 'language.php';


// Instanciar a classe Database
$database = new Database();
$db = $database->getConnection();

// Processar o envio do formulário
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Capturar os dados do formulário
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $country = $_POST['country'];
    $country_code = $_POST['country_code'];

    // Obter o ID do usuário da sessão
    $user_id = $_GET['id'];

    // Verificar se já existe uma entrada para este usuário
    $stmt_check = $db->prepare("SELECT * FROM user_info WHERE id = ?");
    $stmt_check->execute([$user_id]);
    $existing_user_info = $stmt_check->fetch(PDO::FETCH_ASSOC);

    if ($existing_user_info) {
        // Atualizar as informações do usuário na tabela 'user_info'
        $stmt_update = $db->prepare("UPDATE user_info SET first_name = ?, last_name = ?, country = ?, country_code = ? WHERE id = ?");
        $stmt_update->execute([$first_name, $last_name, $country, $country_code, $user_id]);
    } else {
        // Inserir as informações do usuário na tabela 'user_info'
        $stmt_insert = $db->prepare("INSERT INTO user_info (id, first_name, last_name, country, country_code) VALUES (?, ?, ?, ?, ?)");
        $stmt_insert->execute([$user_id, $first_name, $last_name, $country, $country_code]);
    }

    // Redirecionar para a página de perfil com uma mensagem de sucesso
    header('Location: user.php?success=1');
    exit;
}

// Obter as informações do usuário, se disponíveis
$user_id = $user_id = $_GET['id'];
$stmt = $db->prepare("SELECT * FROM user_info WHERE id = ?");
$stmt->execute([$user_id]);
$user_info = $stmt->fetch(PDO::FETCH_ASSOC);

// Obter a lista de países
$countries_json = file_get_contents('countries.json');
$countries = json_decode($countries_json, true);
?>

<!DOCTYPE html>
<html lang="en" data-sidenav-size="fullscreen">
<head>
    <meta charset="utf-8" />
    <title>User Profile | <?php echo SITE_TITLE; ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="<?php echo META_DESCRIPTION;?>" name="description" />
		<meta name="keywords" content="<?php echo META_KEYWORDS;?>">
        <meta content="SITE_TITLE" name="author" />
    <link rel="shortcut icon" href="assets/images/favicon.ico">
    <link rel="stylesheet" href="assets/vendor/daterangepicker/daterangepicker.css">
    <link rel="stylesheet" href="assets/vendor/admin-resources/jquery.vectormap/jquery-jvectormap-1.2.2.css">
    <script src="assets/js/hyper-config.js"></script>
    <link href="assets/css/app-saas.min.css" rel="stylesheet" type="text/css" id="app-style" />
    <script src="js/Chart.js"></script>
    <script src="js/jquery.js"></script>
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
</head>

<body>
    <div class="wrapper">
        <?php include 'includes/topbar.php';?>

        <div class="leftside-menu">
            <div class="button-sm-hover" data-bs-toggle="tooltip" data-bs-placement="right" title="Show Full Sidebar">
                <i class="ri-checkbox-blank-circle-line align-middle"></i>
            </div>

            <div class="button-close-fullsidebar">
                <i class="ri-close-fill align-middle"></i>
            </div>

            <div class="h-100" id="leftside-menu-container" data-simplebar>
                <?php include 'includes/sidebar2.php';?>
                <div class="clearfix"></div>
            </div>
        </div>

        <div class="content-page">
            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-8" style="margin:0 auto;">
                            <div class="page-title-box">
                                
                                <h4 class="page-title"><?php echo lang('User Profile'); ?></h4>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="card col-xl-8 col-lg-8" style="margin:0 auto;">
                            <form action="user.php" method="post" style="margin-top:10px;">
                                <div class="mb-3">
                                    <label for="first_name" class="form-label">First Name:</label>
                                    <input type="text" id="first_name" name="first_name" value="<?= $user_info['first_name'] ?? '' ?>" class="form-control" required>
                                </div>
                                <div class="mb-3">
                                    <label for="last_name" class="form-label">Last Name:</label>
                                    <input type="text" id="last_name" name="last_name" value="<?= $user_info['last_name'] ?? '' ?>" class="form-control" required>
                                </div>
                                <div class="mb-3">
                                    <label for="country" class="form-label">Country:</label>
                                    <select id="country" name="country" onchange="updateCountryCode()" class="form-select">
                                        <option value="">Select a country</option>
                                        <?php foreach ($countries as $country => $code): ?>
                                            <option value="<?= $country ?>" <?= (($user_info['country'] ?? '') == $country ? "selected" : "") ?>><?= $country ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label for="country_code" class="form-label">Country Code:</label>
                                    <input type="text" id="country_code" name="country_code" readonly value="<?= $user_info['country_code'] ?? '' ?>" class="form-control">
                                </div>
                                <div class="d-grid">
                                    <button type="submit" class="btn btn-lg btn-primary">Save</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include 'includes/footer.php';?>

    <div class="rightbar-overlay"></div>

    <script src="assets/js/vendor.min.js"></script>
    <script src="assets/vendor/daterangepicker/moment.min.js"></script>
    <script src="assets/vendor/daterangepicker/daterangepicker.js"></script>
	<script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
    <script src="assets/vendor/admin-resources/jquery.vectormap/jquery-jvectormap-1.2.2.min.js"></script>
    <script src="assets/vendor/admin-resources/jquery.vectormap/maps/jquery-jvectormap-world-mill-en.js"></script>
    <script src="assets/js/pages/demo.apex-line.js"></script>
    <script src="assets/js/app.min.js"></script>
    <script>
        function updateCountryCode() {
            var countrySelect = document.getElementById('country');
            var countryCodeInput = document.getElementById('country_code');
            var selectedCountry = countrySelect.value;
            var countries = <?php echo json_encode($countries); ?>;
            
            countryCodeInput.value = countries[selectedCountry] || '';
        }
    </script>
</body>
</html>

