<?php 

require 'protected.php';
include 'config.php';
	require 'core/functions.php'; 
	include 'language.php'; 
	


?>

<!DOCTYPE html>
<html lang="en" data-layout="topnav">

    <head>
        <meta charset="utf-8" />
        <title>Horizontal Layout | Hyper - Responsive Bootstrap 5 Admin Dashboard</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="<?php echo META_DESCRIPTION;?>" name="description" />
		<meta name="keywords" content="<?php echo META_KEYWORDS;?>">
        <meta content="SITE_TITLE" name="author" />

        <!-- App favicon -->
        <link rel="shortcut icon" href="assets/images/favicon.ico">

        <!-- Plugin css -->
        <link rel="stylesheet" href="assets/vendor/daterangepicker/daterangepicker.css">
        <link href="assets/vendor/admin-resources/jquery.vectormap/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css" />

        <!-- Theme Config Js -->
        <script src="assets/js/hyper-config.js"></script>

        <!-- App css -->
        <link href="assets/css/app-saas.min.css" rel="stylesheet" type="text/css" />

        <!-- Icons css -->
        <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    </head>

    <body>
        <!-- Begin page -->
        <div class="wrapper">

            

		<?php include('includes/topnav.php'); ?>

            
            <div class="content-page" style="max-width: 1300px; margin:0 auto;">
                <div class="content">
                    
                    <!-- Start Content-->
                    <div class="container-fluid">
					<?php 
						
						if (isset($_GET['id'])) {
										$itemId = $_GET['id'];
										$itemId = filter_var($itemId, FILTER_SANITIZE_STRING);
										// Defina as condições desejadas como um array
										$conditions = ["id = '$itemId'"];

										// Use a função fetchRecords para buscar registros em uma tabela com condições
										$result = fetchRecords('items', '*', $conditions);
									
									}else{

										// Use a função fetchRecords para buscar registros em uma tabela com condições
										$result = fetchRecords('items', '*');
									}
						
						
						foreach ($result as $item): ?>





                        <div class="row" style="margin-top:20px;">
					
                            <div class="col-xl-8 col-lg-12 order-lg-2 order-xl-1">
							
                                <div class="card ribbon-box">
                                    <div class="card-body">
									<div class="ribbon ribbon-dark float-end"><i class="mdi mdi-crown me-1"></i> level: <?php echo $item['level']; ?></div>
									<div class="ribbon ribbon-dark float-end"><i class="mdi mdi-star-outline me-1"></i> <?php
										
											$typeId = $item['category'];
											if ($typeId != 0){
											$conditionsss = ["id = '$typeId'"];
											$cat = fetchRecords('category_items', '*', $conditionsss);
											foreach ($cat as $rows) {
												 echo $rows['name'];; 
											
											}
											}else{
												echo lang('None');
											}
										
										?></div>
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <h4 class="header-title"><?php echo $item['name']; ?></h4>
                                        </div>
										
						<div class="row">
                            <div class="col-4 center" > 
								<img class="d-block img-fluid" style="important;width: 200px !important; height: 200px !important;" src="<?php echo $item['image']; ?>">
								<h4 class="header-title " style="text-align: center !important; margin-top:10px;">
								
								</h4>
                            </div>
							<div class="col-8 center" > 
								<h6 class="header-title"><?php echo lang('Description'); ?></h6>
								<p><?php 
									if ($item['description'] == ''){
										echo lang('No description.');
									}else{
										echo $item['description'];
									}


								?></p>
								<h6 class="header-title"><?php echo lang('Stats'); ?></h6>
								<p>
								<?php 
									if ($item['stats'] == ''){
										echo lang('No Stats.');
									}else{
										echo $item['stats'];
									}


								?>
								</p>
								<h6 class="header-title"><?php echo lang('Conditions'); ?></h6>
								<p><?php echo $item['conditions']; ?>
								<?php 
									if ($item['conditions'] == ''){
										echo lang('No conditions.');
									}else{
										echo $item['conditions'];
									}


								?>
								
								</p>
                            </div>

                    </div> <!-- end col -->
						<div class="row" style="margin-top:20px;">
                            <div class="col-lg-12">
                                <?php echo $item['content']; ?>
                            </div> <!-- end col-->
                        </div>
						<?php endforeach; ?>

                                    </div> <!-- end card-body-->
                                </div> <!-- end card-->
                            </div> <!-- end col-->
							<div class="col-xl-3 col-lg-6 order-lg-1">
                                <div class="card">
                                    <div class="card-body pb-0">
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <h4 class="header-title">Item Type</h4>
                                        </div>
                                    </div>

                                    <div class="card-body py-0 mb-3" data-simplebar> 
                                        <ul class="side-nav">


                        

                        

                        <li class="side-nav-item">
                            <a data-bs-toggle="collapse" href="#weapons" aria-expanded="false" aria-controls="sidebarEcommerce" class="side-nav-link">
                                <i class="mdi mdi-sword"></i>
                                <span> Weapons </span>
                                <span class="menu-arrow"></span>
                            </a>
                            <div class="collapse" id="weapons">
                                <ul class="side-nav-second-level">
                                    <li>
                                        <a href="apps-ecommerce-products.html">All</a>
                                    </li>
									<li>
                                        <a href="apps-ecommerce-products.html">Bow</a>
                                    </li>
                                    <li>
                                        <a href="apps-ecommerce-products-details.html">Dagger</a>
                                    </li>
                                    <li>
                                        <a href="apps-ecommerce-orders.html">Spelbook</a>
                                    </li>
                                    <li>
                                        <a href="apps-ecommerce-orders-details.html">Sword</a>
                                    </li>
                                    <li>
                                        <a href="apps-ecommerce-customers.html">Wand</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
						<li class="side-nav-item">
                            <a data-bs-toggle="collapse" href="#equipaments" aria-expanded="false" aria-controls="sidebarEcommerce" class="side-nav-link">
                                <i class="mdi mdi-ring"></i>
                                <span> Equipaments </span>
                                <span class="menu-arrow"></span>
                            </a>
                            <div class="collapse" id="equipaments">
                                <ul class="side-nav-second-level">
									<li>
                                        <a href="apps-ecommerce-products.html">All</a>
                                    </li>
                                    <li>
                                        <a href="apps-ecommerce-products.html">Helmet</a>
                                    </li>
                                    <li>
                                        <a href="apps-ecommerce-products-details.html">Gloves</a>
                                    </li>
                                    <li>
                                        <a href="apps-ecommerce-orders.html">Amulets</a>
                                    </li>
                                    <li>
                                        <a href="apps-ecommerce-orders-details.html">Rings</a>
                                    </li>
                                    <li>
                                        <a href="apps-ecommerce-customers.html">Belts</a>
                                    </li>
									<li>
                                        <a href="apps-ecommerce-customers.html">Shooes</a>
                                    </li>
									<li>
                                        <a href="apps-ecommerce-customers.html">Shields</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
						<li class="side-nav-item">
                            <a data-bs-toggle="collapse" href="#consumables" aria-expanded="false" aria-controls="sidebarEcommerce" class="side-nav-link">
                                <i class="uil uil-flask-potion"></i>
                                <span> Consumables </span>
                                <span class="menu-arrow"></span>
                            </a>
                            <div class="collapse" id="consumables">
                                <ul class="side-nav-second-level">
									<li>
                                        <a href="apps-ecommerce-products.html">All</a>
                                    </li>
                                    <li>
                                        <a href="apps-ecommerce-products.html">Breads</a>
                                    </li>
                                    <li>
                                        <a href="apps-ecommerce-products-details.html">Potions</a>
                                    </li>
                                    <li>
                                        <a href="apps-ecommerce-orders.html">Scrolls</a>
                                    </li>
                                    <li>
                                        <a href="apps-ecommerce-orders-details.html">Boxes</a>
                                    </li>
                                    <li>
                                        <a href="apps-ecommerce-customers.html">Fruits</a>
                                    </li>
									<li>
                                        <a href="apps-ecommerce-customers.html">Teleport Potions</a>
                                    </li>
                                </ul>
                            </div>
                        </li>

                    </ul>

       
                                        <!-- end timeline -->
                                    </div> <!-- end slimscroll -->
                                </div>
                                <!-- end card-->
                            </div>
                            <!-- end col -->

                        </div>
                        <!-- end row -->
						
						
                    </div>
                    <!-- container -->
					

                </div>
                <!-- content -->

                <!-- Footer Start -->
                <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-6">
                                <script>document.write(new Date().getFullYear())</script> © <?php echo SITE_TITLE; ?>
                            </div>
                            <div class="col-md-6">
                                <div class="text-md-end footer-links d-none d-md-block">
                                    <a href="javascript: void(0);">About</a>
                                    <a href="javascript: void(0);">Support</a>
                                    <a href="javascript: void(0);">Contact Us</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </footer>
                <!-- end Footer -->

            </div>

            <!-- ============================================================== -->
            <!-- End Page content -->
            <!-- ============================================================== -->

        </div>
        <!-- END wrapper -->

   
        
        <!-- Vendor js -->
        <script src="assets/js/vendor.min.js"></script>

        <!-- Daterangepicker js -->
        <script src="assets/vendor/daterangepicker/moment.min.js"></script>
        <script src="assets/vendor/daterangepicker/daterangepicker.js"></script>
        
        <!-- Apex Charts js -->
        <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>

        <!-- Vector Map js -->
        <script src="assets/vendor/admin-resources/jquery.vectormap/jquery-jvectormap-1.2.2.min.js"></script>
        <script src="assets/vendor/admin-resources/jquery.vectormap/maps/jquery-jvectormap-world-mill-en.js"></script>

        <!-- Dashboard App js -->
        <script src="assets/js/pages/demo.dashboard.js"></script>
		
		<!-- Code Highlight js -->
        <script src="assets/vendor/highlightjs/highlight.pack.min.js"></script>
        <script src="assets/vendor/clipboard/clipboard.min.js"></script>
        <script src="assets/js/hyper-syntax.js"></script>

        <!-- App js -->
        <script src="assets/js/app.min.js"></script>

    </body>
</html>