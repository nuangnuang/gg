<?php
require 'config.php';
require 'core/functions.php'; 
include 'language.php'; 

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newsId = $_POST['news_id'];
    $username = $_POST['username'];
    $comment = $_POST['comment'];

    // Insert comment into the database
    $stmt = $conn->prepare("INSERT INTO comments (news_id, username, comment) VALUES (?, ?, ?)");
    $stmt->execute([$newsId, $username, $comment]);

    echo "Comment added successfully!";
}

// Fetch comments for a specific news article
$newsId = $_GET['id'];
$stmt = $conn->prepare("SELECT * FROM comments WHERE news_id = ?");
$stmt->execute([$newsId]);
$comments = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Comments</title>
</head>
<body>
    <h2>Comments</h2>
    <form method="post" action="comments.php?id=<?php echo $newsId; ?>">
        <input type="hidden" name="news_id" value="<?php echo $newsId; ?>">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required><br>
        <label for="comment">Comment:</label>
        <textarea id="comment" name="comment" required></textarea><br>
        <button type="submit">Add Comment</button>
    </form>

    <?php foreach ($comments as $comment): ?>
        <div>
            <p><strong><?php echo $comment['username']; ?>:</strong></p>
            <p><?php echo $comment['comment']; ?></p>
            <p><?php echo $comment['created_at']; ?></p>
        </div>
    <?php endforeach; ?>
</body>
</html>
