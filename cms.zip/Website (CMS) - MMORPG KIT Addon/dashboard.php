<?php 
session_start();

	include 'config.php';
	require 'core/functions.php'; 
	require 'protected.php';
	checkLogin();
	checkUserLevel(5, 'index.php');

	include 'language.php'; 
	include 'includes/dashboard.php'; 
	

	

	

?>

<!DOCTYPE html>
<html lang="en" data-sidenav-size="fullscreen">

    <head>
        <meta charset="utf-8" />
        <title> <?php echo lang('Dashboard'); ?> | <?php echo SITE_TITLE; ?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="<?php echo META_DESCRIPTION;?>" name="description" />
		<meta name="keywords" content="<?php echo META_KEYWORDS;?>">
        <meta content="SITE_TITLE" name="author" />

        <!-- App favicon -->
        <link rel="shortcut icon" href="assets/images/favicon.ico">

        <!-- Daterangepicker css -->
        <link rel="stylesheet" href="assets/vendor/daterangepicker/daterangepicker.css">

        <!-- Vector Map css -->
        <link rel="stylesheet" href="assets/vendor/admin-resources/jquery.vectormap/jquery-jvectormap-1.2.2.css">

        <!-- Theme Config Js -->
        <script src="assets/js/hyper-config.js"></script>

        <!-- App css -->
        <link href="assets/css/app-saas.min.css" rel="stylesheet" type="text/css" id="app-style" />

        <!-- Icons css -->
        <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    </head>

    <body>
        <!-- Begin page -->
        <div class="wrapper">

            <?php include 'includes/topbar.php';?> 

            <!-- ========== Left Sidebar Start ========== -->
            <div class="leftside-menu">

               

                

                <!-- Sidebar Hover Menu Toggle Button -->
                <div class="button-sm-hover" data-bs-toggle="tooltip" data-bs-placement="right" title="Show Full Sidebar">
                    <i class="ri-checkbox-blank-circle-line align-middle"></i>
                </div>

                <!-- Full Sidebar Menu Close Button -->
                <div class="button-close-fullsidebar">
                    <i class="ri-close-fill align-middle"></i>
                </div>

                <!-- Sidebar -left -->
                <div class="h-100" id="leftside-menu-container" data-simplebar>
                    <!-- Leftbar User -->
                    
<?php include 'includes/sidebar2.php';?>
                    <!--- End Sidemenu -->

                    <div class="clearfix"></div>
                </div>
            </div>
            <!-- ========== Left Sidebar End ========== -->

            <!-- ============================================================== -->
            <!-- Start Page Content here -->
            <!-- ============================================================== -->

            <div class="content-page">
                <div class="content">

                    <!-- Start Content-->
                    <div class="container-fluid">

                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">                                    
                                    
                                    <h4 class="page-title"><?php echo lang('Dashboard'); ?></h4>
                                </div>
                            </div>
                        </div>

                        <div class="row">
						
                            <div class="col-xl-5 col-lg-6">

                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="card widget-flat">
                                            <div class="card-body">
                                                <div class="float-end">
                                                    
                                                </div>
                                                <h5 class="text-muted fw-normal mt-0" title="Number of Customers"><?php echo lang('Players Online'); ?></h5>
                                                <h3 class="mt-3 mb-3"><?php echo $playersOnline; ?></h3>
                                                <p class="mb-0 text-muted">
                                                    <a href="#"> <span class="text-nowrap"><?php echo lang(''); ?></span></a>
                                                </p>
                                            </div> <!-- end card-body-->
                                        </div> <!-- end card-->
                                    </div> <!-- end col-->

                                    <div class="col-sm-6">
                                        <div class="card widget-flat">
                                            <div class="card-body">
                                                <div class="float-end">
                                                    
                                                </div>
                                                <h5 class="text-muted fw-normal mt-0" title="Number of Accounts"><?php echo lang('Accounts'); ?></h5>
                                                <h3 class="mt-3 mb-3"><?php echo $totalAccounts; ?></h3>
                                                <p class="mb-0 text-muted">
                                                   <a href="accounts.php"> <span class="text-nowrap"><?php echo lang('View List'); ?></span></a>
                                                </p>
                                            </div> <!-- end card-body-->
                                        </div> <!-- end card-->
                                    </div> <!-- end col-->
                                </div> <!-- end row -->

                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="card widget-flat">
                                            <div class="card-body">
                                                <div class="float-end">
                                                   
                                                </div>
                                                <h5 class="text-muted fw-normal mt-0" title="Average Revenue"><?php echo lang('Characters'); ?></h5>
                                                <h3 class="mt-3 mb-3"><?php echo $totalCharacters; ?></h3>
                                                <p class="mb-0 text-muted">
                                                    <a href="characters.php"> <span class="text-nowrap"><?php echo lang('View List'); ?></span></a>
                                                </p>
                                            </div> <!-- end card-body-->
                                        </div> <!-- end card-->
                                    </div> <!-- end col-->

                                    <div class="col-sm-6">
                                        <div class="card widget-flat">
                                            <div class="card-body">
                                                <div class="float-end">
                                                    
                                                </div>
                                                <h5 class="text-muted fw-normal mt-0" title="Growth"><?php echo lang('Banned Accounts'); ?></h5>
                                                <h3 class="mt-3 mb-3"><?php echo $bannedAccounts; ?></h3>
                                                <p class="mb-0 text-muted">
                                                    <a href="accounts.php?list=banned"> <span class="text-nowrap"><?php echo lang('View List'); ?></span></a>
                                                </p>
                                            </div> <!-- end card-body-->
                                        </div> <!-- end card-->
                                    </div> <!-- end col-->
                                </div> <!-- end row -->

                            </div> <!-- end col -->

                            <div class="col-xl-7 col-lg-6">
                                <div class="card card-h-100">
                                    <div class="d-flex card-header justify-content-between align-items-center">
                                        <h4 class="header-title"><?php echo lang('Classes'); ?></h4>
                                        
                                    </div>
                                    <div class="card-body pt-0" style="height:400px !important;">
                                        <div dir="ltr">
                                            <div id="distributed-column" class="apex-charts" data-colors="#727cf5,#6c757d,#0acf97,#fa5c7c,#ffbc00,#39afd1,#e3eaef,#313a46"></div>
                                        </div>
                                            
                                    </div> <!-- end card-body-->
                                </div> <!-- end card-->

                            </div> <!-- end col -->
                        </div>
                        <!-- end row -->

                        <div class="row">
						<div class="col-xl-7 col-lg-6">
                                <div class="card card-h-100">
                                    <div class="d-flex card-header justify-content-between align-items-center">
                                        <h4 class="header-title"><?php echo lang('Factions'); ?></h4>
                                        
                                    </div>
                                    <div class="card-body pt-0" style="height:400px !important;">
                                        <div dir="ltr">
                                            <div id="distributed-columna" class="apex-charts" data-colors="#727cf5,#6c757d,#0acf97,#fa5c7c,#ffbc00,#39afd1,#e3eaef,#313a46"></div>
                                        </div>
                                            
                                    </div> <!-- end card-body-->
                                </div> <!-- end card-->

                            </div> <!-- end col -->
                            <div class="col-lg-4">
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="header-title"><?php echo lang('Quantity of Characters per level'); ?></h4>
                                        <div dir="ltr">
                                            <div id="grouped-bar" class="apex-charts" data-colors="#8790f6,#fa5c7c,#0c701d"></div>
                                        </div>
                                    </div>
                                 </div> <!-- end card-->
                            </div> <!-- end col-->
                        </div>
                        <!-- end row -->
						<div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="d-flex card-header justify-content-between align-items-center">
                                        <h4 class="header-title"><?php echo lang('players by country');?></h4>
                                        
                                    </div>

                                    <div class="card-body pt-0">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <div id="world-map-markers" class="mt-3 mb-3" style="height: 300px">
                                                </div>
                                            </div>
                                            <div class="col-lg-4" dir="ltr">
                                                <div id="country-chart" class="apex-charts" data-colors="#727cf5"></div>
                                            </div>
                                        </div>
                                    </div> <!-- end card-body-->
                                </div> <!-- end card-->
                            </div> <!-- end col-->
                        </div>
                        <!-- end row -->

                        <div class="row">
                            <div class="col-xl-12 col-lg-12 order-lg-2 order-xl-1">
                                <div class="card">
                                    <!-- Datatable Init js -->


            

                                    </div> <!-- end card-->
                            </div> <!-- end col-->


                           <!-- end col -->

                        </div>
                        <!-- end row -->

                    </div>
                    <!-- container -->

                </div>
                <!-- content -->

                

            </div>

            <!-- ============================================================== -->
            <!-- End Page content -->
            <!-- ============================================================== -->

        </div>
        <!-- END wrapper -->

        <!-- Vendor js -->
        <script src="assets/js/vendor.min.js"></script>

        <!-- Daterangepicker js -->
        <script src="assets/vendor/daterangepicker/moment.min.js"></script>
        <script src="assets/vendor/daterangepicker/daterangepicker.js"></script>
        
        <!-- Apex Charts js -->
        <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>

        <!-- Vector Map js -->
        <script src="assets/vendor/admin-resources/jquery.vectormap/jquery-jvectormap-1.2.2.min.js"></script>
        <script src="assets/vendor/admin-resources/jquery.vectormap/maps/jquery-jvectormap-world-mill-en.js"></script>

        
		 

      

        <!-- Apex Chart Column Demo js -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/dayjs/1.11.0/dayjs.min.js"></script>  
        <script src="https://cdnjs.cloudflare.com/ajax/libs/dayjs/1.11.0/plugin/quarterOfYear.min.js"></script>        
        <!--<script src="assets/js/pages/demo.apex-column.js"></script> -->
		<?php
			include 'js/graficosCollum.php';
			//include 'js/graficospie.php';
			include 'js/graficosbar.php';
			include 'js/demo.php';
		?>

        <!-- Apex Chart Area Demo js -->
        <script src="assets/js/app.min.js"></script>

    </body>
</html> 