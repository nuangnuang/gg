require('dotenv').config();
const { RestClientV5 } = require('bybit-api');
const TOKEN_SYMBOL = process.env.COIN;

const client = new RestClientV5({
  key: process.env.KEY,
  secret: process.env.SECRET,
  testnet: false,
});

async function getLastWithdrawalFee() {
  try {
    const response = await client.getWithdrawalRecords({
      coin: TOKEN_SYMBOL,
      limit: 1,
    });

    const withdrawal = response.result?.rows?.[0];
    if (!withdrawal) {
      console.log(`❌ Tidak ada data withdrawal untuk ${TOKEN_SYMBOL}`);
      return;
    }

    console.log(`💸 Fee ${TOKEN_SYMBOL}: ${withdrawal.withdrawFee || withdrawal.fee} ${TOKEN_SYMBOL}`);
  } catch (error) {
    console.error('❌ Gagal mengambil data fee:', error.message || error);
  }
}

getLastWithdrawalFee();
setInterval(getLastWithdrawalFee, 29000);
