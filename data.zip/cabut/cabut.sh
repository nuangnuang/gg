cat cabut.txt | parallel
