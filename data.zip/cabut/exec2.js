// main.js
const { spawn } = require('child_process');

const scripts = ['cabut3.js', 'cabut4.js'];

scripts.forEach(script => {
  const proc = spawn('node', [script], { stdio: 'inherit' });
});
