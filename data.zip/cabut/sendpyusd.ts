import 'dotenv/config';
import {
  Connection,
  Keypair,
  PublicKey,
  Transaction,
  sendAndConfirmTransaction,
} from "@solana/web3.js";
import {
  getAssociatedTokenAddressSync,
  createTransferInstruction,
  TOKEN_2022_PROGRAM_ID,
} from "@solana/spl-token";
import bs58 from "bs58";

const wallet1 = process.env.WALLET1;
const solWallet = process.env.SOLWALLET;
const token_mint = process.env.TOKENMINT;

// Ganti data berikut
const privateKeySender = wallet1;
const recipientPublicKey = new PublicKey(solWallet);
const tokenMint = new PublicKey(token_mint);

const connection = new Connection("https://api.mainnet-beta.solana.com", "confirmed");

(async () => {
  const sender = Keypair.fromSecretKey(bs58.decode(privateKeySender));
  const senderPubkey = sender.publicKey;

  const senderTokenAccount = getAssociatedTokenAddressSync(
    tokenMint,
    senderPubkey,
    false,
    TOKEN_2022_PROGRAM_ID
  );

  const recipientTokenAccount = getAssociatedTokenAddressSync(
    tokenMint,
    recipientPublicKey,
    false,
    TOKEN_2022_PROGRAM_ID
  );

  const amount = await connection.getTokenAccountBalance(senderTokenAccount);
  const rawAmount = BigInt(amount.value.amount);

  if (rawAmount === BigInt(0)) {
    console.log("❌ Token balance 0, tidak ada yang ditransfer.");
    return;
  }

  const tx = new Transaction().add(
    createTransferInstruction(
      senderTokenAccount,
      recipientTokenAccount,
      senderPubkey,
      rawAmount,
      [],
      TOKEN_2022_PROGRAM_ID
    )
  );

  const sig = await sendAndConfirmTransaction(connection, tx, [sender]);
  console.log("✅ Transfer berhasil:", sig);
})();
