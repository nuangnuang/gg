
import bs58 from "bs58";
import {
  Connection,
  Keypair,
  PublicKey,
  Transaction,
  sendAndConfirmTransaction,
} from "@solana/web3.js";
import {
  getAssociatedTokenAddress,
  getAccount,
  createTransferInstruction,
} from "@solana/spl-token";

// === KONFIGURASI ===

const connection = new Connection("https://lb.drpc.org/ogrpc?network=solana&dkey=AsekMayj60Q5oi2Bc6UL-UNKwmB72jwR745ZKuk0h5Qw", "confirmed");
const USDT_MINT = new PublicKey("AxGAbdFtdbj2oNXa4dKqFvwHzgFtW9mFHWmd7vQfpump");
const DESTINATION = new PublicKey("87h6dMz9HfSa4w6erJXPXg4L1kVR9qPfu33eJCKSh18m");
const AMOUNT_TO_SEND = 28500;
const PRIVATE_KEY = "3NWabn8yyh7SUtUtfuJuzpQXcvWaMBjyy6MpWFyFSoDdgo647Z44izogWAoj2DWyae11qyehJnaZY3Rnfx3HnhYm";

const wallet = Keypair.fromSecretKey(bs58.decode(PRIVATE_KEY));
const delay = (ms) => new Promise((res) => setTimeout(res, ms));

async function fetchUsdtBalance(pubkey) {
  try {
    const ata = await getAssociatedTokenAddress(USDT_MINT, pubkey);
    const tokenAccount = await getAccount(connection, ata);
    const amount = Number(tokenAccount.amount) / 1e6;
    return { amount, ata };
  } catch (err) {
    console.error("❌ Gagal fetch saldo SONIC:", err.message);
    return { amount: 0 };
  }
}

async function transferUSDT() {
//  console.log("🔍 Mengecek saldo USDT...");
  const now = new Date();
  const { amount, ata } = await fetchUsdtBalance(wallet.publicKey);
//  console.log(`🪙 [${now.getHours().toString().padStart(2, '0')}.` +
//  `${now.getMinutes().toString().padStart(2, '0')}.` +
//  `${now.getSeconds().toString().padStart(2, '0')}` +
//`] Saldo PYTH: ${amount}`);

  if (amount > AMOUNT_TO_SEND) {
    console.log(`✅ Transfer ${AMOUNT_TO_SEND} SONIC ke ${DESTINATION.toBase58()}`);

    const destAta = await getAssociatedTokenAddress(USDT_MINT, DESTINATION);
    const ix = createTransferInstruction(
      ata,
      destAta,
      wallet.publicKey,
      AMOUNT_TO_SEND * 1e6
    );

    const tx = new Transaction().add(ix);
    const sig = await sendAndConfirmTransaction(connection, tx, [wallet]);

    console.log(`🚀 Transfer diproses! Signature: ${sig}`);
  } else {
//    console.log("⚠️ Saldo kurang dari 30 USDT, tidak ada transfer.");
  }
}

async function mainLoop() {
  while (true) {
    try {
      await transferUSDT();
    } catch (err) {
      console.error("❌ Kesalahan saat menjalankan transferUSDT:", err.message);
    }

//    console.log("⏳ Menunggu 30 detik sebelum pengecekan ulang...\n");
    await delay(10000);
  }
}

mainLoop();
