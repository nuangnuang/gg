require('dotenv').config();
const { Connection, PublicKey } = require('@solana/web3.js');
const { exec } = require('child_process');

// Ganti ini:
const RPC_ENDPOINT = process.env.CONNECT;
const WALLET_ADDRESS = '6RCDD9WCHv22grjtDZWUWHJgxYUQgHY3T1en4jQGFBtF';
const TOKEN_MINT_ADDRESS = "2b1kV6DkPAnxd5ixfnxCpjxmKwqjjaYmCZfHsFu24GXo";

// Path file yang mau dieksekusi kalau saldo > 0
const FILE_TO_EXECUTE = 'node pyusdw2.js';

const connection = new Connection(RPC_ENDPOINT, 'confirmed');

async function checkTokenBalance() {
    try {
        const walletPublicKey = new PublicKey(WALLET_ADDRESS);
        const tokenMintPublicKey = new PublicKey(TOKEN_MINT_ADDRESS);

        const tokenAccounts = await connection.getParsedTokenAccountsByOwner(walletPublicKey, {
            mint: tokenMintPublicKey,
        });

        let balance = 0;

        if (tokenAccounts.value.length > 0) {
            balance = tokenAccounts.value[0].account.data.parsed.info.tokenAmount.uiAmount;
        }

        if (balance > 0) {
            console.log(`[${new Date().toLocaleTimeString()}] wallet 2 detected`);
            executeExternalFile();
        }

    } catch (error) {
        console.error('Error checking token balance:', error.message);
    }
}

function executeExternalFile() {
    exec(FILE_TO_EXECUTE, (error, stdout, stderr) => {
        if (error) {
//            console.error(`Error executing file: ${error.message}`);
            return;
        }
        if (stderr) {
//            console.error(`stderr: ${stderr}`);
//            return;
        }
        console.log(`stdout: ${stdout}`);
    });
}

// Loop setiap 10 detik
setInterval(checkTokenBalance, 30000);

// Jalankan pertama kali
checkTokenBalance();
