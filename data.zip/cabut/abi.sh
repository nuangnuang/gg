node cabut1.js
node cabut2.js
node cabut3.js
node cabut4.js
