import 'dotenv/config';
import bs58 from 'bs58';
import fetch from 'cross-fetch';
import {
  Connection,
  Keypair,
  PublicKey,
  VersionedTransaction,
  LAMPORTS_PER_SOL,
  TransactionSignature,
  SendOptions,
  ConfirmOptions,
} from '@solana/web3.js';

// ======= Konstanta penting =======
const RPC_URL = process.env.RPC_URL!;
const PRIVATE_KEY_BS58 = process.env.PRIVATE_KEY_BS58!;
const SLIPPAGE_BPS = 50;
const SAFETY_SOL = 0.0011;

// Token Mints
const inputMint = 'So11111111111111111111111111111111111111112'; // SOL
const outputMint = 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v'; // USDT

(async () => {
  try {
    // === Setup koneksi dan wallet ===
    const connection = new Connection(RPC_URL, 'confirmed');
    const secretKey = bs58.decode(PRIVATE_KEY_BS58);
    const wallet = Keypair.fromSecretKey(secretKey);
    const publicKey: PublicKey = wallet.publicKey;

    // === Ambil saldo wallet dan hitung amount swap ===
    const balanceLamports = await connection.getBalance(publicKey);
    const safetyReserve = SAFETY_SOL * LAMPORTS_PER_SOL;
    const amountToSwap = balanceLamports - safetyReserve;

    if (amountToSwap <= 0) {
      throw new Error(`Saldo terlalu kecil. Sisa SOL: ${balanceLamports / LAMPORTS_PER_SOL}`);
    }

    console.log(`💰 Saldo: ${(balanceLamports / LAMPORTS_PER_SOL).toFixed(6)} SOL`);
    console.log(`➡️ Diswap: ${(amountToSwap / LAMPORTS_PER_SOL).toFixed(6)} SOL`);

    // === Get Quote ===
    const quoteUrl = `https://lite-api.jup.ag/swap/v1/quote?inputMint=${inputMint}&outputMint=${outputMint}&amount=${Math.floor(amountToSwap)}&slippageBps=${SLIPPAGE_BPS}&restrictIntermediateTokens=true`;
    const quoteRes = await fetch(quoteUrl);
    const quoteResponse = await quoteRes.json();

    if (!quoteResponse || !quoteResponse.outAmount) {
      throw new Error("❌ Gagal mendapatkan quote dari Jupiter.");
    }

    console.log(`✅ Estimasi hasil: ${Number(quoteResponse.outAmount) / 1e6} USDT`);

    // === Build Swap Transaction ===
    const swapRes = await fetch('https://lite-api.jup.ag/swap/v1/swap', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        quoteResponse,
        userPublicKey: publicKey.toBase58(),
        dynamicComputeUnitLimit: true,
        dynamicSlippage: true,
        prioritizationFeeLamports: {
          priorityLevelWithMaxLamports: {
            maxLamports: 200000, // low gas setting
            priorityLevel: 'low'
          }
        }
      })
    });

    const swapResponse = await swapRes.json();

    if (!swapResponse.swapTransaction) {
      throw new Error("❌ Gagal membangun transaksi swap.");
    }

    // === Deserialize dan sign transaksi ===
    const transactionBase64 = swapResponse.swapTransaction;
    const transaction = VersionedTransaction.deserialize(Buffer.from(transactionBase64, 'base64'));
    transaction.sign([wallet]);

    const transactionBinary = transaction.serialize();

    // === Kirim transaksi ===
    const options: SendOptions = {
      skipPreflight: true,
      maxRetries: 3,
    };

    const signature: TransactionSignature = await connection.sendRawTransaction(transactionBinary, options);
    console.log(`⏳ Menunggu konfirmasi: ${signature}`);

    const confirmOptions: ConfirmOptions = { commitment: "finalized" };
    const confirmation = await connection.confirmTransaction({ signature }, confirmOptions.commitment);

    if (confirmation.value.err) {
      throw new Error(`❌ Transaksi gagal: ${JSON.stringify(confirmation.value.err)}\nhttps://solscan.io/tx/${signature}`);
    }

    console.log(`✅ Swap berhasil! 🔗 https://solscan.io/tx/${signature}`);

  } catch (err: any) {
    console.error("❌ Error:", err.message || err);
  }
})();
