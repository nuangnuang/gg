const { RestClientV5 } = require('bybit-api');

require('dotenv').config();
const API_KEY = process.env.KEY;
const API_SECRET = process.env.SECRET;

// Masukkan API key dan secret kamu
const client = new RestClientV5({
  key: API_KEY,
  secret: API_SECRET,
  testnet: false, // false untuk mainnet
});

async function transferTradeToFund() {
  try {
    const result = await client.createInternalTransfer({
      fromAccountType: 'UNIFIED',  // akun perdagangan terpadu
      toAccountType: 'FUND',       // tujuan ke akun pendanaan
      coin: 'USDT',                   // coin/token yang ingin ditransfer
      amount: '28.5',            // jumlah token yang akan ditransfer
    });

    console.log('✅ Transfer berhasil:', JSON.stringify(result, null, 2));
  } catch (err) {
    console.error('❌ Gagal transfer:', err);
  }
}

transferTradeToFund();
