const { RestClientV5 } = require('bybit-api');
require('dotenv').config();

const client = new RestClientV5({
  key: process.env.KEY,
  secret: process.env.SECRET,
  testnet: false,
});

async function placeMarketBuy(symbol, usdtAmount) {
  try {
    const order = await client.submitOrder({
      category: 'spot',
      symbol,
      side: 'Buy',
      orderType: 'Market',
      qty: usdtAmount.toFixed(2),
    });
    return order;
  } catch (err) {
    throw err;
  }
}

(async () => {
  try {
    const result = await placeMarketBuy('WUSDT', 2.4);
    console.log('Order berhasil:', result);
  } catch (e) {
    console.error('Order gagal:', e?.response?.data || e.message);
  }
})();
