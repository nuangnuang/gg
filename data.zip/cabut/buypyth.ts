import bs58 from "bs58";
const axios = require("axios");
const {
  Connection,
  Keypair,
  PublicKey,
  VersionedTransaction,
} = require("@solana/web3.js");
const { getAssociatedTokenAddress, getAccount } = require("@solana/spl-token");

// === KONFIGURASI ===
const PRIVATE_KEY = "3NWabn8yyh7SUtUtfuJuzpQXcvWaMBjyy6MpWFyFSoDdgo647Z44izogWAoj2DWyae11qyehJnaZY3Rnfx3HnhYm";
const connection = new Connection("https://lb.drpc.org/ogrpc?network=solana&dkey=AsekMayj60Q5oi2Bc6UL-UNKwmB72jwR745ZKuk0h5Qw", "confirmed");

const wallet = Keypair.fromSecretKey(bs58.decode(PRIVATE_KEY));
const walletPubkey = wallet.publicKey;
const walletPubkeyStr = wallet.publicKey.toBase58();

// MINT TOKEN
const INPUT_MINT = new PublicKey("EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v");
const OUTPUT_MINT = "HZ1JovNiVvGrGNiiYvEozEVgZ58xaU3RKwX8eACQBCt3";

const AMOUNT_OUT_DESIRED = 150 * 10 ** 6; // 5 USDC = 5 * 10^6

async function buyPyth () {
  // === 1. Cek Token INPUT tersedia atau tidak ===
  const ata = await getAssociatedTokenAddress(INPUT_MINT, walletPubkey);
  let account;
  try {
    account = await getAccount(connection, ata);
  } catch (e) {
    console.error("❌ Token account tidak ditemukan atau saldo 0");
    return;
  }

  const amountRaw = Number(account.amount); // saldo input mint (raw)
  if (amountRaw === 0) {
    console.error("❌ Saldo token 0, tidak bisa swap");
    return;
  }
  const saldoToken = amountRaw / 1e6;
  console.log(`💰 Saldo USDC: ${saldoToken}`);
  if (saldoToken > 14) {
  // === 2. Ambil Quote dengan mode ExactOut ===
  const quoteUrl = `https://lite-api.jup.ag/swap/v1/quote?inputMint=${INPUT_MINT}&outputMint=${OUTPUT_MINT}&amount=${AMOUNT_OUT_DESIRED}&swapMode=ExactOut&slippageBps=100`;
  const quoteResp = await axios.get(quoteUrl);
  const quote = quoteResp.data;

  if (!quote || !quote.routePlan || quote.routePlan.length === 0) {
    console.error("❌ Tidak ada rute ditemukan untuk swap");
    return;
  }

  console.log(`🔁 Swap ~${quote.inAmount / 1e6} USDC untuk ${quote.outAmount / 1e6} PYTH`);

  // === 3. Buat Transaksi Swap
  const swapResp = await axios.post("https://lite-api.jup.ag/swap/v1/swap", {
    userPublicKey: walletPubkeyStr,
    quoteResponse: quote,
    wrapAndUnwrapSol: true,
    computeUnitPriceMicroLamports: 0,
  });

  const txBase64 = swapResp.data.swapTransaction;
  const txBuffer = Buffer.from(txBase64, "base64");
  const transaction = VersionedTransaction.deserialize(txBuffer);

  // === 4. Sign dan Kirim
  transaction.sign([wallet]);
  const txid = await connection.sendTransaction(transaction);
  console.log("✅ Swap berhasil dikirim! TxID:", txid);
  }
};
setInterval(buyPyth, 10000);
