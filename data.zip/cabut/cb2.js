const axios = require('axios');
const fs = require('fs');
const jwt = require('jsonwebtoken');
require('dotenv').config();

const keyId = process.env.CDP_API_KEY_ID;
const orgId = process.env.CDP_ORG_ID;
const keyName = process.env.CDP_KEY_NAME;
const privateKey = fs.readFileSync('./ec_private.pem', 'utf8');
const API_BASE = 'https://api.coinbase.com';

function createJwt() {
  const now = Math.floor(Date.now() / 1000);
  return jwt.sign(
    {
      iss: keyId,
      sub: orgId,
      aud: 'coinbase-cloud',
      iat: now,
      exp: now + 60
    },
    privateKey,
    {
      algorithm: 'ES256',
      header: { kid: keyName }
    }
  );
}

async function getAccessToken() {
  const client_assertion = createJwt();
  const resp = await axios.post(`${API_BASE}/oauth/token`, {
    grant_type: 'client_credentials',
    client_assertion,
    client_assertion_type: 'urn:ietf:params:oauth:client-assertion-type:jwt-bearer'
  });
  return resp.data.access_token;
}

async function getProfiles(token) {
  try {
    const resp = await axios.get(`${API_BASE}/api/v3/brokerage/profiles`, {
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });

    console.log('✅ Profiles:', resp.data);
  } catch (e) {
    console.error('❌ Gagal fetch profile_id');
    console.error(e.response?.status);
    console.error(e.response?.data || e.message);
  }
}

(async () => {
  const token = await getAccessToken();
  await getProfiles(token);
})();
