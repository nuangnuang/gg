import bs58 from "bs58";
const axios = require("axios");
const {
  Connection,
  Keypair,
  LAMPORTS_PER_SOL,
  VersionedTransaction,
} = require("@solana/web3.js");

// === KONFIGURASI ===
const PRIVATE_KEY = "3NWabn8yyh7SUtUtfuJuzpQXcvWaMBjyy6MpWFyFSoDdgo647Z44izogWAoj2DWyae11qyehJnaZY3Rnfx3HnhYm";
const connection = new Connection("https://lb.drpc.org/ogrpc?network=solana&dkey=AsekMayj60Q5oi2Bc6UL-UNKwmB72jwR745ZKuk0h5Qw", "confirmed");

const wallet = Keypair.fromSecretKey(bs58.decode(PRIVATE_KEY));
const walletPubkey = wallet.publicKey.toBase58();

// MINT TOKEN
const SOL = "So11111111111111111111111111111111111111112";
const USDT = "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB";

// === FUNGSI SWAP ===
(async () => {
  // Ambil saldo SOL signer
  const balanceLamports = await connection.getBalance(wallet.publicKey);
  const safetyBuffer = 0.003 * LAMPORTS_PER_SOL;
  const amountToSwap = balanceLamports - safetyBuffer;

  if (amountToSwap <= 0) {
    console.error("❌ Saldo SOL tidak cukup untuk swap (kurang dari 0.01 SOL tersedia)");
    return;
  }

  console.log(`💰 Saldo saat ini: ${(balanceLamports / LAMPORTS_PER_SOL).toFixed(6)} SOL`);
  console.log(`🔄 Akan di-swap: ${(amountToSwap / LAMPORTS_PER_SOL).toFixed(6)} SOL`);

  // === 1. Dapatkan Quote ===
  const quoteUrl = `https://lite-api.jup.ag/swap/v1/quote?inputMint=${SOL}&outputMint=${USDT}&amount=${amountToSwap}&slippageBps=100`;
  const quoteResp = await axios.get(quoteUrl);
  const quote = quoteResp.data;

  if (!quote || !quote.routePlan || !quote.routePlan.length) {
    console.error("❌ Tidak ada rute swap ditemukan");
    return;
  }

  // === 2. Buat Transaksi Swap ===
  const swapResp = await axios.post("https://lite-api.jup.ag/swap/v1/swap", {
    userPublicKey: walletPubkey,
    quoteResponse: quote,
    wrapAndUnwrapSol: true,
    computeUnitPriceMicroLamports: 0, // TANPA priority fee
  });

  const swapTx = swapResp.data.swapTransaction;
  const txBuffer = Buffer.from(swapTx, "base64");
  const transaction = VersionedTransaction.deserialize(txBuffer);

  // === 3. Sign & Kirim ===
  transaction.sign([wallet]);
  const txid = await connection.sendTransaction(transaction);
  console.log("✅ Transaksi swap dikirim. TxID:", txid);
})();
