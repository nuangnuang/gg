// main.js
const { spawn } = require('child_process');

const scripts = ['autosol.js', 'autow.js',];

scripts.forEach(script => {
  const proc = spawn('node', [script], { stdio: 'inherit' });
});



