const { spawn } = require("child_process");
const { Connection, PublicKey, LAMPORTS_PER_SOL } = require("@solana/web3.js");

// === KONFIGURASI ===
const WALLET_ADDRESS = "6iLzQjQCFeq5FKmdPgHiTqkpvWEmwbDop12gZkTPzhTF";
const connection = new Connection("https://lb.drpc.org/ogrpc?network=solana&dkey=AsekMayj60Q5oi2Bc6UL-UNKwmB72jwR745ZKuk0h5Qw", "confirmed");

const delay = (ms) => new Promise((res) => setTimeout(res, ms));

async function cekLooping() {
  while (true) {
    try {
      const pubkey = new PublicKey(WALLET_ADDRESS);
      const balanceLamports = await connection.getBalance(pubkey);
      const balanceSOL = balanceLamports / LAMPORTS_PER_SOL;

      console.log(`🪙 BALANCE: ${balanceSOL.toFixed(6)} SOL`);

      if (balanceSOL > 0.1) {
        console.log("✅ Melakukan penjualan SOL/USDT\n");

        const child = spawn("node", ["solusdt.js"]);

        child.stdout.on("data", (data) => {
          process.stdout.write(`📤 [external]: ${data}`);
        });

        child.stderr.on("data", (data) => {
          process.stderr.write(`❌ [external error]: ${data}`);
        });

        await new Promise((resolve) => {
          child.on("exit", (code) => {
            console.log(`🔚 exit code ${code}`);
            resolve();
          });
        });
      } else {
        console.log("⚠️  Fetching SOL Balance");
      }
    } catch (err) {
      console.error("❌ Terjadi kesalahan saat cek saldo:", err.message);
    }

//    console.log("⏳ Menunggu 30 detik untuk cek ulang...");
    await delay(30_000); // 30 detik
  }
}

cekLooping();
