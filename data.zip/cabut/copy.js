for i in {1..25}; do
  cp "wdtemplate.js" "wd$i.js"
done
