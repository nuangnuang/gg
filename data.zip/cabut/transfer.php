<?php
require 'vendor/autoload.php';

use GuzzleHttp\Client;
use Dotenv\Dotenv;

// Load .env
$dotenv = Dotenv::createImmutable(__DIR__);
$dotenv->load();

$apiKey = $_ENV['KEY'];
$apiSecret = $_ENV['SECRET'];
$baseUrl = 'https://api.bybit.com';

// Step 1: Ambil saldo UNIFIED
$client = new Client(['base_uri' => $baseUrl]);

try {
    $response = $client->get('/v5/account/wallet-balance', [
        'query' => [
            'accountType' => 'UNIFIED',
            'coin' => 'USDT'
        ],
        'headers' => [
            'X-BAPI-API-KEY' => $apiKey
        ]
    ]);

    $data = json_decode($response->getBody(), true);
    $walletBalance = (float)$data['result']['balance']['transferBalance'] ?? 0;

    echo "✅ Saldo tersedia: {$walletBalance} USDT\n";

    if ($walletBalance <= 0) {
        exit("❌ Tidak ada saldo tersedia untuk transfer.\n");
    }

    // Step 2: Hitung amount
    $amount = floor($walletBalance);
    echo "🔁 Amount untuk transfer (dibagi 50): {$amount} USDT\n";

    // Step 3: Siapkan parameter transfer
    $timestamp = round(microtime(true) * 1000);
    $transferId = uniqid();

    $params = [
        'amount' => (string)$amount,
        'coin' => 'USDT',
        'fromAccountType' => 'UNIFIED',
        'toAccountType' => 'FUND',
        'timestamp' => $timestamp,
        'transferId' => $transferId
    ];

    // Step 4: Buat signature
    ksort($params);
    $query = http_build_query($params, '', '&', PHP_QUERY_RFC3986);
    $signPayload = $timestamp . $apiKey . $query;
    $sign = hash_hmac('sha256', $signPayload, $apiSecret);

    // Step 5: Kirim request transfer
    $transferResponse = $client->post('/v5/asset/transfer/inter-transfer', [
        'form_params' => $params,
        'headers' => [
            'X-BAPI-API-KEY' => $apiKey,
            'X-BAPI-TIMESTAMP' => $timestamp,
            'X-BAPI-SIGN' => $sign,
            'Content-Type' => 'application/x-www-form-urlencoded'
        ]
    ]);

    $transferData = json_decode($transferResponse->getBody(), true);
    echo "✅ Transfer response:\n";
    print_r($transferData);

} catch (Exception $e) {
    echo "❌ Gagal: " . $e->getMessage() . "\n";
}
