cat cabut2.txt | parallel
cat cabut2.txt | parallel
cat cabut2.txt | parallel
cat cabut2.txt | parallel
cat cabut2.txt | parallel
cat cabut2.txt | parallel
cat cabut2.txt | parallel
cat cabut2.txt | parallel
cat cabut2.txt | parallel
cat cabut2.txt | parallel

