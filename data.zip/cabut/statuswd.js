require('dotenv').config();
const { RestClientV5 } = require('bybit-api');
const token = process.env.COIN;
const TOKEN_SYMBOL = token;

const client = new RestClientV5({
  key: process.env.KEY,
  secret: process.env.SECRET,
  testnet: false,
});

async function checkLastWithdrawalStatus() {
  try {
    const res = await client.getWithdrawalRecords({
      coin: TOKEN_SYMBOL,
      limit: 1,
    });

    const withdrawal = res.result?.rows?.[0];

    if (!withdrawal) {
      console.log(`❌ Tidak ada withdrawal untuk ${TOKEN_SYMBOL}.`);
      return;
    }

    const status = withdrawal.status;
    const id = withdrawal.id || withdrawal.withdrawId;
    const amount = withdrawal.amount;
    const fee = withdrawal.withdrawFee || withdrawal.fee || '0';
    const time = new Date(Number(withdrawal.createTime)).toLocaleString();

    if (status === 'Success') {
      console.log(`✅ Withdrawal berhasil:`);
    } else {
      console.log(`⏳ Withdrawal masih dalam proses:`);
    }

    console.log(`- ID       : ${id}`);
    console.log(`- Status   : ${status}`);
    console.log(`- Amount   : ${amount} ${TOKEN_SYMBOL}`);
    console.log(`- Fee      : ${fee}`);
    console.log(`- Waktu    : ${time}`);

  } catch (err) {
    console.error(`❌ Gagal mengambil data withdrawal:`, err.message || err);
  }
}

checkLastWithdrawalStatus();
