require('dotenv').config();
const axios = require('axios');
const crypto = require('crypto');

// Konfigurasi API
const API_KEY = process.env.KEY;
const API_SECRET = process.env.SECRET;

// Parameter transfer
const transferId = Date.now().toString(); // Bisa diganti dengan UUID
const coin = 'USDT';
const amount = '2.5';
const fromAccountType = 'UNIFIED';
const toAccountType = 'FUND';
const timestamp = Date.now().toString();

// Parameter dalam urutan alfabet
const params = {
  amount: amount,
  coin: coin,
  fromAccountType: fromAccountType,
  timestamp: timestamp,
  toAccountType: toAccountType,
  transferId: transferId,
};

// Konversi params ke query string dalam urutan alfabet
const orderedQuery = Object.keys(params)
  .sort()
  .map(key => `${key}=${params[key]}`)
  .join('&');

// Buat signature
const sign = crypto
  .createHmac('sha256', API_SECRET)
  .update(orderedQuery)
  .digest('hex');

// Header
const headers = {
  'X-BAPI-API-KEY': API_KEY,
  'X-BAPI-SIGN': sign,
  'X-BAPI-TIMESTAMP': timestamp,
  'X-BAPI-RECV-WINDOW': '5000',
  'Content-Type': 'application/json',
};

// Kirim permintaan transfer
axios.post('https://api.bybit.com/v5/asset/transfer/inter-transfer', params, { headers })
  .then(res => {
    console.log('✅ Transfer berhasil:', res.data);
  })
  .catch(err => {
    console.error('❌ Transfer gagal:', err.response?.data || err.message);
  });
