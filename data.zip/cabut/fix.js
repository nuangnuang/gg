const fs = require('fs');
const path = require('path');

for (let i = 1; i <= 50; i++) {
  const filename = `bybit${i}.js`;
  const filepath = path.join(__dirname, filename);

  if (fs.existsSync(filepath)) {
    let content = fs.readFileSync(filepath, 'utf-8');

    // Perbaiki baris yang bug: hapus kesalahan sintaks dan ubah jadi template literal
    const fixedContent = content.replace(
       console.log('Balance Token= ' sisaBalance);?/g,
      'console.log(`Balance Token= ${sisaBalance}`);'
    );

    fs.writeFileSync(filepath, fixedContent, 'utf-8');
    console.log(`✅ Diperbaiki: ${filename}`);
  } else {
    console.log(`❌ File tidak ditemukan: ${filename}`);
  }
}
