// main.js
const { spawn } = require('child_process');

const scripts = ['pyth1.js', 'pyth2.js', 'pyth3.js', 'pyth4.js', 'pyth5.js', 'pyth6.js', 'pyth7.js', 'pyth8.js', 'pyth9.js', 'pyth10.js'];

scripts.forEach(script => {
  const proc = spawn('node', [script], { stdio: 'inherit' });
});
