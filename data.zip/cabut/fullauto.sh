echo MELAKUKAN TRADE
node autotrade1.js
sleep 5
echo TRANSFER FUNDS
node autotransfer2.js
sleep 5
DONE
autowd.js
