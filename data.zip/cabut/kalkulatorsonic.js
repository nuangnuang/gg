const axios = require('axios');
const readline = require('readline');
const chalk = require('chalk');
//const rl = readline.createInterface({
//  input: process.stdin,
//  output: process.stdout
//});

//function tanyaInput(pertanyaan) {
//  return new Promise(resolve => {
//    rl.question(pertanyaan, (jawaban) => {
//      rl.close();
//      resolve(jawaban);
//    });
//  });
//}

async function main() {
//  const input = await tanyaInput('Withdrawal Fee: ');
//  const fees = parseFloat(input);

//  if (isNaN(fees)) {
//    console.log("❌ Nilai tidak valid");
//    return;
// }
  const feesauto = 1.5;
  const hargaUsdt = 16310;
  const tokenInDesimal = 9;
  const tokenOutDesimal = 9;
  const amountToSwap = Math.floor(feesauto * 10 ** tokenInDesimal);
  const SOL = 'So11111111111111111111111111111111111111112';
  const USDT = 'Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB';
  const Wormhole = '85VBFQZC9TZkfaptBWjvUw7YbZjy52A6mjtPGjstQAmQ';
  const DOOD = 'DvjbEsdca43oQcw2h3HW1CT7N3x5vRcr3QrvTUHnXvgV';
  const PYTH = 'HZ1JovNiVvGrGNiiYvEozEVgZ58xaU3RKwX8eACQBCt3';
  const SONIC = 'SonicxvLud67EceaEzCLRnMTBqzYUUYNr93DBkBdDES';
  try {
    const quoteUrl = `https://lite-api.jup.ag/swap/v1/quote?inputMint=${SONIC}&outputMint=${SOL}&amount=${amountToSwap}&slippageBps=50`;
    const quoteResp = await axios.get(quoteUrl);
    const quote = quoteResp.data;
//    console.log(quote);

    const quoteUrl2 = `https://lite-api.jup.ag/swap/v1/quote?inputMint=${SOL}&outputMint=${USDT}&amount=1000000000&slippageBps=50`;
    const quoteResp2 = await axios.get(quoteUrl2);
    const quote2 = quoteResp2.data;

    const hargaSol = quote2.outAmount / 10 ** 6;
    const masuk = amountToSwap / 10 ** tokenInDesimal;
    const keluar = quote.outAmount / 10 ** tokenOutDesimal;
    const profit = 0.002033 - keluar;
    const profitIdr = profit * hargaSol * hargaUsdt;
    const profitUsd = profit * hargaSol;
    const idrTotal = profitIdr * 50;
    const usdTotal = profitUsd * 50;

console.log(chalk.green("✅ Hasil:"));
console.log(chalk.white(`- Fee                     : ${masuk} Sonic`));
console.log(chalk.white(`- Fee Dalam Sol           : ${keluar} SOL`));
console.log(chalk.yellow(`- Harga Sol               : ${hargaSol} USDT`));
console.log(chalk.green(`- Profit IDR              : Rp ${profitIdr.toFixed(2)}`));
console.log(chalk.green(`- Profit USD              : $${profitUsd.toFixed(5)}`));
console.log(chalk.green(`- Total Profit (20m)      : $${(usdTotal).toFixed(4)} / Rp ${(idrTotal).toFixed(2)}`));
  } catch (err) {
    console.error("❌ Gagal mengambil quote:", err.message);
  }
}

main();
setInterval(main, 30000);
