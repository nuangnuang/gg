import {
    Connection,
    PublicKey,
    Keypair,
    Transaction,
    sendAndConfirmTransaction,
} from "@solana/web3.js";
import {
    getAccount,
    closeAccount,
} from "@solana/spl-token";
import bs58 from "bs58";
import dotenv from "dotenv";

dotenv.config();

const RPC_URL = "https://api.mainnet-beta.solana.com";
const connection = new Connection(RPC_URL, "confirmed");

// **Validasi PRIVATE_KEY**
if (!process.env.PRIVATE_KEY) {
    console.error("Error: PRIVATE_KEY tidak ditemukan di .env");
    process.exit(1);
}

let payer: Keypair;
try {
    const secretKey = bs58.decode(process.env.PRIVATE_KEY);
    payer = Keypair.fromSecretKey(secretKey);
} catch (error) {
    console.error("Error: Gagal membaca PRIVATE_KEY. Pastikan formatnya benar dalam Base58.");
    process.exit(1);
}

async function closeEmptyTokenAccounts(): Promise<void> {
    try {
        const tokenAccounts = await connection.getParsedTokenAccountsByOwner(
            payer.publicKey,
            { programId: new PublicKey("TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA") }
        );

        let closedAccounts = 0;
        for (const account of tokenAccounts.value) {
            const tokenAccountPubkey = new PublicKey(account.pubkey);
            const balance: number = account.account.data.parsed.info.tokenAmount.uiAmount;

            if (balance === 0) {
                console.log(`Menutup akun kosong: ${tokenAccountPubkey.toBase58()}`);

                // **Dapatkan informasi akun token sebelum menutupnya**
                const tokenAccount = await getAccount(connection, tokenAccountPubkey);

                // **Pastikan pemilik akun token adalah payer**
                if (!tokenAccount.owner.equals(payer.publicKey)) {
                    console.log(`❌ Lewati akun ${tokenAccountPubkey.toBase58()} karena bukan milik payer.`);
                    continue;
                }

                // **Buat transaksi untuk menutup akun**
                const transaction = new Transaction().add(
                    closeAccount({
                        source: tokenAccountPubkey,
                        destination: payer.publicKey,
                        owner: payer.publicKey,
                    })
                );

                // **Pastikan payer sebagai signer**
                const txid = await sendAndConfirmTransaction(connection, transaction, [payer]);
                console.log(`✅ Akun ${tokenAccountPubkey.toBase58()} berhasil ditutup. TXID: ${txid}`);

                closedAccounts++;
            }
        }

        if (closedAccounts === 0) {
            console.log("Tidak ada akun token kosong yang ditemukan.");
        }
    } catch (error) {
        console.error("Terjadi kesalahan:", error);
    }
}

closeEmptyTokenAccounts();
