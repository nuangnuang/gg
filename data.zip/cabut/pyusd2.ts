import 'dotenv/config';
import {
  Connection,
  PublicKey,
  Keypair,
  Transaction,
  sendAndConfirmTransaction,
} from "@solana/web3.js";
import {
  getAccount,
  getMint,
  createTransferCheckedInstruction,
  createCloseAccountInstruction,
  TOKEN_2022_PROGRAM_ID,
} from "@solana/spl-token";
import bs58 from "bs58";
const decimals = 6;
const RPC = process.env.CONNECT;
const payer = process.env.PAYERGASS;
const tokenAccount = process.env.TOKENACCOUNT;
const tokenMintAddress = process.env.TOKENMINT;
const solWallet = process.env.SOLWALLET;
const wallet1 = process.env.WALLET6;
const wallet2 = process.env.WALLET7;
const wallet3 = process.env.WALLET8;
const wallet4 = process.env.WALLET9;
const wallet5 = process.env.WALLET10;


// Fungsi utama untuk batch transfer
(async () => {
  // Koneksi ke mainnet
  const connection = new Connection(
    RPC,
    "confirmed"
  );

  // Fee payer
  const feePayer = Keypair.fromSecretKey(bs58.decode(payer));

  // Penerima token
  const recipientTokenPubkey = new PublicKey(tokenAccount);
  const recipientPubkey = new PublicKey(solWallet);

  // Alamat mint token
  const tokenMintPubkey = new PublicKey(tokenMintAddress);

  // Daftar wallet
  const privateKeyList = [
    wallet1,
    wallet2,
    wallet3,
    wallet4,
    wallet5
  ];

  // Buat transaksi
  const transaction = new Transaction();
  const signers = [feePayer];

  for (let secretKey of privateKeyList) {
    const fromWallet = Keypair.fromSecretKey(bs58.decode(secretKey));
    const fromPublicKey = fromWallet.publicKey;

    const tokenAccounts = await connection.getTokenAccountsByOwner(fromPublicKey, {
      mint: tokenMintPubkey,
      programId: TOKEN_2022_PROGRAM_ID,
    });

    for (let tokenAccountInfo of tokenAccounts.value) {
      const tokenAccountPubkey = new PublicKey(tokenAccountInfo.pubkey);
      const tokenAccountDetails = await getAccount(
        connection,
        tokenAccountPubkey,
        undefined,
        TOKEN_2022_PROGRAM_ID
      );
      const tokenBalance = tokenAccountDetails.amount;

      if (tokenBalance > BigInt(0)) {
        transaction.add(
          createTransferCheckedInstruction(
            tokenAccountPubkey,
            tokenMintPubkey,
            recipientTokenPubkey,
            fromPublicKey,
            tokenBalance,
            decimals,
            [],
            TOKEN_2022_PROGRAM_ID
          ),
          createCloseAccountInstruction(
            tokenAccountPubkey,
            recipientPubkey,
            fromPublicKey,
            [],
            TOKEN_2022_PROGRAM_ID
          )
        );

        signers.push(fromWallet);
      } else {
        console.log(`❌ Token account ${tokenAccountPubkey.toBase58()} tidak ada saldo.`);
      }
    }
  }

  try {
    const signature = await sendAndConfirmTransaction(connection, transaction, signers);
    console.log(`✅ Transaksi berhasil. Signature: ${signature}`);
  } catch (error) {
    console.error(`❌ Gagal mengirim transaksi:`, error);
  }
})();
