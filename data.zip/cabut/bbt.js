const walletBalance = 100;

for (let i = 1; i <= 25; i++) {
  const fileName = `bybit${i}.js`;
  const numberFromFile = i; // karena nama file urut, kita tahu angkanya
  const amountraw = (parseFloat(walletBalance)).toFixed(4);
  const amountraw2 = 26 - numberFromFile;
  const amount = amountraw / amountraw2;
//console.log(`${fileName} -> amount = ${amountraw2}`);
}
