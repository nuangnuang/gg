curl https://api.coinbase.com/v2/accounts/0f90064c-0db2-548c-8cf9-83e4e70f1468/transactions /
  -X POST \
  -H 'Content-Type: application/json' \
  -H 'Authorization: Bearer ' \
  -d '{
    "type": "send",
    "to": "75RVv2UjBio1yDpx3mnYG1Td9oP81U9wnyuaRYgGvPjm",
    "amount": "1.4",
    "currency": "USDC",
  }'
