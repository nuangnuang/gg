require('dotenv').config();
const axios = require('axios');
const fs = require('fs');
const jwt = require('jsonwebtoken');

const clientId = process.env.CDP_CLIENT_ID;
const orgId = process.env.CDP_ORG_ID;
const accountId = process.env.CDP_USDC_ACCOUNT_ID;
const privateKey = fs.readFileSync('./private_key.pem', 'utf8');

async function generateAccessToken() {
  const payload = {
    aud: 'coinbase-cloud',
    iss: clientId,
    sub: orgId,
    iat: Math.floor(Date.now() / 1000),
    exp: Math.floor(Date.now() / 1000) + 60
  };

  const token = jwt.sign(payload, privateKey, { algorithm: 'ES256' });

  const res = await axios.post('https://api.coinbase.com/oauth/token', {
    grant_type: 'client_credentials',
    client_id: clientId,
    client_assertion: token,
    client_assertion_type: 'urn:ietf:params:oauth:client-assertion-type:jwt-bearer'
  });

  return res.data.access_token;
}

async function sendUSDC(toAddress, amount) {
  try {
    const token = await generateAccessToken();

    const res = await axios.post(
      `https://api.coinbase.com/v2/accounts/${accountId}/transactions`,
      {
        type: 'send',
        to: toAddress,
        amount: amount,
        currency: 'USDC'
      },
      {
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      }
    );

    console.log('✅ Transaksi sukses:', res.data);
  } catch (err) {
    console.error('❌ Gagal kirim USDC:', err.response?.data || err.message);
  }
}

// Contoh pemakaian CLI
const [,, address, amount] = process.argv;
if (!address || !amount) {
  console.error('❌ Gunakan format: node sendUsdc.js <alamat> <jumlah>');
  process.exit(1);
}

sendUSDC(address, amount);
