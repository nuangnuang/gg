for i in {1..120}; do
    echo "node cabut$i.js"
    echo "echo PACK$i"
done > cabut.sh
