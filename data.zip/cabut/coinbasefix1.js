require('dotenv').config();
const axios = require('axios');
const crypto = require('crypto');
const { sign } = require('jsonwebtoken');

const key_secret = require('fs').readFileSync('./ec_private.pem', 'utf8');
const key_name = process.env.CDP_KEY_NAME;      // isi dengan key name dari CDP
const client_id = process.env.CDP_CLIENT_ID;    // isi dengan client id dari CDP
const org_id = process.env.CDP_ORG_ID;          // biasanya seperti: org:abc123
const API_BASE = 'https://api.coinbase.com';
const toAddress = process.env.TO_ADDRESS;
const amountToSend = process.env.AMOUNT_TO_SEND;

async function generateAccessToken() {
  const now = Math.floor(Date.now() / 1000);

  const jwtToken = sign(
    {
      iss: client_id,
      sub: org_id,
      aud: 'coinbase-cloud',
      iat: now,
      exp: now + 60
    },
    key_secret,
    {
      algorithm: 'ES256',
      header: {
        kid: key_name
      }
    }
  );

  const res = await axios.post(`${API_BASE}/oauth/token`, {
    grant_type: 'client_credentials',
    client_id: client_id,
    client_assertion: jwtToken,
    client_assertion_type: 'urn:ietf:params:oauth:client-assertion-type:jwt-bearer'
  });

  return res.data.access_token;
}

async function sendUsdc(token, accountId) {
  try {
    const res = await axios.post(
      `${API_BASE}/v2/accounts/${accountId}/transactions`,
      {
        type: "send",
        to: toAddress,
        amount: amountToSend,
        currency: "USDC",
        network: "solana"
      },
      {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json"
        }
      }
    );

    console.log("✅ Transaksi sukses:");
    console.log(res.data);
  } catch (err) {
    console.error("❌ Gagal kirim USDC:");
    console.error(err.response?.data || err.message);
  }
}

(async () => {
  try {
    const token = await generateAccessToken();
    const accountId = '0f90064c-0db2-548c-8cf9-83e4e70f1468';
    await sendUsdc(token, accountId);
  } catch (e) {
    console.error("❌ Error:", e.message);
  }
})();
