// main.js
const { spawn } = require('child_process');

const scripts = ['detecpyusd21.js', 'detecpyusd22.js', 'detecpyusd23.js', 'detecpyusd24.js'];

scripts.forEach(script => {
  const proc = spawn('node', [script], { stdio: 'inherit' });
});
