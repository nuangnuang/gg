import bs58 from "bs58";
const axios = require("axios");
const {
  Connection,
  Keypair,
  PublicKey,
  VersionedTransaction,
} = require("@solana/web3.js");
const { getAssociatedTokenAddress, getAccount } = require("@solana/spl-token");

// === KONFIGURASI ===
const PRIVATE_KEY = "45JT85FWbxUSDLTJkrxuQLcmC4BbNFwAqhy77mVQrMobMjoQ6zgoXpZV4gizEpDHcey24TETUz6EVbVNdqLf5moA";
const connection = new Connection("https://lb.drpc.org/ogrpc?network=solana&dkey=AsekMayj60Q5oi2Bc6UL-UNKwmB72jwR745ZKuk0h5Qw", "confirmed");

const wallet = Keypair.fromSecretKey(bs58.decode(PRIVATE_KEY));
const walletPubkey = wallet.publicKey;
const walletPubkeyStr = wallet.publicKey.toBase58();

// MINT TOKEN
const INPUT_MINT = new PublicKey("EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v");
const OUTPUT_MINT = "2b1kV6DkPAnxd5ixfnxCpjxmKwqjjaYmCZfHsFu24GXo";
const OUTPUT_MINT2 = "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB";
async function pyUsdc () {
  // === 1. Fetch Token Account & Saldo ===
  const ata = await getAssociatedTokenAddress(INPUT_MINT, walletPubkey);
  let account;
  try {
    account = await getAccount(connection, ata);
  } catch (e) {
    console.error("❌ Token account tidak ditemukan atau saldo 0");
    return;
  }

  const amountRaw = Number(account.amount); // tanpa desimal (native format)
  if (amountRaw === 0) {
//    console.error("❌ Saldo token 0, tidak bisa swap");
    return;
  }
  const Jumlah = 3150000;
  console.log(`💰 Saldo USDC: ${amountRaw / 1e6}`);

  // === 2. Ambil Quote
  const quoteUrl = `https://lite-api.jup.ag/swap/v1/quote?inputMint=${INPUT_MINT}&outputMint=${OUTPUT_MINT}&amount=${Jumlah}&slippageBps=50`;
  const quoteResp = await axios.get(quoteUrl);
  const quote = quoteResp.data;

  if (!quote || !quote.routePlan || quote.routePlan.length === 0) {
    console.error("❌ Tidak ada rute ditemukan untuk swap");
    return;
  }

  // === 3. Buat Transaksi Swap
  const swapResp = await axios.post("https://lite-api.jup.ag/swap/v1/swap", {
    userPublicKey: walletPubkeyStr,
    quoteResponse: quote,
    wrapAndUnwrapSol: true,
    computeUnitPriceMicroLamports: 500,
  });

  const txBase64 = swapResp.data.swapTransaction;
  const txBuffer = Buffer.from(txBase64, "base64");
  const transaction = VersionedTransaction.deserialize(txBuffer);

  // === 4. Sign dan Kirim
  transaction.sign([wallet]);
  const txid = await connection.sendTransaction(transaction);
  console.log(`✅ Swap ${Jumlah / 1e6} USDC => ${quote.outAmount / 1e6 } PYUSD berhasil dikirim! TxID:`, txid);

  const delay = (ms: number): Promise<void> => {
    return new Promise(resolve => setTimeout(resolve, ms));
  };

  await delay(20000);

  if (txid == null) {
 
  console.log("SWAP GAGAL");
  return;
  }

  const account2 = await getAccount(connection, ata);
  const amountRaw2 = Number(account2.amount);

//  if (amountRaw2 == amountRaw) {
//  console.log(`💰 Saldo USDC: ${amountRaw2 / 1e6}`);
//    console.error("Swap Gagal.. Mencoba kembali");
//    return;
//  }
  console.log(`💰 Saldo USDC: ${amountRaw2 / 1e6}`);

  if (amountRaw2 < 1000000) {
  return;
  }

  // === 2. Ambil Quote
  const quoteUrl2 = `https://lite-api.jup.ag/swap/v1/quote?inputMint=${INPUT_MINT}&outputMint=${OUTPUT_MINT2}&amount=${amountRaw2}&slippageBps=50`;
  const quoteResp2 = await axios.get(quoteUrl2);
  const quote2 = quoteResp2.data;

  if (!quote2 || !quote2.routePlan || quote2.routePlan.length === 0) {
    console.error("❌ Tidak ada rute ditemukan untuk swap");
    return;
  }

  // === 3. Buat Transaksi Swap
  const swapResp2 = await axios.post("https://lite-api.jup.ag/swap/v1/swap", {
    userPublicKey: walletPubkeyStr,
    quoteResponse: quote2,
    wrapAndUnwrapSol: true,
    computeUnitPriceMicroLamports: 500,
  });

  const txBase642 = swapResp2.data.swapTransaction;
  const txBuffer2 = Buffer.from(txBase642, "base64");
  const transaction2 = VersionedTransaction.deserialize(txBuffer2);

  // === 4. Sign dan Kirim
  transaction2.sign([wallet]);
  const txid2 = await connection.sendTransaction(transaction2);
  console.log(`===>>✅ Profit ${amountRaw2 / 1e6} USDC => ${quote2.outAmount / 1e6 } USDT berhasil di swap! TxID:`, txid2);

};

pyUsdc();
setInterval(pyUsdc, 30000)
