require('dotenv').config();
const { spawn } = require("child_process");
const { Connection, PublicKey, LAMPORTS_PER_SOL } = require("@solana/web3.js");

// === KONFIGURASI ===
const WALLET_ADDRESS = "6iLzQjQCFeq5FKmdPgHiTqkpvWEmwbDop12gZkTPzhTF";
const RPC = process.env.CONNECT;
const connection = new Connection(RPC, "confirmed");
const minimaljual = process.env.MINIMUMJUAL;
const delay = (ms) => new Promise((res) => setTimeout(res, ms));

async function cekLooping() {
  while (true) {
    try {
      const pubkey = new PublicKey(WALLET_ADDRESS);
      const balanceLamports = await connection.getBalance(pubkey);
      const balanceSOL = balanceLamports / LAMPORTS_PER_SOL;

//      console.log(`🪙 BALANCE: ${balanceSOL.toFixed(9)} SOL`);

      if (balanceSOL > minimaljual) {
//        console.log("✅ Melakukan penjualan SOL/PYUSD\n");

        const child = spawn("node", ["solpyusd4.js"]);

        child.stdout.on("data", (data) => {
          process.stdout.write(`📤 [external]: ${data}`);
        });

        child.stderr.on("data", (data) => {
          process.stderr.write(`❌ [external error]: ${data}`);
        });

        await new Promise((resolve) => {
          child.on("exit", (code) => {
//            console.log(`🔚 exit code ${code}`);
            resolve();
          });
        });
      } else {
//        console.log("⚠️  Fetching SOL Balance");
      }
    } catch (err) {
      console.error("❌ Terjadi kesalahan saat cek saldo:", err.message);
    }

//    console.log("⏳ Menunggu 30 detik untuk cek ulang...");
    await delay(30000);
  }
}

cekLooping();
