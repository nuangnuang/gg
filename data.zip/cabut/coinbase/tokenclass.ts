const { Connection, PublicKey } = require("@solana/web3.js");
const {
  TOKEN_PROGRAM_ID,
  TOKEN_2022_PROGRAM_ID,
} = require("@solana/spl-token");

// Ganti dengan alamat wallet yang ingin dicek
const WALLET_ADDRESS = new PublicKey("9obNtb5GyUegcs3a1CbBkLuc5hEWynWfJC6gjz5uWQkE");

// RPC endpoint Solana
const connection = new Connection("https://api.mainnet-beta.solana.com");

async function detectTokens() {
  try {
    // Ambil token SPL biasa
    const tokenAccounts = await connection.getParsedTokenAccountsByOwner(WALLET_ADDRESS, {
      programId: TOKEN_PROGRAM_ID,
    });

    // Ambil token SPL 2022
    const tokenAccounts2022 = await connection.getParsedTokenAccountsByOwner(WALLET_ADDRESS, {
      programId: TOKEN_2022_PROGRAM_ID,
    });

    console.log("📦 Token Program Biasa (SPL):");
    for (const { account } of tokenAccounts.value) {
      const info = account.data.parsed.info;
      const amount = info.tokenAmount.uiAmount;
      if (amount > 0) {
//        console.log(`- Mint: ${info.mint} | Amount: ${amount} | Program: SPL`);
      }
    }

    console.log("\n🆕 Token Program 2022 (SPL 2022):");
    for (const { account } of tokenAccounts2022.value) {
      const info = account.data.parsed.info;
      const amount = info.tokenAmount.uiAmount;
      if (amount > 0) {
        console.log(`- Mint: ${info.mint} | Amount: ${amount} | Program: SPL 2022`);
      }
    }

  } catch (error) {
    console.error("❌ Terjadi error:", error.message);
  }
}

detectTokens();
