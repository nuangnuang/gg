// main.js
const { spawn } = require('child_process');

const scripts = ['autopyusd.js', 'sendpyusd2.js', 'autosol2.js', 'usdcpyswap.js'];

scripts.forEach(script => {
  const proc = spawn('node', [script], { stdio: 'inherit' });
});
