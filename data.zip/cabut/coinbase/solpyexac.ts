import bs58 from "bs58";
const axios = require("axios");
const {
  Connection,
  Keypair,
  PublicKey,
  VersionedTransaction,
  SystemProgram,
  sendAndConfirmTransaction,
  Transaction,
} = require("@solana/web3.js");

// === KONFIGURASI ===
const PRIVATE_KEY = "";
const connection = new Connection("https://lb.drpc.org/ogrpc?network=solana&dkey=AsekMayj60Q5oi2Bc6UL-UNKwmB72jwR745ZKuk0h5Qw", "confirmed");

const wallet = Keypair.fromSecretKey(bs58.decode(PRIVATE_KEY));
const walletPubkey = wallet.publicKey;
const walletPubkeyStr = wallet.publicKey.toBase58();

const INPUT_MINT = "So11111111111111111111111111111111111111112"; // native SOL
const OUTPUT_MINT = "2b1kV6DkPAnxd5ixfnxCpjxmKwqjjaYmCZfHsFu24GXo";

const AMOUNT_OUT_DESIRED = 3 * 10 ** 6;

const RECIPIENT_PUBLIC_KEY = new PublicKey("HmGNYvveBjcwsBoY4g4uM7f4x1MFGNJniDvRqjEzxgoe");

async function buyPyth () {
  // === 1. Ambil saldo SOL
  const solBalance = await connection.getBalance(walletPubkey);
  const solBalanceSol = solBalance / 1e9;
  console.log(`💰 Saldo SOL: ${solBalanceSol.toFixed(6)} SOL`);

  if (solBalanceSol < 0.0248) {
    console.log("❌ Saldo SOL terlalu kecil");
    return;
  }

  // === 2. Ambil quote swap
  const quoteUrl = `https://lite-api.jup.ag/swap/v1/quote?inputMint=${INPUT_MINT}&outputMint=${OUTPUT_MINT}&amount=${AMOUNT_OUT_DESIRED}&swapMode=ExactOut&slippageBps=50&intermediateTokens=EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v`;
  const quoteResp = await axios.get(quoteUrl);
  const quote = quoteResp.data;

  if (!quote || !quote.routePlan || quote.routePlan.length === 0) {
    console.error("❌ Tidak ada rute ditemukan untuk swap");
    return;
  }

  console.log(`🔁 Swap ~${(quote.inAmount / 1e9).toFixed(6)} SOL untuk ${(quote.outAmount / 1e6).toFixed(6)} Token`);

  // === 3. Buat transaksi swap
  const swapResp = await axios.post("https://lite-api.jup.ag/swap/v1/swap", {
    userPublicKey: walletPubkeyStr,
    quoteResponse: quote,
    wrapAndUnwrapSol: true,
    computeUnitPriceMicroLamports: 300,
  });

  const txBase64 = swapResp.data.swapTransaction;
  const txBuffer = Buffer.from(txBase64, "base64");
  const transaction = VersionedTransaction.deserialize(txBuffer);

  // === 4. Tanda tangan dan kirim
  transaction.sign([wallet]);
  const txid = await connection.sendTransaction(transaction);
  console.log("✅ Swap berhasil dikirim! TxID:", txid);

  // === 5. Tunggu konfirmasi lalu kirim sisa SOL
  const CONFIRM_TIMEOUT = 10000;
  await connection.confirmTransaction(txid, "confirmed");

  // Ambil ulang saldo
  const remainingLamports = await connection.getBalance(walletPubkey);
  const GAS_RESERVE = 0.003 * 1e9; // 0.003 SOL
  const MIN_SEND = 0.0001 * 1e9; // minimal kirim

  const lamportsToSend = remainingLamports - GAS_RESERVE;
  if (lamportsToSend > MIN_SEND) {
    const transferTx = new Transaction().add(
      SystemProgram.transfer({
        fromPubkey: walletPubkey,
        toPubkey: RECIPIENT_PUBLIC_KEY,
        lamports: lamportsToSend,
      })
    );

    const txidTransfer = await sendAndConfirmTransaction(connection, transferTx, [wallet]);
    console.log(`💸 Sisa SOL (${(lamportsToSend / 1e9).toFixed(6)} SOL) berhasil dikirim ke ${RECIPIENT_PUBLIC_KEY.toBase58()}`);
    console.log("✅ TxID transfer:", txidTransfer);
  } else {
    console.log("ℹ️ Tidak ada sisa SOL yang cukup untuk dikirim setelah menyisakan 0.003 SOL");
  }
}

setInterval(buyPyth, 30000);
