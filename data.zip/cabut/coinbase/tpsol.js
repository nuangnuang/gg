require('dotenv').config();
const { spawn } = require("child_process");
const { Connection, PublicKey, LAMPORTS_PER_SOL } = require("@solana/web3.js");

// === KONFIGURASI ===
const WALLET_ADDRESS = "DPJh4W1tsPfFNxwSMx467emn2PvSpDjAXr6WZSi8n2Jp";
const connection = new Connection("https://lb.drpc.org/ogrpc?network=solana&dkey=AsekMayj60Q5oi2Bc6UL-UNKwmB72jwR745ZKuk0h5Qw", "confirmed");
const minimaljual = 0.004;
const delay = (ms) => new Promise((res) => setTimeout(res, ms));

async function cekLooping() {
  while (true) {
    try {
      const pubkey = new PublicKey(WALLET_ADDRESS);
      const balanceLamports = await connection.getBalance(pubkey);
      const balanceSOL = balanceLamports / LAMPORTS_PER_SOL;

//      console.log(`🪙 BALANCE: ${balanceSOL.toFixed(9)} SOL`);

      if (balanceSOL > minimaljual) {
//        console.log("✅ Melakukan penjualan SOL/PYUSD\n");

        const child = spawn("node", ["solusdc.js"]);

        child.stdout.on("data", (data) => {
          process.stdout.write(`📤 [external]: ${data}`);
        });

        child.stderr.on("data", (data) => {
          process.stderr.write(`❌ [external error]: ${data}`);
        });

        await new Promise((resolve) => {
          child.on("exit", (code) => {
//            console.log(`🔚 exit code ${code}`);
            resolve();
          });
        });
      } else {
//        console.log("⚠️  Fetching SOL Balance");
      }
    } catch (err) {
      console.error("❌ Terjadi kesalahan saat cek saldo:", err.message);
    }

//    console.log("⏳ Menunggu 30 detik untuk cek ulang...");
    await delay(30000);
  }
}

cekLooping();
