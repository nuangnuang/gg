const { Connection, PublicKey } = require('@solana/web3.js');

// Ganti ini dengan alamat wallet kamu
const walletAddress = '6iLzQjQCFeq5FKmdPgHiTqkpvWEmwbDop12gZkTPzhTF';

// Ganti ini dengan RPC dari DRPC (atau provider lain)
const DRPC_ENDPOINT = 'https://lb.drpc.org/solana/AsekMayj60Q5oi2Bc6UL-UMsJLNBWvQR8JcwrqRhf0fE';

const connection = new Connection(DRPC_ENDPOINT, 'confirmed');

(async () => {
  try {
    const pubkey = new PublicKey(walletAddress);

    let beforeSignature = null;
    let totalLamports = 0;
    let done = false;
    const limitPerPage = 1000;

    console.log(`🔍 Menghitung total gas fee wallet: ${walletAddress}`);

    while (!done) {
      const signatures = await connection.getSignaturesForAddress(pubkey, {
        before: beforeSignature,
        limit: limitPerPage,
      });

      if (signatures.length === 0) break;

      // Ambil detail transaksi secara paralel untuk efisiensi
      const txs = await Promise.allSettled(
        signatures.map(sig => connection.getTransaction(sig.signature, { commitment: 'confirmed' }))
      );

      for (const result of txs) {
        if (result.status === 'fulfilled') {
          const tx = result.value;
          if (tx?.meta?.fee) {
            totalLamports += tx.meta.fee;
          }
        }
      }

      beforeSignature = signatures[signatures.length - 1].signature;
      done = signatures.length < limitPerPage;

      console.log(`📦 Proses ${signatures.length} transaksi... Total fee sejauh ini: ${(totalLamports / 1e9).toFixed(6)} SOL`);
    }

    console.log(`\n✅ Total biaya gas wallet ${walletAddress}: ${(totalLamports / 1e9).toFixed(6)} SOL`);
  } catch (err) {
    console.error('❌ Error:', err);
  }
})();
