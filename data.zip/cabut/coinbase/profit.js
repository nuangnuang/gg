let currentValue = 0;
const incrementPerSecond = 17.743;

setInterval(() => {
  currentValue += incrementPerSecond;
  process.stdout.clearLine(0);               // Hapus baris saat ini
  process.stdout.cursorTo(0);                // Pindahkan kursor ke awal baris
  process.stdout.write(`Profit: ${currentValue.toFixed(3)} IDR`);
}, 1000);
