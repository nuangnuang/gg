import bs58 from "bs58";
const axios = require("axios");
const {
  Connection,
  Keypair,
  PublicKey,
  VersionedTransaction,
} = require("@solana/web3.js");
const { getAssociatedTokenAddress, getAccount } = require("@solana/spl-token");

// === KONFIGURASI ===
const PRIVATE_KEY = "45JT85FWbxUSDLTJkrxuQLcmC4BbNFwAqhy77mVQrMobMjoQ6zgoXpZV4gizEpDHcey24TETUz6EVbVNdqLf5moA";
const connection = new Connection("https://lb.drpc.org/ogrpc?network=solana&dkey=AsekMayj60Q5oi2Bc6UL-UNKwmB72jwR745ZKuk0h5Qw", "confirmed");

const wallet = Keypair.fromSecretKey(bs58.decode(PRIVATE_KEY));
const walletPubkey = wallet.publicKey;
const walletPubkeyStr = wallet.publicKey.toBase58();

// MINT TOKEN
const INPUT_MINT = new PublicKey("EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v");
const OUTPUT_MINT = "2b1kV6DkPAnxd5ixfnxCpjxmKwqjjaYmCZfHsFu24GXo";

(async () => {
  // === 1. Fetch Token Account & Saldo ===
  const ata = await getAssociatedTokenAddress(INPUT_MINT, walletPubkey);
  let account;
  try {
    account = await getAccount(connection, ata);
  } catch (e) {
    console.error("❌ Token account tidak ditemukan atau saldo 0");
    return;
  }

  const amountRaw = Number(account.amount); // tanpa desimal (native format)
  if (amountRaw === 0) {
    console.error("❌ Saldo token 0, tidak bisa swap");
    return;
  }
  const Jumlah = 3120000;
  console.log(`💰 Saldo USDC: ${amountRaw / 1e6}`);

  // === 2. Ambil Quote
  const quoteUrl = `https://lite-api.jup.ag/swap/v1/quote?inputMint=${INPUT_MINT}&outputMint=${OUTPUT_MINT}&amount=${Jumlah}&slippageBps=50`;
  const quoteResp = await axios.get(quoteUrl);
  const quote = quoteResp.data;

  if (!quote || !quote.routePlan || quote.routePlan.length === 0) {
    console.error("❌ Tidak ada rute ditemukan untuk swap");
    return;
  }

  // === 3. Buat Transaksi Swap
  const swapResp = await axios.post("https://lite-api.jup.ag/swap/v1/swap", {
    userPublicKey: walletPubkeyStr,
    quoteResponse: quote,
    wrapAndUnwrapSol: true,
    computeUnitPriceMicroLamports: 2000,
  });

  const txBase64 = swapResp.data.swapTransaction;
  const txBuffer = Buffer.from(txBase64, "base64");
  const transaction = VersionedTransaction.deserialize(txBuffer);

  // === 4. Sign dan Kirim
  transaction.sign([wallet]);
  const txid = await connection.sendTransaction(transaction);
  console.log(`✅ Swap ${Jumlah / 1e6} USDC => ${quote.outAmount / 1e6 } PYUSD berhasil dikirim! TxID:`, txid);
})();
