const axios = require('axios');
const crypto = require('crypto');
require('dotenv').config();
const API_KEY = process.env.KEY;
const API_SECRET = process.env.SECRET;
const BASE_URL = 'https://api.bybit.com';

function getSignature(body) {
  const payload = body.timestamp + API_KEY + body.recvWindow + JSON.stringify(body);
  return crypto.createHmac('sha256', API_SECRET).update(payload).digest('hex');
}

async function placeMarketOrder(symbol, usdtAmount) {
  const timestamp = Date.now().toString();
  const recvWindow = 5000;

  const body = {
    category: 'spot',
    symbol,            // contoh: 'WUSDT'
    side: 'Buy',
    orderType: 'Market',
    qty: usdtAmount.toString(),
    timestamp,
    recvWindow
  };

  const sign = getSignature(body);

  const res = await axios.post(`${BASE_URL}/v5/order/create`, body, {
    headers: {
      'X-BAPI-API-KEY': API_KEY,
      'X-BAPI-TIMESTAMP': timestamp,
      'X-BAPI-RECV-WINDOW': recvWindow.toString(),
      'X-BAPI-SIGN': sign,
      'Content-Type': 'application/json'
    }
  });

  return res.data;
}

// Contoh eksekusi trade market order
(async () => {
  const SYMBOL = 'WUSDT';   // pair token W terhadap USDT
  const USDT_AMOUNT = '2';

  try {
    console.log(`Melakukan market buy ${SYMBOL} dengan ${USDT_AMOUNT} USDT...`);
    const result = await placeMarketOrder(SYMBOL, USDT_AMOUNT);
    console.log('✅ Order berhasil:', result.result.orderId);
  } catch (error) {
    console.error('❌ Gagal melakukan order:', error.response?.data || error.message);
  }
})();
