import 'dotenv/config';
import {
  Connection,
  Keypair,
  PublicKey,
  Transaction,
  sendAndConfirmTransaction,
} from "@solana/web3.js";
import {
  getMint,
  getAssociatedTokenAddressSync,
  createTransferCheckedInstruction,
  TOKEN_2022_PROGRAM_ID,
} from "@solana/spl-token";
import bs58 from "bs58";

// Ambil dari .env
const jumlahtf = 19.5;
const wallet1 = process.env.PAYERGASS!;
const solWallet = "8Zm6WWK9rxAcVcSLuK7TnezXVL7ii6tC79NHsDAmr7WA";
const token_mint = process.env.TOKENMINT!;
const decimals = 6;
const RPC = process.env.CONNECT!;
const connection = new Connection(RPC, "confirmed");

(async () => {
  const sender = Keypair.fromSecretKey(bs58.decode(wallet1));
  const senderPubkey = sender.publicKey;

  const tokenMint = new PublicKey(token_mint);
  const recipientPublicKey = new PublicKey(solWallet);

  const senderTokenAccount = getAssociatedTokenAddressSync(
    tokenMint,
    senderPubkey,
    false,
    TOKEN_2022_PROGRAM_ID
  );

  const recipientTokenAccount = getAssociatedTokenAddressSync(
    tokenMint,
    recipientPublicKey,
    false,
    TOKEN_2022_PROGRAM_ID
  );

  // Ambil saldo token
  const balanceInfo = await connection.getTokenAccountBalance(senderTokenAccount);
  const currentBalance = parseFloat(balanceInfo.value.uiAmountString || "0");

  console.log(`💰 Saldo token saat ini: ${currentBalance}`);
//  console.log(`🔄 Jumlah yang diminta ditransfer: ${jumlahtf}`);

  if (currentBalance < jumlahtf) {
    return;
  }

  const rawAmount = Math.floor(jumlahtf * Math.pow(10, decimals));

  const tx = new Transaction().add(
    createTransferCheckedInstruction(
      senderTokenAccount,
      tokenMint,
      recipientTokenAccount,
      senderPubkey,
      rawAmount,
      decimals,
      [],
      TOKEN_2022_PROGRAM_ID
    )
  );

  const sig = await sendAndConfirmTransaction(connection, tx, [sender]);
  console.log("✅ Transfer berhasil:", sig);
})();
