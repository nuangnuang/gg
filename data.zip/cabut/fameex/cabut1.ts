import {
  Connection,
  PublicKey,
  Keypair,
  Transaction,
  sendAndConfirmTransaction,
  ComputeBudgetProgram,
} from "@solana/web3.js";
import {
  getAccount,
  createTransferInstruction,
  createCloseAccountInstruction,
} from "@solana/spl-token";
import bs58 from "bs58";

// Fungsi utama untuk batch transfer
(async () => {
  // Koneksi ke mainnet
  const connection = new Connection('https://quick-little-snowflake.solana-mainnet.quiknode.pro/3d986a8ea4cf4688c07bf1c8662034f9e058ea0d', 'confirmed');

  // Fee payer
  const feePayer = Keypair.fromSecretKey(
    bs58.decode(
      "5MJ7fBcubyXRVWD91cKBtwQPTRFeGhwYuuMuJGwp8Pftu9ZrwN8iWoev1EfRcTQPjrhsU4F5y1kJrrV5LiC8RytZ",
    ),
  );

  // Penerima token
  const recipientTokenPubkey = new PublicKey(
    "BF4pjBW8hacQ5yKc5GGvTNWZjAHKf2FwAHAABeQ3eLSN"
  );
  const recipientPubkey = new PublicKey("EMy56BV6L4ZdXUrgdzsRzGK12oenZMJSUNbpHVYgc8XZ");

  // Alamat mint token
  const tokenMintPubkey = new PublicKey(
    "Df6yfrKC8kZE3KNkrHERKzAetSxbrWeniQfyJY4Jpump"
  );

  // Daftar wallet
  const privateKeyList = [

"5dwAGk3EhQq5qaTRWScMuf6FVJGj8kbs2P4FeNNcQmV4ZUW14nU24LmzrzjsBXJEDVqwk3CCDEMnJqxeWCWVc8Wb",

"4tuG3MH85fKs1J2j9kb34mGJu1DyCviz9XBHJ9dJxbYeMZWQijkb9xvepf4Em9bTMzar1ZxZf2gSZ4YDTwUbQW4A",

"62DcVZSRCBr9xyStbGob2hinQh6VwBib1K5qHqzTbzY3CwH3LVgovfts4AHK3yMdMjGykuVtdQtM77agwVaKvvXX",

"5EBeuDRNw5jg1jdgV3haaF552tc9EJDrt8zXr15eMrwBJao3RErwMA987W1gsvuWeuR4VbRqr95UbX4pYdTRzHC3",

"4y4MKYAH4PtPhomTck1JmjuKoo2oGwZSYMnRKB3MXuDyXBhnBZZhghxR3DAeDsBP6bpPvewdZpB9UUUvGLrG6LX"

  ];

  // Buat transaksi
  const transaction = new Transaction();

  const PRIORITY_LAMPORTS = 30000;
  const priorityFeeInstruction = ComputeBudgetProgram.setComputeUnitPrice({
    microLamports: PRIORITY_LAMPORTS,
  });
  transaction.add(priorityFeeInstruction);

  // Koleksi signers (feePayer + semua pemilik wallet yang terlibat dalam transaksi)
  const signers = [feePayer];

  // Loop untuk mencari token accounts dari setiap private key
  for (let secretKey of privateKeyList) {
    const fromWallet = Keypair.fromSecretKey(bs58.decode(secretKey));
    const fromPublicKey = fromWallet.publicKey;

    // Cari token accounts yang dimiliki oleh wallet
    const tokenAccounts = await connection.getTokenAccountsByOwner(fromPublicKey, {
      mint: tokenMintPubkey,
    });

    // Loop untuk setiap token account dan lakukan transfer jika ada saldo
    for (let tokenAccountInfo of tokenAccounts.value) {
      const tokenAccountPubkey = new PublicKey(tokenAccountInfo.pubkey);
      const tokenAccountDetails = await getAccount(connection, tokenAccountPubkey);
      const tokenBalance = tokenAccountDetails.amount;

      if (tokenBalance > BigInt(0)) {
        // Tambahkan instruksi transfer token ke dalam transaksi
        transaction.add(
          createTransferInstruction(
            tokenAccountPubkey,
            recipientTokenPubkey,
            fromWallet.publicKey,
            tokenBalance,
            []
          )
        );

        // Tambahkan wallet pemilik akun token ke dalam signers
        signers.push(fromWallet);
      } else {
        console.log(`Akun token ${tokenAccountPubkey.toBase58()} tidak memiliki saldo.`);
      }
    }
  }

  try {
    const signature = await sendAndConfirmTransaction(connection, transaction, signers);
    console.log(`Batch transaksi berhasil dengan signature: ${signature}`);
  } catch (error) {
    console.error(`Error saat mengirim batch transaksi: ${error}`);
  }
})();
