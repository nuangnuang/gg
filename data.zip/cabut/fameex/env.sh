awk '{print "WALLET" NR "=" $1}' ENV.txt > wallet.txt
