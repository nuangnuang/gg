cat cabut1.txt | parallel
cat cabut1.txt | parallel
cat cabut1.txt | parallel
cat cabut1.txt | parallel
cat cabut1.txt | parallel
cat cabut1.txt | parallel
cat cabut1.txt | parallel
cat cabut1.txt | parallel
cat cabut1.txt | parallel
cat cabut1.txt | parallel

