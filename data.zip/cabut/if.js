const n1 = 1;
const n2 = 2;

if ( n1 < n2 ) {

console.log('sukses');

};
