// main.js
const { spawn } = require('child_process');

const scripts = ['tfusdt2.js'];

scripts.forEach(script => {
  const proc = spawn('node', [script], { stdio: 'inherit' });
});
