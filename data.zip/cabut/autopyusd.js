// main.js
const { spawn } = require('child_process');

const scripts = ['detecpyusd1.js', 'detecpyusd2.js', 'detecpyusd3.js', 'detecpyusd4.js', 'detecpyusd5.js'];

scripts.forEach(script => {
  const proc = spawn('node', [script], { stdio: 'inherit' });
});
