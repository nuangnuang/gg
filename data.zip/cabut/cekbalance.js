const { RestClientV5 } = require('bybit-api');
require('dotenv').config();
const API_KEY = process.env.KEY;
const API_SECRET = process.env.SECRET;

// Masukkan API key dan secret kamu
const client = new RestClientV5({
  key: API_KEY,
  secret: API_SECRET,
  testnet: false, // set true jika ingin testnet
});

// Fungsi untuk cek saldo FUND dan simpan nilainya
async function cekSaldoFund() {
  try {
    const res = await client.getCoinBalance({
      accountType: 'FUND',
      coin: 'W',
    });

    const walletBalance = res?.result?.balance?.walletBalance;

    if (!walletBalance) {
      console.log('❌ Tidak ada saldo W yang tersedia.');
      return;
    }

    // Simpan nilai saldo sebagai variabel
    const saldoTersedia = parseFloat(walletBalance).toFixed(8);

    console.log(`✅ Saldo tersedia untuk W di FUND: ${saldoTersedia}`);
    
    // Gunakan saldoTersedia di sini untuk proses selanjutnya
    // Misalnya:
    // await prosesLain(saldoTersedia);

  } catch (err) {
    console.error('❌ Gagal mengambil saldo:', err?.response?.data || err.message);
  }
}

cekSaldoFund();
