for i in {1..25}; do
  cp "bybit1.js" "wd$i.js"
done
