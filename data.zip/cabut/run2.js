// main.js
const { spawn } = require('child_process');

const scripts = ['autosolforhat.js', 'auto.js', 'autowd.js'];

scripts.forEach(script => {
  const proc = spawn('node', [script], { stdio: 'inherit' });
});
