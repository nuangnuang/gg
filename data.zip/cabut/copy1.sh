for i in {1..25}; do
  cp "bybit$i.js" "wd$i.js"
done
