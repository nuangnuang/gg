const { Connection, PublicKey, clusterApiUrl } = require('@solana/web3.js');

// Ganti dengan wallet yang mau dicek
const WALLET_ADDRESS = 'EnwHZMkBUvem41GhDLvEo5bVb9Rz9kLyTDcqGgfBfKcZ';

// Endpoint Solana RPC (bisa pakai 'mainnet-beta', atau custom endpoint)
const connection = new Connection(clusterApiUrl('mainnet-beta'), 'confirmed');

// Fungsi untuk cek saldo
async function checkBalance() {
    try {
        const publicKey = new PublicKey(WALLET_ADDRESS);
        const balance = await connection.getBalance(publicKey);
        console.log(`[${new Date().toLocaleTimeString()}] Balance: ${balance / 1e9} SOL`);
    } catch (error) {
        console.error('Error fetching balance:', error.message);
    }
}

// Loop setiap 10 detik
setInterval(checkBalance, 30000);

// Jalankan pertama kali tanpa nunggu 10 detik
checkBalance();
