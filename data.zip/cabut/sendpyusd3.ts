import 'dotenv/config';
import {
  Connection,
  Keypair,
  PublicKey,
  Transaction,
  sendAndConfirmTransaction,
} from "@solana/web3.js";
import {
  getAssociatedTokenAddressSync,
  createTransferCheckedInstruction,
  TOKEN_2022_PROGRAM_ID,
} from "@solana/spl-token";
import bs58 from "bs58";

// Ambil dari .env
const jumlahtf = 6.51;
const wallet1 = process.env.PAYERGASS!;
const solWallet = "8Zm6WWK9rxAcVcSLuK7TnezXVL7ii6tC79NHsDAmr7WA";
const token_mint = process.env.TOKENMINT!;
const decimals = 6;
const RPC = process.env.CONNECT!;
const connection = new Connection(RPC, "confirmed");

// Inisialisasi Keypair dan PublicKey
const sender = Keypair.fromSecretKey(bs58.decode(wallet1));
const senderPubkey = sender.publicKey;
const tokenMint = new PublicKey(token_mint);
const recipientPublicKey = new PublicKey(solWallet);

const senderTokenAccount = getAssociatedTokenAddressSync(
  tokenMint,
  senderPubkey,
  false,
  TOKEN_2022_PROGRAM_ID
);

const recipientTokenAccount = getAssociatedTokenAddressSync(
  tokenMint,
  recipientPublicKey,
  false,
  TOKEN_2022_PROGRAM_ID
);

// Fungsi utama transfer
const transferIfEligible = async () => {
  try {
    const balanceInfo = await connection.getTokenAccountBalance(senderTokenAccount);
    const currentBalance = parseFloat(balanceInfo.value.uiAmountString || "0");

    console.log(`\n[${new Date().toLocaleTimeString()}] 💰 Saldo: ${currentBalance}`);
//    console.log(`🔄 Ingin transfer: ${jumlahtf}`);

    if (currentBalance < jumlahtf) {
//      console.log("⏸️ Saldo belum cukup. Menunggu loop berikutnya...");
      return;
    }

    const rawAmount = Math.floor(jumlahtf * Math.pow(10, decimals));

    const tx = new Transaction().add(
      createTransferCheckedInstruction(
        senderTokenAccount,
        tokenMint,
        recipientTokenAccount,
        senderPubkey,
        rawAmount,
        decimals,
        [],
        TOKEN_2022_PROGRAM_ID
      )
    );

    const sig = await sendAndConfirmTransaction(connection, tx, [sender]);
    console.log("✅ Transfer berhasil:", sig);
  } catch (err) {
    console.error("❌ Terjadi kesalahan saat transfer:", err);
  }
};

// Jalankan setiap 30 detik (30000 ms)
setInterval(transferIfEligible, 30000);

// Bisa juga langsung dipanggil sekali di awal
transferIfEligible();
