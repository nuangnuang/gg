const { RestClientV5 } = require('bybit-api');
require('dotenv').config();

const client = new RestClientV5({
  key: process.env.KEY,
  secret: process.env.SECRET,
  testnet: false,
});

// ====== SETTING ======
const SYMBOL = 'WUSDT';         // Ubah ke symbol valid jika perlu
const MIN_USDT_BALANCE = 20;    // Minimum saldo USDT untuk trigger
const MANUAL_QTY = 28.5;          // Jumlah token yang ingin dibeli (qty W)

async function getUSDTBalance() {
  try {
    const res = await client.getCoinBalance({
      accountType: 'UNIFIED',
      coin: 'USDT',
    });
    const saldo = parseFloat(res.result.balance.walletBalance);
    console.log(`💰 Saldo USDT saat ini: ${saldo}`);
    return saldo;
  } catch (err) {
    console.error('❌ Gagal mendapatkan saldo:', err?.response?.data || err.message);
    return 0;
  }
}

async function placeMarketBuy(symbol, qty) {
  try {
    const order = await client.submitOrder({
      category: 'spot',
      symbol,
      side: 'Buy',
      orderType: 'Market',
      qty: qty.toString(),  // Kirim qty manual
    });
    return order;
  } catch (err) {
    throw err;
  }
}

(async () => {
  try {
    const usdtBalance = await getUSDTBalance();

    if (usdtBalance >= MIN_USDT_BALANCE) {
      console.log(`✅ Saldo cukup trade dilakukan sebesar ${MANUAL_QTY}USDT`);
      const result = await placeMarketBuy(SYMBOL, MANUAL_QTY);
      console.log('✅ Order berhasil:', result.result.orderId);
    } else {
      console.log(`⏳ Saldo belum mencukupi (${usdtBalance} USDT). Minimal: ${MIN_USDT_BALANCE} USDT`);
    }
  } catch (e) {
    console.error('❌ Order gagal:', e?.response?.data || e.message);
  }
})();
