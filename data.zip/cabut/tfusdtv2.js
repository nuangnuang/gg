import bs58 from "bs58";
import {
  Connection,
  Keypair,
  PublicKey,
  Transaction,
  sendAndConfirmTransaction,
} from "@solana/web3.js";
import {
  getAssociatedTokenAddress,
  getAccount,
  createTransferInstruction,
} from "@solana/spl-token";

// === KONFIGURASI ===
const connection = new Connection(
  "https://lb.drpc.org/ogrpc?network=solana&dkey=AsekMayj60Q5oi2Bc6UL-UNKwmB72jwR745ZKuk0h5Qw",
  "confirmed"
);

const USDT_MINT = new PublicKey("Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB"); // USDT di Solana
const WORMHOLE_MINT = new PublicKey("85VBFQZC9TZkfaptBWjvUw7YbZjy52A6mjtPGjstQAmQ");
const WALLET_TO_MONITOR = new PublicKey("EKf7sJMNZnyW5tPmcCxBX19Vhp7t8kqd7zYJ1uyD5yz8");
const DESTINATION = new PublicKey("87h6dMz9HfSa4w6erJXPXg4L1kVR9qPfu33eJCKSh18m"); // tujuan transfer USDT
const WORMHOLE_THRESHOLD = 1;
const AMOUNT_TO_SEND = 15;

const PRIVATE_KEY = "3NWabn8yyh7SUtUtfuJuzpQXcvWaMBjyy6MpWFyFSoDdgo647Z44izogWAoj2DWyae11qyehJnaZY3Rnfx3HnhYm";
const wallet = Keypair.fromSecretKey(bs58.decode(PRIVATE_KEY));
const delay = (ms) => new Promise((res) => setTimeout(res, ms));

async function fetchTokenBalance(mint, pubkey) {
  try {
    const ata = await getAssociatedTokenAddress(mint, pubkey);
    const tokenAccount = await getAccount(connection, ata);
    const decimals = mint.equals(USDT_MINT) ? 6 : 6; // bisa disesuaikan
    const amount = Number(tokenAccount.amount) / 1e6;
    return { amount, ata };
  } catch (err) {
//    console.error(`❌ Gagal fetch saldo token ${mint.toBase58()}:`, err.message);
    return { amount: 0 };
  }
}

async function transferUSDT() {
  const now = new Date();

  const { amount: wormholeAmount } = await fetchTokenBalance(WORMHOLE_MINT, WALLET_TO_MONITOR);
  const { amount: usdtAmount, ata: usdtAta } = await fetchTokenBalance(USDT_MINT, wallet.publicKey);

  console.log(
    `🪙 [${now.toTimeString().split(" ")[0]}] USDT : ${usdtAmount}`
  );

  if (wormholeAmount > WORMHOLE_THRESHOLD) {
//    console.log(`✅ Syarat terpenuhi. Mengirim ${AMOUNT_TO_SEND} USDT ke ${DESTINATION.toBase58()}`);

    const destAta = await getAssociatedTokenAddress(USDT_MINT, DESTINATION);
    const ix = createTransferInstruction(
      usdtAta,
      destAta,
      wallet.publicKey,
      AMOUNT_TO_SEND * 1e6
    );

    const tx = new Transaction().add(ix);
    const sig = await sendAndConfirmTransaction(connection, tx, [wallet]);
    console.log(`🚀 Transfer berhasil! Signature: ${sig}`);
  } else {
//    console.log("⛔ Token Wormhole di Wallet 2 belum memenuhi syarat. Tidak ada transfer.");
  }
}

async function mainLoop() {
  while (true) {
    try {
      await transferUSDT();
    } catch (err) {
//      console.error("❌ Kesalahan saat transferUSDT:", err.message);
    }
    await delay(5000);
  }
}

mainLoop();
