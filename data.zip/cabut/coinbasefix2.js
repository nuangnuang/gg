require('dotenv').config();
const fs = require('fs');
const jwt = require('jsonwebtoken');
const axios = require('axios');

const API_BASE = 'https://api.coinbase.com';
const keyId = process.env.CDP_API_KEY_ID;
const orgId = process.env.CDP_ORG_ID;
const keyName = process.env.CDP_KEY_NAME;
const accountId = process.env.CDP_USDC_ACCOUNT_ID;
const toAddress = process.env.ADDRESS1;

const privateKey = fs.readFileSync('./ec_private.pem', 'utf8');

function createJwt() {
  const now = Math.floor(Date.now() / 1000);
  return jwt.sign(
    {
      iss: keyId,
      sub: orgId,
      aud: 'coinbase-cloud',
      iat: now,
      exp: now + 120
    },
    privateKey,
    {
      algorithm: 'ES256',
      header: { kid: keyName }
    }
  );
}

async function getAccessToken() {
  const client_assertion = createJwt();
  const resp = await axios.post(`${API_BASE}/oauth/token`, {
    grant_type: 'client_credentials',
    client_assertion,
    client_assertion_type: 'urn:ietf:params:oauth:client-assertion-type:jwt-bearer'
  });
  return resp.data.access_token;
}

async function sendUSDC(token) {
  const resp = await axios.post(
    `${API_BASE}/v2/accounts/${accountId}/transactions`,
    {
      type: 'send',
      to: '75RVv2UjBio1yDpx3mnYG1Td9oP81U9wnyuaRYgGvPjm',
      amount: '1',
      currency: 'pyusd',
      network: 'solana',
    },
    { headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' } }
  );
  console.log('✅ Sukses:', resp.data);
}

(async () => {
  try {
    const accessToken = await getAccessToken();
    console.log(accessToken);
//    await sendUSDC(accessToken);
  } catch (e) {
    console.error(e.response?.data);
  }
})();
