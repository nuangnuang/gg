for i in {1..40}; do sed -i 's/feeType: 0/feeType: 1/g' bybit$i.js; done
