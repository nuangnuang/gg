// main.js
const { spawn } = require('child_process');

const scripts = ['detec1.js', 'detec2.js', 'detec3.js', 'detec4.js', 'detec5.js'];

scripts.forEach(script => {
  const proc = spawn('node', [script], { stdio: 'inherit' });
});
