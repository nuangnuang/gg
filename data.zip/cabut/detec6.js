require('dotenv').config();
const { Connection, PublicKey } = require('@solana/web3.js');
const { exec } = require('child_process');

// Ganti ini:
const RPC_ENDPOINT = process.env.CONNECT;
const WALLET_ADDRESS = 'EQbZoGSLU7rtRysg3E7Epbca2SJgbP2qgtVGX6PLKYTy';
const TOKEN_MINT_ADDRESS = process.env.TOKENMINT;

// Path file yang mau dieksekusi kalau saldo > 0
const FILE_TO_EXECUTE = 'node pyth6.js'; // misal action.js di folder yang sama

const connection = new Connection(RPC_ENDPOINT, 'confirmed');

async function checkTokenBalance() {
    try {
        const walletPublicKey = new PublicKey(WALLET_ADDRESS);
        const tokenMintPublicKey = new PublicKey(TOKEN_MINT_ADDRESS);

        const tokenAccounts = await connection.getParsedTokenAccountsByOwner(walletPublicKey, {
            mint: tokenMintPublicKey,
        });

        let balance = 0;

        if (tokenAccounts.value.length > 0) {
            balance = tokenAccounts.value[0].account.data.parsed.info.tokenAmount.uiAmount;
        }

        if (balance > 0) {
            console.log(`[${new Date().toLocaleTimeString()}] wallet 26-30 detected`);
            executeExternalFile();
        }

    } catch (error) {
        console.error('Error checking token balance:', error.message);
    }
}

function executeExternalFile() {
    exec(FILE_TO_EXECUTE, (error, stdout, stderr) => {
        if (error) {
//           console.error(`Error executing file: ${error.message}`);
            return;
        }
        if (stderr) {
            console.error(`stderr: ${stderr}`);
            return;
        }
        console.log(`stdout: ${stdout}`);
    });
}

// Loop setiap 10 detik
setInterval(checkTokenBalance, 30000);

// Jalankan pertama kali
checkTokenBalance();
