#!/bin/bash

# Warna ANSI
RED='\033[0;31m'
GREEN='\033[1;32m'   # Hijau terang
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
PINK='\033[0;35m'
NC='\033[0m' # Reset warna

# Daftar warna untuk countdown bergantian
COLORS=("$RED" "$GREEN" "$YELLOW" "$BLUE" "$CYAN" "$PINK")

# Fungsi untuk sleep dengan menampilkan detikan berwarna-warni
sleep_with_countdown() {
  local duration=$1
  local i=0
  while [ $duration -gt 0 ]; do
    local color="${COLORS[$i]}"
    echo -ne "Sleep ${color}${duration} ${NC}detik.\r"
    sleep 1
    ((duration--))
    ((i=(i+1)%${#COLORS[@]}))
  done
  echo -ne "\n"
}

for i in {1..50}; do
  echo -e "${GREEN}     WALLET $i            ${NC}"

  node bybit$i.js
  sleep_with_countdown 10
done
