const axios = require('axios');
const readline = require('readline');
const chalk = require('chalk');
const jumlahAkun = 4800;
//const rl = readline.createInterface({
//  input: process.stdin,
//  output: process.stdout
//});

//function tanyaInput(pertanyaan) {
//  return new Promise(resolve => {
//    rl.question(pertanyaan, (jawaban) => {
//      rl.close();
//      resolve(jawaban);
//    });
//  });
//}

async function main() {
//  const input = await tanyaInput('Withdrawal Fee: ');
//  const fees = parseFloat(input);

//  if (isNaN(fees)) {
//    console.log("❌ Nilai tidak valid");
//    return;
// }
  const feesauto = 0.00205;
  const hargaUsdt = 16225;
  const tokenInDesimal = 9;
  const tokenOutDesimal = 6;
  const amountToSwap = Math.floor(feesauto * 10 ** tokenInDesimal);
  const SOL = 'So11111111111111111111111111111111111111112';
  const USDT = 'Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB';
  const Wormhole = '85VBFQZC9TZkfaptBWjvUw7YbZjy52A6mjtPGjstQAmQ';
  const DOOD = 'DvjbEsdca43oQcw2h3HW1CT7N3x5vRcr3QrvTUHnXvgV';
  const PYTH = 'HZ1JovNiVvGrGNiiYvEozEVgZ58xaU3RKwX8eACQBCt3';
  const PYUSD = '2b1kV6DkPAnxd5ixfnxCpjxmKwqjjaYmCZfHsFu24GXo';
  try {
    const quoteUrl = `https://lite-api.jup.ag/swap/v1/quote?inputMint=${SOL}&outputMint=${USDT}&amount=${amountToSwap}&slippageBps=50`;
    const quoteResp = await axios.get(quoteUrl);
    const quote = quoteResp.data;

    const quoteUrl2 = `https://lite-api.jup.ag/swap/v1/quote?inputMint=${SOL}&outputMint=${USDT}&amount=1000000000&slippageBps=50`;
    const quoteResp2 = await axios.get(quoteUrl2);
    const quote2 = quoteResp2.data;

    const hargaSol = quote2.outAmount / 10 ** 6;
    const masuk = amountToSwap / 10 ** tokenInDesimal;
    const keluar = quote.outAmount / 10 ** tokenOutDesimal;
    const profit = 0.0021824 - feesauto;
    const profitIdr = profit * hargaSol * hargaUsdt;
    const profitUsd = profit * hargaSol;
    const idrTotal = profitIdr * jumlahAkun;
    const usdTotal = profitUsd * jumlahAkun;

console.log(chalk.green("✅ Hasil:"));
console.log(chalk.white(`- Fee                     : ${masuk} SOL`));
console.log(chalk.white(`- Fee Dalam Sol           : ${keluar} USDT`));
console.log(chalk.yellow(`- Harga Sol               : ${hargaSol} USDT`));
console.log(chalk.green(`- Profit IDR              : Rp ${profitIdr}`));
console.log(chalk.green(`- Profit USD              : $${profitUsd.toFixed(5)}`));
console.log(chalk.green(`- Total Profit ${jumlahAkun} X     : $${(usdTotal).toFixed(4)} / Rp ${(idrTotal).toFixed(2)}`));
  } catch (err) {
    console.error("❌ Gagal mengambil quote:", err.message);
  }
}

main();
setInterval(main, 60000);
