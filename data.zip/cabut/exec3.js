// main.js
const { spawn } = require('child_process');

const scripts = ['cabut5.js', 'cabut6.js'];

scripts.forEach(script => {
  const proc = spawn('node', [script], { stdio: 'inherit' });
});
