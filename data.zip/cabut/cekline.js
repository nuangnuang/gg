const fs = require('fs');
const path = require('path');

for (let i = 1; i <= 50; i++) {
  const filename = `bybit${i}.js`;
  const filepath = path.join(__dirname, filename);

  if (fs.existsSync(filepath)) {
    const lines = fs.readFileSync(filepath, 'utf-8').split('\n');
    console.log(`\n📁 File: ${filename}`);
    
    const line29 = lines[10] !== undefined ? lines[10] : '[Line 11 not found]';


    console.log(`🔸 Line 30: ${line29}`);
  } else {
    console.log(`\n❌ File not found: ${filename}`);
  }
}
