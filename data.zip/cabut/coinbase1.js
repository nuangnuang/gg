require('dotenv').config();
const fs = require('fs');
const jwt = require('jsonwebtoken');
const axios = require('axios');

// Konfigurasi dari .env
const API_BASE = "https://api.coinbase.com/v2";
const keyId = process.env.CDP_API_KEY_ID;
const orgId = process.env.CDP_ORG_ID;
const privateKey = fs.readFileSync(process.env.CDP_PRIVATE_KEY_PATH, 'utf8');
const toAddress = process.env.ADDRESS1;
const amountToSend = 1;
const accountId = 'ef1a84a4-c6e8-51c2-8c5e-97e7a3065b33';
// Buat JWT untuk autentikasi
const { sign } = require('jsonwebtoken');
const crypto = require('crypto');

const key_name = 'organizations/999c1983-f201-4a3f-ac2d-1c7ef3c895fd/apiKeys/a379bce9-cef9-47a9-9ffa-a88bf033a9ea';
const key_secret = '-----BEGIN EC PRIVATE KEY-----\nMHcCAQEEINY2GcGMSmqNe4/m0r1KWvEMfsuISv+HrEp+4PX6oyHeoAoGCCqGSM49\nAwEHoUQDQgAEaV4cMC39zZ2Igsu/06Y5myl9AHtbLti5C8CqAS8YXCBBKdnYaZ6b\nslscwRP54VKhbQ82jazvyQByxSOzHJC43w==\n-----END EC PRIVATE KEY-----\n';
const request_method = 'GET';
const url = 'api.coinbase.com';
const request_path = '/v2/accounts';

const algorithm = 'ES256';
const uri = request_method + ' ' + url + request_path;

const token = sign(
    {
        iss: 'cdp',
        nbf: Math.floor(Date.now() / 1000),
        exp: Math.floor(Date.now() / 1000) + 120,
        sub: key_name,
        uri,
    },
    key_secret,
    {
        algorithm,
        header: {
            kid: key_name,
            nonce: crypto.randomBytes(16).toString('hex'),
        },
    }
);
console.log('export JWT=' + token);

// Fungsi ambil accountId untuk USDC
async function getUsdcAccountId(token) {
  try {
    const res = await axios.get(`${API_BASE}/accounts`, {
      headers: { Authorization: `Bearer ${token}` }
    });

    const accounts = res.data?.data || [];
    console.log(JSON.stringify(res.data, null, 2));
    const usdc = accounts.find(
      acc =>
        acc.name.toLowerCase().includes("pyusd") &&
        acc.balance?.currency?.toLowerCase() === "pyusd"
    );

    if (!usdc) throw new Error("Account USDC tidak ditemukan.");
    return usdc.id;
  } catch (err) {
    throw new Error("Gagal ambil account USDC: " + (err.response?.data?.error || err.message));
  }
}

// Fungsi kirim USDC
async function sendUsdc(token, accountId) {
  try {
    const res = await axios.post(
      `${API_BASE}/accounts/${accountId}/transactions`,
      {
        type: "send",
        to: toAddress,
        amount: amountToSend,
        asset: "pyusd",
        network: "solana"
      },
      {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json"
        }
      }
    );

    console.log("✅ Transaksi sukses:");
    console.log(res.data);
  } catch (err) {
    console.error("❌ Gagal kirim USDC:");
    console.error(err.response?.data);
  }
}

// Fungsi utama
(async () => {
  try {
    const accountId = await getUsdcAccountId(token);
    console.log("🔎 Ditemukan PYUSD Account ID:", accountId);
    await sendUsdc(token, accountId);
  } catch (e) {
    console.error("❌ Error:", e.message);
  }
})();
