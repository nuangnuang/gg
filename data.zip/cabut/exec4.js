// main.js
const { spawn } = require('child_process');

const scripts = ['cabut7.js', 'cabut8.js'];

scripts.forEach(script => {
  const proc = spawn('node', [script], { stdio: 'inherit' });
});
