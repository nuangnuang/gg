const { RestClientV5 } = require('bybit-api');
require('dotenv').config();
const { spawn } = require('child_process');
const triggering = process.env.TRIGERWD;
const client = new RestClientV5({
  key: process.env.KEY,
  secret: process.env.SECRET,
  testnet: false,
});
const TOKEN = process.env.COIN;
const AMOUNT_TRIGGER = triggering ;
const INTERVAL_MS = 20000;
const SHELL_SCRIPT_PATH = 'wdantri.js';

async function getWormholeBalance() {
  try {
    const res = await client.getCoinBalance({
      accountType: 'FUND',
      coin: TOKEN,
    });

    const balance = parseFloat(res.result.balance.walletBalance);
//    console.log(`💫 Saldo ${TOKEN}: ${balance} Monitoring WD`);
    return balance;
  } catch (err) {
    console.error(`❌ Gagal cek saldo ${TOKEN}:`, err?.response?.data || err.message);
    return 0;
  }
}

function runShellScriptRealtime(path) {
  return new Promise((resolve, reject) => {
    const child = spawn('node', [path]);

    child.stdout.on('data', data => {
      process.stdout.write(`🟢 ${data}`);
    });

    child.stderr.on('data', data => {
      process.stderr.write(`🔴 ${data}`);
    });

    child.on('close', code => {
      console.log(`✅ Withdraw Selesai`);
      resolve();
    });

    child.on('error', err => {
      console.error('❌ Error saat menjalankan script:', err.message);
      reject(err);
    });
  });
}

async function monitorAndRunScript() {
  while (true) {
    try {
      const balance = await getWormholeBalance();

      if (balance >= AMOUNT_TRIGGER) {
        console.log(`🚀 Saldo ${TOKEN}ormhole cukup (${balance}), Preparing withdraw`);
        await runShellScriptRealtime(SHELL_SCRIPT_PATH);
      } else {
//        console.log(`⏳ Saldo ${TOKEN} belum mencukupi Untuk penarikan.`);
      }

      await new Promise(resolve => setTimeout(resolve, INTERVAL_MS));
    } catch (err) {
      console.error('❌ Error dalam loop:', err.message);
      await new Promise(resolve => setTimeout(resolve, INTERVAL_MS));
    }
  }
}

monitorAndRunScript();
