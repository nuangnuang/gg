require('dotenv').config();
const { RestClientV5 } = require('bybit-api');
const { v4: uuidv4 } = require('uuid');
const minimumSaldo = process.env.TRIGERWD;
const API_KEY = process.env.KEY;
const API_SECRET = process.env.SECRET;
const COIN = process.env.COIN;
const client = new RestClientV5({
  key: API_KEY,
  secret: API_SECRET,
  testnet: false,
});

// Konfigurasi
const MINIMAL_SALDO = minimumSaldo;
const CHECK_INTERVAL_MS = 20000;        // Interval pengecekan dalam milidetik (10000 = 10 detik)
const FROM_ACCOUNT = 'UNIFIED';
const TO_ACCOUNT = 'FUND';

// Fungsi utama pengecekan dan transfer
async function cekSaldoDanTransfer() {
  try {
    const res = await client.getCoinBalance({
      accountType: FROM_ACCOUNT,
      coin: COIN,
    });

    const walletBalance = res?.result?.balance?.walletBalance;

    if (!walletBalance || parseFloat(walletBalance) < MINIMAL_SALDO) {
//      console.log(`⏳ Saldo ${COIN} belum cukup untuk transfer`);
      return;
    }

    const saldoTersedia = parseFloat(walletBalance).toFixed(8);
    console.log(`✅ Saldo cukup: ${saldoTersedia} ${COIN} — Melakukan transfer`);

    const transferId = uuidv4();
    const transferResponse = await client.createInternalTransfer(
      transferId,
      COIN,
      saldoTersedia,
      FROM_ACCOUNT,
      TO_ACCOUNT
    );

    console.log(`✅ Transfer berhasil`);

  } catch (err) {
    console.error('❌ Error saat proses transfer:', err?.response?.data || err.message);
  }
}

// Jalankan secara periodik dengan interval
setInterval(cekSaldoDanTransfer, CHECK_INTERVAL_MS);
