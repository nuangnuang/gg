// main.js
const { spawn } = require('child_process');

const scripts = ['cabut9.js', 'cabut10.js'];

scripts.forEach(script => {
  const proc = spawn('node', [script], { stdio: 'inherit' });
});
