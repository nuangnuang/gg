import {
  Connection,
  PublicKey,
  Keypair,
  Transaction,
  sendAndConfirmTransaction,
  ComputeBudgetProgram,
} from "@solana/web3.js";
import {
  getAccount,
  createTransferInstruction,
  createCloseAccountInstruction,
} from "@solana/spl-token";
import bs58 from "bs58";

// Fungsi utama untuk batch transfer
(async () => {
  // Koneksi ke mainnet
  const connection = new Connection('https://quick-little-snowflake.solana-mainnet.quiknode.pro/3d986a8ea4cf4688c07bf1c8662034f9e058ea0d', 'confirmed');

  // Fee payer
  const feePayer = Keypair.fromSecretKey(
    bs58.decode(
      "5BtG2dTGTZvqoENummcm44df5QujFHukgWBZPZrg29c2QHJbFx6RVboEhGQgyqxapJxbiiB7EgHSSaVES15FJfFd",
    ),
  );

  // Penerima token
  const recipientTokenPubkey = new PublicKey(
    "NPjk8sZSQ2pBrUbXqefnJSrFpnr3HUMW4hqoJTFnqCb"
  );
  const recipientPubkey = new PublicKey("EMy56BV6L4ZdXUrgdzsRzGK12oenZMJSUNbpHVYgc8XZ");

  // Alamat mint token
  const tokenMintPubkey = new PublicKey(
    "552wpQEPCdXp2BoHfF6FAwhvhaEeV9zd6FLrtzsjpump"
  );

  // Daftar wallet
  const privateKeyList = [

"2ntH6YKe4HLgaqae3hDiF3J988E3BXooGryBghkFCBbG5z1A7X8o5cDMRnTPisGgkeGKm25DyKiZdjeJKryED9ZR",

"ezpTwbwQkSbgFAbGFPmuK7mEZRgAHPy5szWbKRkY6UjXrVqYLPVYMdatehwYqYjZwghVpdNWtZds9hc6mEi6pNA",

"3ANQDvT5YuB4KjP4TdPDVmW72vQCCrqn5hQ5fHfU9PnHDNkXkySuwcgayRCvQxMAEPTdETu5Ju94LsY5UefjfdeP",

"D98J7H9pvEaGmo2TzX2B5umogA5FRBPf4oAsst5bruo3LcJMXZ9tKgeSVjfeKqU8rF4BhYiroch6emQoVryywLR",

"FQQSDDxCSnNre2kLvG9hN5SNH9LFG1gbZD45A7ZDx2eiTJZfWJ9hBaKMtjTafysfxrWdahixpdw1r2GSqNEgrbE"

  ];

  // Buat transaksi
  const transaction = new Transaction();


// Tambahkan priority fee di awal transaksi
const PRIORITY_LAMPORTS = 20000;
const priorityFeeInstruction = ComputeBudgetProgram.setComputeUnitPrice({
  microLamports: PRIORITY_LAMPORTS,
});
transaction.add(priorityFeeInstruction);

  // Koleksi signers (feePayer + semua pemilik wallet yang terlibat dalam transaksi)
  const signers = [feePayer];

  // Loop untuk mencari token accounts dari setiap private key
  for (let secretKey of privateKeyList) {
    const fromWallet = Keypair.fromSecretKey(bs58.decode(secretKey));
    const fromPublicKey = fromWallet.publicKey;

    // Cari token accounts yang dimiliki oleh wallet
    const tokenAccounts = await connection.getTokenAccountsByOwner(fromPublicKey, {
      mint: tokenMintPubkey,
    });

    // Loop untuk setiap token account dan lakukan transfer jika ada saldo
    for (let tokenAccountInfo of tokenAccounts.value) {
      const tokenAccountPubkey = new PublicKey(tokenAccountInfo.pubkey);
      const tokenAccountDetails = await getAccount(connection, tokenAccountPubkey);
      const tokenBalance = tokenAccountDetails.amount;

      if (tokenBalance > BigInt(0)) {
        // Tambahkan instruksi transfer token ke dalam transaksi
        transaction.add(
          createTransferInstruction(
            tokenAccountPubkey,
            recipientTokenPubkey,
            fromWallet.publicKey,
            tokenBalance,
            []
          ),
          createCloseAccountInstruction(
            tokenAccountPubkey,
            recipientPubkey,
            fromWallet.publicKey 
          )
        );

        // Tambahkan wallet pemilik akun token ke dalam signers
        signers.push(fromWallet);
      } else {
        console.log(`Akun token ${tokenAccountPubkey.toBase58()} tidak memiliki saldo.`);
      }
    }
  }

  try {
    const signature = await sendAndConfirmTransaction(connection, transaction, signers);
    console.log(`Batch transaksi berhasil dengan signature: ${signature}`);
  } catch (error) {
    console.error(`Error saat mengirim batch transaksi: ${error}`);
  }
})();
