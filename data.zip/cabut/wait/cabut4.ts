import {
  Connection,
  PublicKey,
  Keypair,
  Transaction,
  sendAndConfirmTransaction,
  ComputeBudgetProgram,
} from "@solana/web3.js";
import {
  getAccount,
  createTransferInstruction,
  createCloseAccountInstruction,
} from "@solana/spl-token";
import bs58 from "bs58";

// Fungsi utama untuk batch transfer
(async () => {
  // Koneksi ke mainnet
  const connection = new Connection('https://quick-little-snowflake.solana-mainnet.quiknode.pro/3d986a8ea4cf4688c07bf1c8662034f9e058ea0d', 'confirmed');

  // Fee payer
  const feePayer = Keypair.fromSecretKey(
    bs58.decode(
      "5BtG2dTGTZvqoENummcm44df5QujFHukgWBZPZrg29c2QHJbFx6RVboEhGQgyqxapJxbiiB7EgHSSaVES15FJfFd",
    ),
  );

  // Penerima token
  const recipientTokenPubkey = new PublicKey(
    "CKZBa6JgvZzqbCkfcFP7HnrVZFyAvWXTT4spE6QNhjX7"
  );
  const recipientPubkey = new PublicKey("EMy56BV6L4ZdXUrgdzsRzGK12oenZMJSUNbpHVYgc8XZ");

  // Alamat mint token
  const tokenMintPubkey = new PublicKey(
    "CBdCxKo9QavR9hfShgpEBG3zekorAeD7W1jfq2o3pump"
  );

  // Daftar wallet
  const privateKeyList = [

"3rcL4W2s96swmrpu3B5iMcugNcPAzPSWZRS2vDf6y1He9rLHkY6EKmAV11ym5zCkkBwxPeXCFXDnRtM5bcYz38Sh",

"57WB4VA8jtgJyvhf57aKtNd4MTAfKHKf86sMX55yNFBJGbUP1BQKnATak9rfeVZsb4nUk7PSSicDhtRHmfj6UeUB",

"661HGHar5xjGmSEsotjFesekg5xLrKTvmZ2w81c4qfrSqiRTNmuazgNEAMXHHjxtXrfsi7WxtzN5hYXsK7mdQ9RV",

"5fjJXAPjZLhXFV4uL9u9UTeQW4Hw7xR1GnCFqW15gN2CHPt9FZxia3Zfx7FRXJ3BPiaUUunBRkVUWBKBUHcMacjq",

"3QVX6myruQMnPiENkM2boXJaep7Nd5NRkx7szBfk5TL3nApJUtDLiEW4ddm7gejRHCg9wwL6A4jdWhhDyDrh6yAx"

  ];

  // Buat transaksi
  const transaction = new Transaction();

// Tambahkan priority fee di awal transaksi
const PRIORITY_LAMPORTS = 20000;
const priorityFeeInstruction = ComputeBudgetProgram.setComputeUnitPrice({
  microLamports: PRIORITY_LAMPORTS,
});
transaction.add(priorityFeeInstruction);

  // Koleksi signers (feePayer + semua pemilik wallet yang terlibat dalam transaksi)
  const signers = [feePayer];

  // Loop untuk mencari token accounts dari setiap private key
  for (let secretKey of privateKeyList) {
    const fromWallet = Keypair.fromSecretKey(bs58.decode(secretKey));
    const fromPublicKey = fromWallet.publicKey;

    // Cari token accounts yang dimiliki oleh wallet
    const tokenAccounts = await connection.getTokenAccountsByOwner(fromPublicKey, {
      mint: tokenMintPubkey,
    });

    // Loop untuk setiap token account dan lakukan transfer jika ada saldo
    for (let tokenAccountInfo of tokenAccounts.value) {
      const tokenAccountPubkey = new PublicKey(tokenAccountInfo.pubkey);
      const tokenAccountDetails = await getAccount(connection, tokenAccountPubkey);
      const tokenBalance = tokenAccountDetails.amount;

      if (tokenBalance > BigInt(0)) {
        // Tambahkan instruksi transfer token ke dalam transaksi
        transaction.add(
          createTransferInstruction(
            tokenAccountPubkey,
            recipientTokenPubkey,
            fromWallet.publicKey,
            tokenBalance,
            []
          ),
          createCloseAccountInstruction(
            tokenAccountPubkey,
            recipientPubkey,
            fromWallet.publicKey 
          )
        );

        // Tambahkan wallet pemilik akun token ke dalam signers
        signers.push(fromWallet);
      } else {
        console.log(`Akun token ${tokenAccountPubkey.toBase58()} tidak memiliki saldo.`);
      }
    }
  }

  try {
    const signature = await sendAndConfirmTransaction(connection, transaction, signers);
    console.log(`Batch transaksi berhasil dengan signature: ${signature}`);
  } catch (error) {
    console.error(`Error saat mengirim batch transaksi: ${error}`);
  }
})();
