import {
  Connection,
  PublicKey,
  Keypair,
  Transaction,
  sendAndConfirmTransaction,
  ComputeBudgetProgram,
} from "@solana/web3.js";
import {
  getAccount,
  createTransferInstruction,
  createCloseAccountInstruction,
} from "@solana/spl-token";
import bs58 from "bs58";

// Fungsi utama untuk batch transfer
(async () => {
  // Koneksi ke mainnet
  const connection = new Connection('https://quick-little-snowflake.solana-mainnet.quiknode.pro/3d986a8ea4cf4688c07bf1c8662034f9e058ea0d', 'confirmed');

  // Fee payer
  const feePayer = Keypair.fromSecretKey(
    bs58.decode(
      "5BtG2dTGTZvqoENummcm44df5QujFHukgWBZPZrg29c2QHJbFx6RVboEhGQgyqxapJxbiiB7EgHSSaVES15FJfFd",
    ),
  );

  // Penerima token
  const recipientTokenPubkey = new PublicKey(
    "CKZBa6JgvZzqbCkfcFP7HnrVZFyAvWXTT4spE6QNhjX7"
  );
  const recipientPubkey = new PublicKey("EMy56BV6L4ZdXUrgdzsRzGK12oenZMJSUNbpHVYgc8XZ");

  // Alamat mint token
  const tokenMintPubkey = new PublicKey(
    "CBdCxKo9QavR9hfShgpEBG3zekorAeD7W1jfq2o3pump"
  );

  // Daftar wallet
  const privateKeyList = [

"2VwFACi1EoyTYGEEZoxH2nmKQJ8unfoYuuBHoc7Nn91yjBy5p76Nc7ZH3mhmcSHsLP3aVDkDckEXXzJ12AreV4Ne",

"4c6F4o3WMFWbMfvSk2mtr8Wu3dBeT4oHhU8mH6snCsPHBdDkYqBxXUnBZ7fuHEHyanr2RGFUvxvXwLcn563dvbc9",

"EvKwwSbQUwe7je9W6MEGznws6VJWveCiyh29zfqWDZmQnKY9qQ195h57ZyyVyDd2mnMS539wfTQZisqgGN6yEqU",

"zJjwyPzjrvXPQF5JozewZECZSwDL2ZMac9eKmyHFJgxm1ainZoHvXmBGUrtS9tfARW59wvw18dPo7PNnba6AoA4",

"4RGxwpH5uujkikMcKcGx8qC6m6hsoUVQ2aEbdCxaf2c1AZ3jvnjReHvhMm4HoWL1isZcqm8SiYmxRQwiPgqTzbTq"

  ];

  // Buat transaksi
  const transaction = new Transaction();

// Tambahkan priority fee di awal transaksi
const PRIORITY_LAMPORTS = 20000;
const priorityFeeInstruction = ComputeBudgetProgram.setComputeUnitPrice({
  microLamports: PRIORITY_LAMPORTS,
});
transaction.add(priorityFeeInstruction);


  // Koleksi signers (feePayer + semua pemilik wallet yang terlibat dalam transaksi)
  const signers = [feePayer];

  // Loop untuk mencari token accounts dari setiap private key
  for (let secretKey of privateKeyList) {
    const fromWallet = Keypair.fromSecretKey(bs58.decode(secretKey));
    const fromPublicKey = fromWallet.publicKey;

    // Cari token accounts yang dimiliki oleh wallet
    const tokenAccounts = await connection.getTokenAccountsByOwner(fromPublicKey, {
      mint: tokenMintPubkey,
    });

    // Loop untuk setiap token account dan lakukan transfer jika ada saldo
    for (let tokenAccountInfo of tokenAccounts.value) {
      const tokenAccountPubkey = new PublicKey(tokenAccountInfo.pubkey);
      const tokenAccountDetails = await getAccount(connection, tokenAccountPubkey);
      const tokenBalance = tokenAccountDetails.amount;

      if (tokenBalance > BigInt(0)) {
        // Tambahkan instruksi transfer token ke dalam transaksi
        transaction.add(
          createTransferInstruction(
            tokenAccountPubkey,
            recipientTokenPubkey,
            fromWallet.publicKey,
            tokenBalance,
            []
          ),
          createCloseAccountInstruction(
            tokenAccountPubkey,
            recipientPubkey,
            fromWallet.publicKey 
          ),
        );

        // Tambahkan wallet pemilik akun token ke dalam signers
        signers.push(fromWallet);
      } else {
        console.log(`Akun token ${tokenAccountPubkey.toBase58()} tidak memiliki saldo.`);
      }
    }
  }

  // Dapatkan blockhash terbaru
  const { blockhash } = await connection.getLatestBlockhash(); // Dapatkan blockhash terbaru
  transaction.recentBlockhash = blockhash;
  transaction.feePayer = feePayer.publicKey; // Tetapkan fee payer
 
 try {
    const signature = await sendAndConfirmTransaction(connection, transaction, signers);
    console.log(`Batch transaksi berhasil dengan signature: ${signature}`);
  } catch (error) {
    console.error(`Error saat mengirim batch transaksi: ${error}`);
  }
})();
