const express = require('express');
const { spawn } = require('child_process');
const app = express();
const PORT = 3000;

app.use(express.static(__dirname));

// Objek untuk menyimpan proses yang sedang berjalan
const runningProcesses = {
  kode1: null,
  kode2: null,
  kode3: null
};

// Fungsi untuk menjalankan skrip
function runScript(scriptName, res) {
  if (runningProcesses[scriptName]) {
    return res.send(`Proses ${scriptName}.js sedang berjalan.`);
  }

  const process = spawn('node', [`${scriptName}.js`]);
  runningProcesses[scriptName] = process;

  let output = '';
  process.stdout.on('data', (data) => {
    output += data.toString();
  });

  process.stderr.on('data', (data) => {
    output += `ERR: ${data}`;
  });

  process.on('close', () => {
    runningProcesses[scriptName] = null;

    const allLines = output.split('\n');
    const lines = allLines.slice(0, 200);
    if (allLines.length > 200) lines.push();
    res.send(lines.join('\n'));
  });
}

// Jalankan endpoint masing-masing
app.get('/run-kode1', (req, res) => runScript('kode1', res));
app.get('/run-kode2', (req, res) => runScript('kode2', res));
app.get('/run-kode3', (req, res) => runScript('kode3', res));

// Endpoint untuk menghentikan proses
app.get('/stop-kode1', (req, res) => stopScript('kode1', res));
app.get('/stop-kode2', (req, res) => stopScript('kode2', res));
app.get('/stop-kode3', (req, res) => stopScript('kode3', res));

function stopScript(scriptName, res) {
  const process = runningProcesses[scriptName];
  if (process) {
    process.kill('SIGTERM');
    runningProcesses[scriptName] = null;
    res.send(`Proses ${scriptName}.js dihentikan.`);
  } else {
    res.send(`Tidak ada proses ${scriptName}.js yang sedang berjalan.`);
  }
}

app.listen(PORT, () => {
  console.log(`Server berjalan di http://localhost:${PORT}`);
});
