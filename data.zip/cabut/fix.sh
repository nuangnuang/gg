for i in {1..50}; do
  sed -i 's/console\.log('\''Balance Token= '\''sisaBalance);/console.log(`🏦Balance Token = ${sisaBalance}`);/' bybit$i.js
done
