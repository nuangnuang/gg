require('dotenv').config();
const { RestClientV5 } = require('bybit-api');
const { v4: uuidv4 } = require('uuid');

const API_KEY = process.env.KEY;
const API_SECRET = process.env.SECRET;

const client = new RestClientV5({
  key: API_KEY,
  secret: API_SECRET,
  testnet: false, // ganti true jika ingin pakai testnet
});

const COIN = 'W'; // Ganti dengan coin yang ingin dicek dan ditransfer

// Fungsi utama
async function cekSaldoDanTransfer() {
  try {
    // 1. Cek saldo di akun FUND
    const res = await client.getCoinBalance({
      accountType: 'UNIFIED',
      coin: COIN,
    });

    const walletBalance = res?.result?.balance?.walletBalance;

    if (!walletBalance || parseFloat(walletBalance) === 0) {
      console.log(`❌ Tidak ada saldo ${COIN} yang tersedia di FUND.`);
      return;
    }

    const saldoTersedia = parseFloat(walletBalance).toFixed(8);
    console.log(`✅ Saldo tersedia untuk ${COIN} di FUND: ${saldoTersedia}`);

    // 2. Lakukan transfer internal dari FUND ke UNIFIED
    const transferId = uuidv4(); // Transfer ID unik

    const transferResponse = await client.createInternalTransfer(
      transferId,
      COIN,
      saldoTersedia,
      'UNIFIED',
      'FUND'
    );

    console.log(`✅ Transfer berhasil`);

  } catch (err) {
    console.error('❌ Terjadi kesalahan:', err?.response?.data || err.message);
  }
}

// Jalankan fungsi utama
cekSaldoDanTransfer();
