const axios = require('axios');
const crypto = require('crypto');
require('dotenv').config(); // Gunakan file .env untuk simpan KEY dan SECRET

// Konfigurasi API
const API_KEY = process.env.KUCOIN_API_KEY;
const API_SECRET = process.env.KUCOIN_API_SECRET;
const API_PASSPHRASE = process.env.KUCOIN_API_PASSPHRASE;
const API_BASE_URL = 'https://api.kucoin.com';

const now = Date.now();

// Fungsi untuk membuat signature
function signRequest(method, endpoint, body = '') {
  const strForSign = `${now}${method}${endpoint}${body}`;
  const signature = crypto
    .createHmac('sha256', API_SECRET)
    .update(strForSign)
    .digest('base64');
  return signature;
}

// Fungsi untuk enkripsi passphrase
function signPassphrase() {
  return crypto
    .createHmac('sha256', API_SECRET)
    .update(API_PASSPHRASE)
    .digest('base64');
}

async function withdraw() {
  const endpoint = '/api/v3/withdrawals';
  const method = 'POST';

  // Data yang akan dikirim
  const bodyData = {
    currency: 'PIP',
    toAddress: '884escp1AAmngEmeijL2VnggY859Pt65GqqXzQ3M3vT4',
    amount: '400',
    chain: 'sol',
    feeDeductType: 'INTERNAL',
    withdrawType: 'ADDRESS'
  };

  const bodyString = JSON.stringify(bodyData);
  const signature = signRequest(method, endpoint, bodyString);

  try {
    const response = await axios({
      method,
      url: `${API_BASE_URL}${endpoint}`,
      headers: {
        'KC-API-KEY': API_KEY,
        'KC-API-SIGN': signature,
        'KC-API-TIMESTAMP': now.toString(),
        'KC-API-PASSPHRASE': signPassphrase(),
        'KC-API-KEY-VERSION': '2',
        'Content-Type': 'application/json',
      },
      data: bodyData,
    });

    console.log('✅ Withdrawal sukses:', response.data);
  } catch (error) {
    console.error('❌ Gagal withdraw:', error.response?.data || error.message);
  }
}

withdraw();
