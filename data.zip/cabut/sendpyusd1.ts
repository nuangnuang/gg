import 'dotenv/config';
import {
  Connection,
  Keypair,
  PublicKey,
  Transaction,
  sendAndConfirmTransaction,
} from "@solana/web3.js";
import {
  getAssociatedTokenAddressSync,
  createTransferCheckedInstruction,
  getMint,
  TOKEN_2022_PROGRAM_ID,
} from "@solana/spl-token";
import bs58 from "bs58";

// Ambil dari .env
const jumlahtf = 6.5;
const wallet1 = process.env.PAYERGASS;
const solWallet = "8Zm6WWK9rxAcVcSLuK7TnezXVL7ii6tC79NHsDAmr7WA";
const token_mint = process.env.TOKENMINT;
const decimals = 6;
const RPC = process.env.CONNECT;
const connection = new Connection(RPC, "confirmed");

(async () => {
  const sender = Keypair.fromSecretKey(bs58.decode(wallet1));
  const senderPubkey = sender.publicKey;

  const tokenMint = new PublicKey(token_mint);
  const recipientPublicKey = new PublicKey(solWallet);

  const senderTokenAccount = getAssociatedTokenAddressSync(
    tokenMint,
    senderPubkey,
    false,
    TOKEN_2022_PROGRAM_ID
  );

  const recipientTokenAccount = getAssociatedTokenAddressSync(
    tokenMint,
    recipientPublicKey,
    false,
    TOKEN_2022_PROGRAM_ID
  );

  const amount = await connection.getTokenAccountBalance(senderTokenAccount);
  const rawAmount = jumlahtf * 1e6;

//  if (rawAmount === BigInt(0)) {
//    console.log("❌ Token balance 0, tidak ada yang ditransfer.");
//    return;
//  }

  const tx = new Transaction().add(
    createTransferCheckedInstruction(
      senderTokenAccount,
      tokenMint,
      recipientTokenAccount,
      senderPubkey,
      rawAmount,
      decimals,
      [],
      TOKEN_2022_PROGRAM_ID
    )
  );

  const sig = await sendAndConfirmTransaction(connection, tx, [sender]);
  console.log("✅ Transfer berhasil:", sig);
})();
