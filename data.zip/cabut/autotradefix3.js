const { RestClientV5 } = require('bybit-api');
require('dotenv').config();
const SYMBOL = process.env.SYMBOL;
const client = new RestClientV5({
  key: process.env.KEY,
  secret: process.env.SECRET,
  testnet: false,
});

// ====== SETTING ======
const MIN_USDT_BALANCE = 30;    // Saldo minimum untuk trigger
const MANUAL_QTY = 30;          // Jumlah token W yang ingin dibeli
const INTERVAL_MS = 20000;      // Interval pengecekan (ms)

async function getUSDTBalance() {
  try {
    const res = await client.getCoinBalance({
      accountType: 'UNIFIED',
      coin: 'USDT',
    });
    const saldo = parseFloat(res.result.balance.walletBalance);
    return saldo;
  } catch (err) {
    console.error('❌ Gagal mendapatkan saldo:', err?.response?.data || err.message);
    return 0;
  }
}

async function placeMarketBuy(symbol, qty) {
  try {
    const order = await client.submitOrder({
      category: 'spot',
      symbol,
      side: 'Buy',
      orderType: 'Market',
      qty: qty.toString(),
    });
    console.log('✅ Order berhasil:', order.result.orderId);
  } catch (err) {
    console.error('❌ Order gagal:', err?.response?.data || err.message);
  }
}

async function monitorAndTrade() {
  while (true) {
    try {
      const saldo = await getUSDTBalance();

      if (saldo >= MIN_USDT_BALANCE) {
        console.log(`🚀 Saldo (${saldo} USDT), membeli ${MANUAL_QTY}`);
        await placeMarketBuy(SYMBOL, MANUAL_QTY);
      } else {
//        console.log(`⏳ Saldo belum cukup (${saldo} USDT Untuk buy market)`);
      }

      // Tunggu sebelum cek lagi
      await new Promise(resolve => setTimeout(resolve, INTERVAL_MS));
    } catch (err) {
      console.error('❌ Error dalam loop:', err.message);
      await new Promise(resolve => setTimeout(resolve, INTERVAL_MS));
    }
  }
}

// Jalankan loop
monitorAndTrade();
