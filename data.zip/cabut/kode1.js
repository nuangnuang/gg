// main.js
const { spawn } = require('child_process');

const scripts = ['autotradefix1.js', 'autotransfer1.js', 'autowd.js', 'autosell.js'];

scripts.forEach(script => {
  const proc = spawn('node', [script], { stdio: 'inherit' });
});
