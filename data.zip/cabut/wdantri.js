require('dotenv').config();
const { RestClientV5 } = require('bybit-api');
const { spawn } = require('child_process');
const fs = require('fs');
const token = process.env.COIN;
const TOKEN_SYMBOL = token;
const INTERVAL_MS = 10_000;
const MAX_WD = 50;

const client = new RestClientV5({
  key: process.env.KEY,
  secret: process.env.SECRET,
  testnet: false,
});

let lastProcessedId = null;
let currentCount = 1;

async function runScript(scriptPath) {
  if (!fs.existsSync(scriptPath)) {
    console.error(`❌ File tidak ditemukan: ${scriptPath}`);
    return;
  }

  console.log(`🚀 Menjalankan skrip: ${scriptPath}`);
  const child = spawn('node', [scriptPath]);

  child.stdout.on('data', (data) => {
    console.log(`[STDOUT - ${scriptPath}]: ${data.toString()}`);
  });

  child.stderr.on('data', (data) => {
    console.error(`[STDERR - ${scriptPath}]: ${data.toString()}`);
  });

  child.on('close', (code) => {
    console.log(`✅ Skrip ${scriptPath} selesai dengan kode keluar: ${code}`);
  });
}

async function checkWithdrawal() {
  try {
    const res = await client.getWithdrawalRecords({
      coin: TOKEN_SYMBOL,
      limit: 1,
    });

    const withdrawal = res.result?.rows?.[0];

    if (!withdrawal) {
      console.log(`❌ Tidak ada withdrawal untuk ${TOKEN_SYMBOL}.`);
      return setTimeout(checkWithdrawal, INTERVAL_MS);
    }

    const status = withdrawal.status;
    const id = withdrawal.id || withdrawal.withdrawId;

//    console.log(`🔍 withdraw terakhir: ${status} | ID: ${id}`);

    if (status === 'BlockchainConfirmed' && id !== lastProcessedId) {
//      console.log(`✅ Withdrawal sukses terdeteksi [#${currentCount}]`);

      lastProcessedId = id;

      if (currentCount <= MAX_WD) {
        const scriptPath = `./bybit${currentCount}.js`; // <-- diubah dari wd menjadi bybit
        await runScript(scriptPath);
        currentCount++;
      } else {
         console.log(`✅ DONE.`);
       process.exit(0);
      }
    }

    setTimeout(checkWithdrawal, INTERVAL_MS);

  } catch (err) {
    console.error(`❌ Gagal mengecek withdrawal: ${err.message || err}`);
    setTimeout(checkWithdrawal, INTERVAL_MS);
  }
}

checkWithdrawal();
