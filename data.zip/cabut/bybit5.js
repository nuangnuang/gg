require('dotenv').config();
const { RestClientV5 } = require('bybit-api');

const client = new RestClientV5({
  testnet: false, // set true jika ingin menggunakan testnet
  key: process.env.KEY,
  secret: process.env.SECRET,
});

const coin = process.env.COIN;
const address = process.env.ADDRESS5;
const timestamp = Date.now();

async function withdrawSebagianSaldo() {
  try {
    // Ambil saldo FUND untuk koin tertentu
    const res = await client.getCoinBalance({
      accountType: 'FUND',
      coin: coin,
    });

    const walletBalance = res?.result?.balance?.walletBalance;
    if (!walletBalance || parseFloat(walletBalance) === 0) {
      console.log('❌ Saldo tidak tersedia untuk koin:', coin);
      return;
    }

    const amount = (parseFloat(walletBalance) / 46).toFixed(4);
    const sisaBalance = (parseFloat(walletBalance));
    console.log(`Balance Token= ${sisaBalance}`);
    // Kirim withdraw
    const withdrawRes = await client.submitWithdrawal({
      coin: coin,
      chain: 'SOL', // ganti ke chain lain jika diperlukan
      address: address,
      amount: amount,
      timestamp: timestamp,
      forceChain: 1,
      accountType: 'FUND',
      feeType: 1,
    });

    console.log(`✅ Withdrawal sebesar ${amount} ${coin} berhasil.`);
//    console.log(JSON.stringify(withdrawRes, null, 2));
  } catch (error) {
    console.error('❌ Error:', error.response?.data || error.message);
  }
}

withdrawSebagianSaldo();
