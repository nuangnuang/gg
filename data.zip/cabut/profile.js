require('dotenv').config();
const axios = require('axios');
const fs = require('fs');
const jwt = require('jsonwebtoken');

const API_BASE = 'https://api.coinbase.com';
const privateKey = fs.readFileSync('./ec_private.pem', 'utf8');

const keyId = process.env.CDP_API_KEY_ID;
const orgId = process.env.CDP_ORG_ID;
const keyName = process.env.CDP_KEY_NAME;

function createJwt() {
  const now = Math.floor(Date.now() / 1000);
  return jwt.sign(
    {
      iss: keyId,
      sub: orgId,
      aud: 'coinbase-cloud',
      iat: now,
      exp: now + 60
    },
    privateKey,
    {
      algorithm: 'ES256',
      header: { kid: keyName }
    }
  );
}

async function getAccessToken() {
  const client_assertion = createJwt();
  const resp = await axios.post(`${API_BASE}/oauth/token`, {
    grant_type: 'client_credentials',
    client_assertion,
    client_assertion_type: 'urn:ietf:params:oauth:client-assertion-type:jwt-bearer'
  });
  return resp.data.access_token;
}

async function getProfiles(token) {
  const resp = await axios.get(
    `${API_BASE}/api/v3/brokerage/profiles`,
    {
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    }
  );

  console.log('✅ Daftar Profiles:');
  for (const p of resp.data.profiles) {
    console.log(`- Name: ${p.name}`);
    console.log(`  ID: ${p.uuid}`);
    console.log(`  Default: ${p.is_default}`);
    console.log('------------------------');
  }
}

(async () => {
  try {
    const token = await getAccessToken();
    await getProfiles(token);
  } catch (e) {
    console.error('❌ Error:', e.response?.data || e.message || e);
  }
})();
