import { CdpClient } from "@coinbase/cdp-sdk";
import dotenv from "dotenv";
dotenv.config();
const wallet1 : process.env.ADDRESS1;
async function main() {
  const cdp = new CdpClient();
  // pastikan account dibuat sebelumnya:
  const accounts = await cdp.solana.listAccounts();
  const sender = accounts[0]; // atau filter sesuai nama/address

  console.log("🔑 Sending from:", sender.address);
  const resp = await sender.transfer({
    to: wallet1,
    amount: "1",
    token: "usdc",
    network: "solana"
  });
  console.log("✅ Sent! Signature:", resp.signature);
}

main().catch(console.error);
