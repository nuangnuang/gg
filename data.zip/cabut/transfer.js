require('dotenv').config();
const { RestClientV5 } = require('bybit-api');

const client = new RestClientV5({
  testnet: false,
  key: process.env.KEY,
  secret: process.env.SECRET,
});

/**
 * Fungsi untuk melakukan transfer internal di Bybit
 * @param {string} transferId - Unique transfer ID (bisa UUID)
 * @param {string} coin - Contoh 'BTC'
 * @param {string|number} amount - Contoh '0.05'
 * @param {string} fromAccountType - Contoh 'UNIFIED'
 * @param {string} toAccountType - Contoh 'CONTRACT'
 */
async function internalTransfer(transferId, coin, amount, fromAccountType, toAccountType) {
  try {
    const response = await client.createInternalTransfer(
      transferId,
      coin,
      amount.toString(),
      fromAccountType,
      toAccountType
    );
    console.log('Transfer berhasil:', response);
  } catch (error) {
    console.error('Error saat transfer:', error);
  }
}

// Contoh pemakaian:
const { v4: uuidv4 } = require('uuid');
internalTransfer(uuidv4(), 'USDT', 2.5, 'UNIFIED', 'FUND');
