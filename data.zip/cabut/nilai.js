const readline = require('readline');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

rl.question('Masukkan nilai yang ingin digunakan: ', (input) => {
  const nilai = parseFloat(input);
  console.log(`✅ Nilai yang dimasukkan: ${nilai}`);

  // lanjutkan eksekusi kode kamu di sini
  rl.close();
});
