const { spawn } = require("child_process");
const {
  Connection,
  PublicKey,
} = require("@solana/web3.js");
const {
  getAccount,
} = require("@solana/spl-token"); // pastikan sudah install @solana/spl-token

// === KONFIGURASI ===
const WALLET_ADDRESS = "6iLzQjQCFeq5FKmdPgHiTqkpvWEmwbDop12gZkTPzhTF";
const TOKEN_MINT = "85VBFQZC9TZkfaptBWjvUw7YbZjy52A6mjtPGjstQAmQ";
const MIN_TOKEN_BALANCE = 179; // ubah sesuai jumlah minimum token yang diinginkan

const connection = new Connection("https://api.mainnet-beta.solana.com"); // atau endpoint RPC kamu

const delay = (ms) => new Promise((res) => setTimeout(res, ms));

async function getTokenBalance(ownerAddress, mintAddress) {
  const accounts = await connection.getTokenAccountsByOwner(
    new PublicKey(ownerAddress),
    {
      mint: new PublicKey(mintAddress),
    }
  );

  if (accounts.value.length === 0) return 0;

  const tokenAccountPubkey = accounts.value[0].pubkey;
  const accountInfo = await connection.getParsedAccountInfo(tokenAccountPubkey);
  const amount = accountInfo.value.data.parsed.info.tokenAmount.uiAmount;
  return amount;
}

async function cekLooping() {
  while (true) {
    try {
      const balanceToken = await getTokenBalance(WALLET_ADDRESS, TOKEN_MINT);

      console.log(`🪙 Token Balance: ${balanceToken}`);

      if (balanceToken >= MIN_TOKEN_BALANCE) {
        console.log("✅ Menjalankan skrip karena token wormhole terdeteksi\n");

        const child = spawn("node", ["wusdt.js"]);

        child.stdout.on("data", (data) => {
          process.stdout.write(`📤 [external]: ${data}`);
        });

        child.stderr.on("data", (data) => {
          process.stderr.write(`❌ [external error]: ${data}`);
        });

        await new Promise((resolve) => {
          child.on("exit", (code) => {
            console.log(`🔚 exit code ${code}`);
            resolve();
          });
        });
      } else {
        console.log("⚠️  Token belum mencukupi, menunggu...");
      }
    } catch (err) {
      console.error("❌ Terjadi kesalahan saat cek saldo:", err.message);
    }

    await delay(30_000); // 30 detik
  }
}

cekLooping();
